package com.lazur.client;

import com.lazur.LazurMod;
import com.lazur.entity.LazurEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

import java.util.HashMap;
import java.util.Map;

public class LazurRenderer extends MobRenderer<LazurEntity, LazurRenderState, LazurModel> {
    private static final Identifier BLACK = LazurMod.id("textures/entity/lazur_black.png");
    private static final Identifier AZURE = LazurMod.id("textures/entity/lazur_azure.png");

    private final Map<Integer, LazurAnimator> animators = new HashMap<>();

    public LazurRenderer(EntityRendererProvider.Context context) {
        super(context, new LazurModel(context.bakeLayer(LazurModel.LAYER)), 0.4f);
    }

    @Override
    public LazurRenderState createRenderState() {
        return new LazurRenderState();
    }

    @Override
    public void extractRenderState(LazurEntity entity, LazurRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        state.lazurState = entity.getLazurState();
        state.appearance = entity.getAppearance();
        if (state.appearance != LazurEntity.A_FIGURE) ClientSkin.apply(state); // slim / wide arms of the player model
        // both black forms are "lit from inside": the glitch pixels around them must be visible in a dark cave
        if (state.appearance != LazurEntity.A_SKIN) state.lightCoords = 15728880; // = full bright (15 << 20 | 15 << 4)
        state.azureFlash = state.lazurState == LazurEntity.S_GLITCH && LazurAnimator.glitchBurst(state.ageInTicks);
        state.animator = animators.computeIfAbsent(entity.getId(), id -> new LazurAnimator());
        if (animators.size() > 8) animators.keySet().removeIf(id -> id != entity.getId()); // one Lazur at a time
    }

    @Override
    public Identifier getTextureLocation(LazurRenderState state) {
        if (state.appearance == LazurEntity.A_FIGURE) return state.azureFlash ? AZURE : BLACK;
        if (state.appearance == LazurEntity.A_BLACK_PLAYER) return BLACK; // the player model, fully black
        return state.skinTexture != null ? state.skinTexture : BLACK;
    }
}
