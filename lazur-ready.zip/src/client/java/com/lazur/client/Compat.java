package com.lazur.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.gui.screens.Screen;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/** Reflection helpers for client calls whose names differ between Minecraft versions; a miss does nothing. */
final class Compat {
    private Compat() {}

    static boolean getHideGui(Options o) {
        try {
            Field f = o.getClass().getField("hideGui");
            return f.getBoolean(o);
        } catch (ReflectiveOperationException ignored) { }
        try {
            Object v = o.getClass().getMethod("hideGui").invoke(o);
            if (v instanceof Boolean b) return b;
        } catch (ReflectiveOperationException ignored) { }
        return false;
    }

    static void setHideGui(Options o, boolean value) {
        try {
            o.getClass().getField("hideGui").setBoolean(o, value);
            return;
        } catch (ReflectiveOperationException ignored) { }
        for (String name : new String[]{"setHideGui", "hideGui"}) {
            try {
                o.getClass().getMethod(name, boolean.class).invoke(o, value);
                return;
            } catch (ReflectiveOperationException ignored) { }
        }
    }

    static void setScreen(Minecraft mc, Screen s) {
        try {
            Method m = Minecraft.class.getMethod("setScreen", Screen.class);
            m.invoke(mc, s);
        } catch (ReflectiveOperationException ignored) { }
    }
}
