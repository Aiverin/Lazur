package com.lazur.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.gui.screens.Screen;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/** Reflection helpers for client calls whose names differ between Minecraft versions; a miss does nothing. */
final class Compat {
    private Compat() {}

    static boolean getHideGui(Options o) {
        try {
            Field f = o.getClass().getField("hideGui");
            return f.getBoolean(o);
        } catch (ReflectiveOperationException ignored) { }
        try {
            Object v = o.getClass().getMethod("hideGui").invoke(o);
            if (v instanceof Boolean b) return b;
        } catch (ReflectiveOperationException ignored) { }
        return false;
    }

    static void setHideGui(Options o, boolean value) {
        try {
            o.getClass().getField("hideGui").setBoolean(o, value);
            return;
        } catch (ReflectiveOperationException ignored) { }
        for (String name : new String[]{"setHideGui", "hideGui"}) {
            try {
                o.getClass().getMethod(name, boolean.class).invoke(o, value);
                return;
            } catch (ReflectiveOperationException ignored) { }
        }
    }

    private static Method screenSetter;
    private static Object screenSetterOwner;     // null = the Minecraft object itself
    private static boolean screenSearched;

    /** Opens a screen. The method name changes between versions, so it is found by its signature: one Screen parameter. */
    private static Method screenSetter;
    private static boolean searched;

    /** Opens a screen. The method is found by its signature (void, one Screen parameter), so a rename does not matter. */
    static void setScreen(Minecraft mc, Screen s) {
        if (!searched) {
            searched = true;
            try {
                Method best = null;
                for (Method m : Minecraft.class.getMethods()) {
                    if (m.getReturnType() != void.class || m.getParameterCount() != 1) continue;
                    if (m.getParameterTypes()[0] != Screen.class) continue;
                    if (best == null || m.getName().equals("setScreen")) best = m;
                }
                screenSetter = best;
            } catch (RuntimeException ignored) { }
            com.lazur.LazurMod.LOGGER.info("Lazur: screen setter = {}", screenSetter == null ? "NOT FOUND" : screenSetter.getName());
        }
        if (screenSetter == null) return;
        try { screenSetter.invoke(mc, s); } catch (ReflectiveOperationException | RuntimeException ignored) { }
    }
}
