package com.lazur.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.PlayerSkin;

/**
 * The ONLY place that reads the local player's skin. On a pirate launcher getSkin() already returns
 * the default Steve/Alex skin for the offline UUID, so no special case is needed.
 * If PlayerSkin accessors changed in 26.2, fix just this file.
 */
final class ClientSkin {
    private static final Identifier STEVE = Identifier.withDefaultNamespace("textures/entity/player/wide/steve.png");

    static void apply(LazurRenderState s) {
        LocalPlayer p = Minecraft.getInstance().player;
        if (p == null) {
            s.skinTexture = STEVE;
            s.slim = false;
            return;
        }
        PlayerSkin skin = p.getSkin();
        s.skinTexture = skin.body().texturePath();
        s.slim = skin.model().name().equals("SLIM"); // classic model = WIDE/CLASSIC, Alex = SLIM
    }

    private ClientSkin() {}
}
