package com.lazur.client;

import com.lazur.LazurMod;
import com.lazur.net.LazurNet;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * The jumpscare: for now only the screen reddens in a half circle on the left and the right edge
 * (no picture yet). The sound is played by the server.
 */
public final class LazurScreamClient {
    private LazurScreamClient() {}

    private static int total, age;
    private static final int CELL = 3;           // GUI pixels per cell
    private static final float REACH = 0.30f;    // how far the red reaches into the screen (share of the width)
    private static final float TALL = 0.75f;     // half height of the half circle (share of the screen height)

    public static void init() {
        ClientPlayNetworking.registerGlobalReceiver(LazurNet.Scream.TYPE, (payload, context) -> {
            total = Math.max(1, payload.ticks());
            age = 0;
        });
        ClientTickEvents.END_CLIENT_TICK.register(c -> { if (total > 0 && ++age > total + 20) total = 0; });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> total = 0);
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, LazurMod.id("scream"), LazurScreamClient::extract);
    }

    private static void extract(GuiGraphicsExtractor g, DeltaTracker delta) {
        if (total <= 0) return;
        var win = Minecraft.getInstance().getWindow();
        int sw = win.getGuiScaledWidth(), sh = win.getGuiScaledHeight();
        float t = age + delta.getGameTimeDeltaPartialTick(false);
        // quick rise (5 ticks), a pulse, then it stays at full strength; after death it fades out
        float k = Math.min(1f, t / 5f);
        if (t < total) k *= 0.85f + 0.15f * (float) Math.sin(t * 1.4f);
        else k *= Math.max(0f, 1f - (t - total) / 20f);
        if (k <= 0f) return;

        float a = sw * REACH, b = sh * TALL, cy = sh * 0.5f;
        for (int y = 0; y < sh; y += CELL) {
            float dy = (y + CELL * 0.5f - cy) / b;
            if (Math.abs(dy) >= 1f) continue;
            for (int x = 0; x < a; x += CELL) {
                float dx = (x + CELL * 0.5f) / a;
                float dd = (float) Math.sqrt(dx * dx + dy * dy);
                if (dd >= 1f) break;
                float al = (1f - dd) * (1f - dd) * 0.85f * k;
                int color = ((int) (al * 255f) << 24) | 0xC80000;
                g.fill(x, y, x + CELL, y + CELL, color);                        // left edge
                g.fill(sw - x - CELL, y, sw - x, y + CELL, color);              // right edge
            }
        }
    }
}
