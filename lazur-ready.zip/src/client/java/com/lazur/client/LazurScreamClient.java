package com.lazur.client;

import com.lazur.LazurMod;
import com.lazur.net.LazurNet;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * The jumpscare: for now only the screen reddens in a half circle on the left and the right edge
 * (no picture yet). The sound is played by the server.
 */
public final class LazurScreamClient {
    private LazurScreamClient() {}

    private static int total, age;
    private static final float REACH = 0.30f;    // how far the red reaches into the screen (share of the width)
    private static final float TALL = 0.75f;     // half height of the half circle (share of the screen height)

    public static void init() {
        ClientPlayNetworking.registerGlobalReceiver(LazurNet.Scream.TYPE, (payload, context) -> {
            total = Math.max(1, payload.ticks());
            age = 0;
        });
        ClientTickEvents.END_CLIENT_TICK.register(c -> { if (total > 0 && ++age > total + 20) total = 0; });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> total = 0);
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, LazurMod.id("scream"), LazurScreamClient::extract);
    }

    private static void extract(GuiGraphicsExtractor g, DeltaTracker delta) {
        if (total <= 0) return;
        var win = Minecraft.getInstance().getWindow();
        int sw = win.getGuiScaledWidth(), sh = win.getGuiScaledHeight();
        float t = age + delta.getGameTimeDeltaPartialTick(false);
        // quick rise (5 ticks), a pulse, then it stays at full strength; after death it fades out
        float k = Math.min(1f, t / 5f);
        if (t < total) k *= 0.85f + 0.15f * (float) Math.sin(t * 1.4f);
        else k *= Math.max(0f, 1f - (t - total) / 20f);
        if (k <= 0f) return;

        // a half circle on each edge built from a few big rectangles (a few dozen fills per frame, not thousands)
        // a half circle on each side, built from a few nested ellipses (each one a stack of ~20 row strips):
        // about 400 fills in total instead of thousands of small cells, so it costs nothing
        final int rings = 8, rows = 20;
        float a = sw * REACH, b = sh * TALL, cy = sh * 0.5f;
        int alpha = (int) (Math.min(1f, 0.16f * k) * 255f);
        int color = (alpha << 24) | 0xC80000;
        for (int ring = 0; ring < rings; ring++) {
            float sc = (ring + 1f) / rings;               // outer ring first
            float ra = a * (1f - sc * 0.0f) * (1f - ring / (float) rings), rb = b * (1f - ring / (float) rings);
            if (ra < 1f) break;
            for (int row = 0; row < rows; row++) {
                float y0 = cy - rb + (2f * rb) * row / rows, y1 = cy - rb + (2f * rb) * (row + 1) / rows;
                float ym = (y0 + y1) * 0.5f - cy;
                float w = ra * (float) Math.sqrt(Math.max(0f, 1f - (ym * ym) / (rb * rb)));
                if (w < 1f) continue;
                int iy0 = Math.max(0, (int) y0), iy1 = Math.min(sh, (int) y1 + 1);
                g.fill(0, iy0, (int) w, iy1, color);
                g.fill(sw - (int) w, iy0, sw, iy1, color);
            }
        }
    }
}
