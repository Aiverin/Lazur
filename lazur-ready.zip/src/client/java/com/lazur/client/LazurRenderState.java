package com.lazur.client;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;

public class LazurRenderState extends LivingEntityRenderState {
    public int lazurState;
    public int appearance;
    public boolean slim;
    public boolean azureFlash;
    public Identifier skinTexture;
    public LazurAnimator animator;
}
