package com.lazur.client;

import com.lazur.LazurMod;
import com.lazur.net.LazurNet;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Client side of the grab: holds the camera and the player in front of Lazur's face, shakes the camera,
 * draws the gauge + the prompts (only keys and the shrinking ring, no text), judges the key presses and reports
 * the result of each prompt to the server. The server decides everything else.
 */
public final class LazurGrabClient {
    private LazurGrabClient() {}

    private static final int WINDOW_AFTER_TICKS = 2;   // a press this late after the ring closed still counts
    private static final float LAZUR_HEAD_Y = 2.78f;   // centre of Lazur's head above his feet
    private static final float PLAYER_EYE_Y = 1.62f;

    // ---- session ----
    private static boolean active;
    private static int lazurId, missingTicks;
    private static float bar;
    private static float kick;                          // extra camera shake after a mistake
    private static final boolean[] prevDown = new boolean[4];

    // ---- current prompt ----
    private static boolean hasPrompt;
    private static LazurNet.GrabPrompt prompt;
    private static int age;

    // ---- result flash ----
    private static int flashTicks, flashCode;
    private static float flashX, flashY;

    // pixel glyphs (5 x 7) for W A S D, so the key is big and clear without a scaled font
    private static final String[] G_W = {"X...X", "X...X", "X...X", "X.X.X", "X.X.X", "XX.XX", "X...X"};
    private static final String[] G_A = {".XXX.", "X...X", "X...X", "XXXXX", "X...X", "X...X", "X...X"};
    private static final String[] G_S = {".XXXX", "X....", "X....", ".XXX.", "....X", "....X", "XXXX."};
    private static final String[] G_D = {"XXXX.", "X...X", "X...X", "X...X", "X...X", "X...X", "XXXX."};

    public static void init() {
        ClientPlayNetworking.registerGlobalReceiver(LazurNet.GrabStart.TYPE, (payload, context) -> start(payload.lazurId()));
        ClientPlayNetworking.registerGlobalReceiver(LazurNet.GrabState.TYPE, (payload, context) -> bar = payload.bar());
        ClientPlayNetworking.registerGlobalReceiver(LazurNet.GrabPrompt.TYPE, (payload, context) -> {
            if (!active) return;
            prompt = payload;
            hasPrompt = true;
            age = 0;
        });
        ClientPlayNetworking.registerGlobalReceiver(LazurNet.GrabEnd.TYPE, (payload, context) -> end(payload.mode()));

        ClientTickEvents.END_CLIENT_TICK.register(LazurGrabClient::tick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> reset());
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, LazurMod.id("grab"), LazurGrabClient::extract);
    }

    // =====================================================================================
    // session
    // =====================================================================================
    private static void start(int id) {
        Minecraft mc = Minecraft.getInstance();
        reset();
        active = true;
        lazurId = id;
        // keys that are already held when the grab starts must not count as presses
        KeyMapping[] keys = keys(mc);
        for (int i = 0; i < 4; i++) {
            while (keys[i].consumeClick()) { /* drain */ }
            prevDown[i] = keys[i].isDown();
        }
    }

    private static void reset() {
        active = false;
        hasPrompt = false;
        prompt = null;
        bar = 0f;
        kick = 0f;
        missingTicks = 0;
        flashTicks = 0;
    }

    private static void end(int mode) {
        Minecraft mc = Minecraft.getInstance();
        if (active && mode == LazurNet.END_RELEASED && mc.player != null && mc.level != null) {
            // let go: a push away from Lazur so the 1.5 s head start is not spent on getting up
            Entity lz = mc.level.getEntity(lazurId);
            if (lz != null) {
                Vec3 away = mc.player.position().subtract(lz.position());
                double len = Math.hypot(away.x, away.z);
                if (len > 1.0E-4) {
                    mc.player.setDeltaMovement(away.x / len * 0.55, 0.25, away.z / len * 0.55);
                }
            }
        }
        reset();
    }

    private static KeyMapping[] keys(Minecraft mc) {
        var o = mc.options;
        return new KeyMapping[]{o.keyUp, o.keyLeft, o.keyDown, o.keyRight};
    }

    // =====================================================================================
    // tick: hold, shake, read keys
    // =====================================================================================
    private static void tick(Minecraft mc) {
        if (!active) return;
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || !p.isAlive()) {
            reset();
            return;
        }
        Entity lz = mc.level.getEntity(lazurId);
        if (lz == null) {
            if (++missingTicks > 60) reset();
            return;
        }
        missingTicks = 0;

        hold(mc, p, lz);
        shake(p, lz);
        readKeys(mc);
        if (flashTicks > 0) flashTicks--;
    }

    /** The player hangs in front of Lazur's face (eyes at the height of his head). */
    private static void hold(Minecraft mc, LocalPlayer p, Entity lz) {
        double yaw = Math.toRadians(lz.getYRot());
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);
        double[] dists = {com.lazur.LazurConfig.get().grabHoldDistance, 1.0, 0.75};
        double[] heights = {LAZUR_HEAD_Y - PLAYER_EYE_Y, 0.7, 0.2, 0.0};
        for (double dist : dists) {
            for (double h : heights) {
                double x = lz.getX() + fx * dist, y = lz.getY() + h, z = lz.getZ() + fz * dist;
                var box = p.getBoundingBox().move(x - p.getX(), y - p.getY(), z - p.getZ());
                if (mc.level.noCollision(p, box)) {
                    p.setPos(x, y, z);
                    p.setDeltaMovement(Vec3.ZERO);
                    p.resetFallDistance();
                    return;
                }
            }
        }
        p.setDeltaMovement(Vec3.ZERO);   // no free spot at all: at least do not move
        p.resetFallDistance();
    }

    /** The camera is locked on Lazur's face and shakes harder as the gauge fills. */
    private static void shake(LocalPlayer p, Entity lz) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        float baseYaw = lz.getYRot() + 180f;
        double dy = (lz.getY() + LAZUR_HEAD_Y) - p.getEyeY();
        double dist = Math.max(0.3, Math.hypot(p.getX() - lz.getX(), p.getZ() - lz.getZ()));
        float basePitch = (float) -Math.toDegrees(Math.atan2(dy, dist));

        float amp = 1.3f + bar * 3.2f + kick;
        kick *= 0.72f;
        if (kick < 0.05f) kick = 0f;
        p.setYRot(baseYaw + (r.nextFloat() - 0.5f) * 2f * amp);
        p.setXRot(basePitch + (r.nextFloat() - 0.5f) * 2f * amp * 0.8f);
        p.setYHeadRot(baseYaw);
    }

    private static void readKeys(Minecraft mc) {
        KeyMapping[] keys = keys(mc);
        boolean[] pressed = new boolean[4];
        for (int i = 0; i < 4; i++) {
            boolean click = false;
            while (keys[i].consumeClick()) click = true;
            boolean down = keys[i].isDown();
            // a fresh press only: a held key (or OS key repeat) never counts again
            pressed[i] = !prevDown[i] && (click || down);
            prevDown[i] = down;
        }
        if (!hasPrompt || prompt == null) return; // presses between prompts are ignored

        age++;
        int code = -1;
        if (age > prompt.duration() + WINDOW_AFTER_TICKS) {
            code = LazurNet.R_MISS;
        } else {
            boolean right = pressed[prompt.key()], other = false;
            for (int i = 0; i < 4; i++) if (i != prompt.key() && pressed[i]) other = true;
            if (other) code = LazurNet.R_WRONG_KEY;
            else if (right) code = age < prompt.winStart() ? LazurNet.R_EARLY : LazurNet.R_HIT;
        }
        if (code < 0) return;

        ClientPlayNetworking.send(new LazurNet.GrabResult(prompt.id(), code));
        flashTicks = 8;
        flashCode = code;
        flashX = prompt.x();
        flashY = prompt.y();
        if (code != LazurNet.R_HIT) kick = 5f;
        hasPrompt = false;
        prompt = null;
    }

    // =====================================================================================
    // HUD
    // =====================================================================================
    private static void extract(GuiGraphicsExtractor g, DeltaTracker delta) {
        if (!active) return;
        Minecraft mc = Minecraft.getInstance();
        var win = mc.getWindow();
        int sw = win.getGuiScaledWidth(), sh = win.getGuiScaledHeight();
        float pt = delta.getGameTimeDeltaPartialTick(false);

        drawBar(g, sw, sh);
        if (hasPrompt && prompt != null) drawPrompt(g, mc, sw, sh, pt);
        else if (flashTicks > 0) drawFlash(g, sw, sh);
    }

    private static void drawBar(GuiGraphicsExtractor g, int sw, int sh) {
        int w = Math.max(80, (int) (sw * 0.38f));
        int h = 8;
        int x0 = (sw - w) / 2, y0 = sh - 38;
        float b = Math.max(0f, Math.min(1f, bar));
        g.fill(x0 - 2, y0 - 2, x0 + w + 2, y0 + h + 2, 0xFF000000);
        g.fill(x0 - 1, y0 - 1, x0 + w + 1, y0 + h + 1, 0xFF3A3A3A);
        g.fill(x0, y0, x0 + w, y0 + h, 0xFF101010);
        int fw = Math.round(w * b);
        if (fw > 0) g.fill(x0, y0, x0 + fw, y0 + h, mix(0xFF2E8CFF, 0xFFE01818, b)); // azure -> red
    }

    private static void drawPrompt(GuiGraphicsExtractor g, Minecraft mc, int sw, int sh, float pt) {
        int cx = Math.round(prompt.x() * sw), cy = Math.round(prompt.y() * sh);
        int r0 = 24;
        float t = Math.min(1f, (age + pt) / Math.max(1, prompt.duration()));
        float f = switch (prompt.curve()) {
            case 1 -> t * t;                       // speeds up
            case 2 -> 1f - (1f - t) * (1f - t);    // slows down
            default -> t;
        };
        int ringR = r0 + Math.round((prompt.startRadius() - r0) * (1f - f));

        disk(g, cx, cy, r0, 0xD0000000);
        ring(g, cx, cy, r0 + 1, 2, 0xFF2E8CFF);
        drawKey(g, mc, prompt.key(), cx, cy);
        ring(g, cx, cy, ringR + 3, 3, 0xFFEAF4FF);
    }

    private static void drawFlash(GuiGraphicsExtractor g, int sw, int sh) {
        int cx = Math.round(flashX * sw), cy = Math.round(flashY * sh);
        int a = Math.min(255, flashTicks * 32);
        int color = (a << 24) | (flashCode == LazurNet.R_HIT ? 0x3AE05A : 0xE02020);
        disk(g, cx, cy, 24 + (8 - flashTicks) * 2, color);
    }

    private static void drawKey(GuiGraphicsExtractor g, Minecraft mc, int key, int cx, int cy) {
        KeyMapping[] keys = keys(mc);
        String label = keys[key].getTranslatedKeyMessage().getString();
        String[] glyph = switch (label.toUpperCase()) {
            case "W" -> G_W;
            case "A" -> G_A;
            case "S" -> G_S;
            case "D" -> G_D;
            default -> null;
        };
        if (glyph == null) { // rebound to something else: plain text
            g.text(mc.font, label, cx - mc.font.width(label) / 2, cy - 4, 0xFFFFFFFF, true);
            return;
        }
        int c = 3;                       // pixel size
        int x0 = cx - (5 * c) / 2, y0 = cy - (7 * c) / 2;
        for (int row = 0; row < 7; row++) {
            for (int col = 0; col < 5; col++) {
                if (glyph[row].charAt(col) == 'X') {
                    g.fill(x0 + col * c, y0 + row * c, x0 + col * c + c, y0 + row * c + c, 0xFFFFFFFF);
                }
            }
        }
    }

    // ---- shapes made of fill() rows, so no transforms or textures are needed ----
    private static void disk(GuiGraphicsExtractor g, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int hw = (int) Math.sqrt((double) r * r - (double) dy * dy);
            g.fill(cx - hw, cy + dy, cx + hw + 1, cy + dy + 1, color);
        }
    }

    private static void ring(GuiGraphicsExtractor g, int cx, int cy, int rOuter, int thick, int color) {
        int rIn = Math.max(0, rOuter - thick);
        for (int dy = -rOuter; dy <= rOuter; dy++) {
            int ho = (int) Math.sqrt((double) rOuter * rOuter - (double) dy * dy);
            if (Math.abs(dy) >= rIn) {
                g.fill(cx - ho, cy + dy, cx + ho + 1, cy + dy + 1, color);
            } else {
                int hi = (int) Math.sqrt((double) rIn * rIn - (double) dy * dy);
                g.fill(cx - ho, cy + dy, cx - hi, cy + dy + 1, color);
                g.fill(cx + hi + 1, cy + dy, cx + ho + 1, cy + dy + 1, color);
            }
        }
    }

    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int gr = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (gr << 8) | bl;
    }
}
