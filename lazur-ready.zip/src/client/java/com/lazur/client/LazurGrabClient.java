package com.lazur.client;

import com.lazur.LazurMod;
import com.lazur.net.LazurNet;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.CameraType;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Client side of the grab: holds the camera and the player in front of Lazur's face, shakes the camera,
 * draws the gauge + the prompts (only keys and the shrinking ring, no text), judges the key presses and reports
 * the result of each prompt to the server. The server decides everything else.
 */
public final class LazurGrabClient {
    private LazurGrabClient() {}

    private static final int WINDOW_AFTER_TICKS = 2;   // a press this late after the ring closed still counts
    private static final float LAZUR_HEAD_Y = 2.78f;   // centre of Lazur's head above his feet
    private static final float PLAYER_EYE_Y = 1.62f;

    // ---- session ----
    private static boolean active;
    private static int lazurId, missingTicks;
    private static float bar;
    private static CameraType savedCamera;               // camera the player had before the grab
    private static int glitchTick;
    private static float kick;                          // extra camera shake after a mistake
    private static final boolean[] prevDown = new boolean[4];

    // ---- current prompt ----
    private static boolean hasPrompt;
    private static LazurNet.GrabPrompt prompt;
    private static int age;

    // ---- cave form is being stared at ----
    private static int caveId, caveStale;
    private static float caveStrength, caveYawOff, cavePitchOff;

    // ---- result flash ----
    private static int flashTicks, flashCode;
    private static float flashX, flashY;

    // pixel glyphs (5 x 7) for W A S D, so the key is big and clear without a scaled font
    private static final String[] G_W = {"X...X", "X...X", "X...X", "X.X.X", "X.X.X", "XX.XX", "X...X"};
    private static final String[] G_A = {".XXX.", "X...X", "X...X", "XXXXX", "X...X", "X...X", "X...X"};
    private static final String[] G_S = {".XXXX", "X....", "X....", ".XXX.", "....X", "....X", "XXXX."};
    private static final String[] G_D = {"XXXX.", "X...X", "X...X", "X...X", "X...X", "X...X", "XXXX."};

    public static void init() {
        ClientPlayNetworking.registerGlobalReceiver(LazurNet.GrabStart.TYPE, (payload, context) -> start(payload.lazurId()));
        ClientPlayNetworking.registerGlobalReceiver(LazurNet.GrabState.TYPE, (payload, context) -> bar = payload.bar());
        ClientPlayNetworking.registerGlobalReceiver(LazurNet.GrabPrompt.TYPE, (payload, context) -> {
            if (!active) return;
            prompt = payload;
            hasPrompt = true;
            age = 0;
        });
        ClientPlayNetworking.registerGlobalReceiver(LazurNet.GrabEnd.TYPE, (payload, context) -> end(payload.mode()));
        ClientPlayNetworking.registerGlobalReceiver(LazurNet.CaveGaze.TYPE, (payload, context) -> {
            caveId = payload.lazurId();
            caveStrength = payload.strength();
            caveStale = 0;
        });

        ClientTickEvents.END_CLIENT_TICK.register(LazurGrabClient::tick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> reset());
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, LazurMod.id("grab"), LazurGrabClient::extract);
    }

    // =====================================================================================
    // session
    // =====================================================================================
    private static void start(int id) {
        Minecraft mc = Minecraft.getInstance();
        reset();
        active = true;
        lazurId = id;
        savedCamera = mc.options.getCameraType();
        mc.options.setCameraType(CameraType.FIRST_PERSON); // forced first person while held
        // keys that are already held when the grab starts must not count as presses
        KeyMapping[] keys = keys(mc);
        for (int i = 0; i < 4; i++) {
            while (keys[i].consumeClick()) { /* drain */ }
            prevDown[i] = keys[i].isDown();
        }
    }

    private static void reset() {
        caveStrength = 0f;
        restoreFov(Minecraft.getInstance());
        if (active && savedCamera != null) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.options != null) mc.options.setCameraType(savedCamera);
        }
        savedCamera = null;
        active = false;
        hasPrompt = false;
        prompt = null;
        bar = 0f;
        kick = 0f;
        missingTicks = 0;
        flashTicks = 0;
    }

    private static void end(int mode) {
        Minecraft mc = Minecraft.getInstance();
        if (active && mode == LazurNet.END_RELEASED && mc.player != null && mc.level != null) {
            // let go: a push away from Lazur so the 1.5 s head start is not spent on getting up
            Entity lz = mc.level.getEntity(lazurId);
            if (lz != null) {
                Vec3 away = mc.player.position().subtract(lz.position());
                double len = Math.hypot(away.x, away.z);
                if (len > 1.0E-4) {
                    mc.player.setDeltaMovement(away.x / len * 0.55, 0.25, away.z / len * 0.55);
                }
            }
        }
        reset();
    }

    private static KeyMapping[] keys(Minecraft mc) {
        var o = mc.options;
        return new KeyMapping[]{o.keyUp, o.keyLeft, o.keyDown, o.keyRight};
    }

    // =====================================================================================
    // tick: hold, shake, read keys
    // =====================================================================================
    private static void tick(Minecraft mc) {
        if (!active) { caveTick(mc); return; }
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || !p.isAlive()) {
            reset();
            return;
        }
        Entity lz = mc.level.getEntity(lazurId);
        if (lz == null) {
            if (++missingTicks > 60) reset();
            return;
        }
        missingTicks = 0;

        if (mc.options.getCameraType() != CameraType.FIRST_PERSON) mc.options.setCameraType(CameraType.FIRST_PERSON);
        glitchTick++;
        hold(mc, p, lz);
        shake(p, lz);
        readKeys(mc);
        if (flashTicks > 0) flashTicks--;
    }

    private static Integer savedFov;

    private static void restoreFov(Minecraft mc) {
        if (savedFov != null && mc.options != null) {
            try { mc.options.fov().set(savedFov); } catch (Exception ignored) { }
        }
        savedFov = null;
    }

    /**
     * The cave form's head is turning: the CAMERA (only the view, the player is not moved) locks onto his head
     * and slowly zooms in on him (strength 0..1 = progress of the turn, from the server).
     */
    private static void caveTick(Minecraft mc) {
        if (caveStrength <= 0f) { caveYawOff = cavePitchOff = 0f; restoreFov(mc); return; }
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || !p.isAlive() || ++caveStale > 10) {
            caveStrength = 0f;
            restoreFov(mc);
            return;
        }
        Entity lz = mc.level.getEntity(caveId);
        if (lz == null) return;
        float s = caveStrength;

        double dx = lz.getX() - p.getX(), dz = lz.getZ() - p.getZ();
        double dy = (lz.getY() + lz.getBbHeight() * 0.9) - p.getEyeY();
        double dist = Math.max(0.3, Math.hypot(dx, dz));

        // the view is fixed on his head (a strong pull every tick, so mouse movement cannot take it away)
        float wantYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float wantPitch = (float) -Math.toDegrees(Math.atan2(dy, dist));
        float k = 0.55f;
        float yaw = p.getYRot() + Mth.wrapDegrees(wantYaw - p.getYRot()) * k;
        float pitch = p.getXRot() + (wantPitch - p.getXRot()) * k;
        p.setYRot(yaw);
        p.setXRot(Mth.clamp(pitch, -90f, 90f));

        // "approaching": the field of view narrows step by step, so he grows in the picture (the player stays where he is)
        if (savedFov == null) savedFov = mc.options.fov().get();
        float ease = s * s * (3f - 2f * s);
        int fov = Math.round(savedFov - (savedFov - 30) * ease);
        try { mc.options.fov().set(Math.max(30, fov)); } catch (Exception ignored) { }
    }

    /** The player hangs in front of Lazur's face (eyes at the height of his head). */
    private static void hold(Minecraft mc, LocalPlayer p, Entity lz) {
        double yaw = Math.toRadians(lz.getYRot());
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);
        double[] dists = {com.lazur.LazurConfig.get().grabHoldDistance, 1.0, 0.75};
        double[] heights = {LAZUR_HEAD_Y - PLAYER_EYE_Y, 0.7, 0.2, 0.0};
        for (double dist : dists) {
            for (double h : heights) {
                double x = lz.getX() + fx * dist, y = lz.getY() + h, z = lz.getZ() + fz * dist;
                var box = p.getBoundingBox().move(x - p.getX(), y - p.getY(), z - p.getZ());
                if (mc.level.noCollision(p, box)) {
                    p.setPos(x, y, z);
                    p.setDeltaMovement(Vec3.ZERO);
                    p.resetFallDistance();
                    return;
                }
            }
        }
        p.setDeltaMovement(Vec3.ZERO);   // no free spot at all: at least do not move
        p.resetFallDistance();
    }

    /** The camera is locked on Lazur's face and shakes harder as the gauge fills. */
    private static void shake(LocalPlayer p, Entity lz) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        float baseYaw = lz.getYRot() + 180f;
        double dy = (lz.getY() + LAZUR_HEAD_Y) - p.getEyeY();
        double dist = Math.max(0.3, Math.hypot(p.getX() - lz.getX(), p.getZ() - lz.getZ()));
        float basePitch = (float) -Math.toDegrees(Math.atan2(dy, dist));

        float amp = 1.3f + bar * 3.2f + kick;
        kick *= 0.72f;
        if (kick < 0.05f) kick = 0f;
        p.setYRot(baseYaw + (r.nextFloat() - 0.5f) * 2f * amp);
        p.setXRot(basePitch + (r.nextFloat() - 0.5f) * 2f * amp * 0.8f);
        p.setYHeadRot(baseYaw);
    }

    private static void readKeys(Minecraft mc) {
        KeyMapping[] keys = keys(mc);
        boolean[] pressed = new boolean[4];
        for (int i = 0; i < 4; i++) {
            boolean click = false;
            while (keys[i].consumeClick()) click = true;
            boolean down = keys[i].isDown();
            // a fresh press only: a held key (or OS key repeat) never counts again
            pressed[i] = !prevDown[i] && (click || down);
            prevDown[i] = down;
        }
        if (!hasPrompt || prompt == null) return; // presses between prompts are ignored

        age++;
        int code = -1;
        if (age > prompt.duration() + WINDOW_AFTER_TICKS) {
            code = LazurNet.R_MISS;
        } else {
            boolean right = pressed[prompt.key()], other = false;
            for (int i = 0; i < 4; i++) if (i != prompt.key() && pressed[i]) other = true;
            if (other) code = LazurNet.R_WRONG_KEY;
            else if (right) code = age < prompt.winStart() ? LazurNet.R_EARLY : LazurNet.R_HIT;
        }
        if (code < 0) return;

        ClientPlayNetworking.send(new LazurNet.GrabResult(prompt.id(), code));
        flashTicks = 8;
        flashCode = code;
        flashX = prompt.x();
        flashY = prompt.y();
        if (code != LazurNet.R_HIT) kick = 5f;
        hasPrompt = false;
        prompt = null;
    }

    // =====================================================================================
    // HUD
    // =====================================================================================
    private static void extract(GuiGraphicsExtractor g, DeltaTracker delta) {
        if (!active) return;
        Minecraft mc = Minecraft.getInstance();
        var win = mc.getWindow();
        int sw = win.getGuiScaledWidth(), sh = win.getGuiScaledHeight();
        float pt = delta.getGameTimeDeltaPartialTick(false);

        drawGlitch(g, sw, sh);
        drawBar(g, sw, sh);
        if (hasPrompt && prompt != null) drawPrompt(g, mc, sw, sh, pt);
        else if (flashTicks > 0) drawFlash(g, sw, sh);
    }

    private static void drawBar(GuiGraphicsExtractor g, int sw, int sh) {
        int w = Math.max(80, (int) (sw * 0.38f));
        int h = 8;
        int x0 = (sw - w) / 2, y0 = sh - 38;
        float b = Math.max(0f, Math.min(1f, bar));
        g.fill(x0 - 2, y0 - 2, x0 + w + 2, y0 + h + 2, 0xFF000000);
        g.fill(x0 - 1, y0 - 1, x0 + w + 1, y0 + h + 1, 0xFF3A3A3A);
        g.fill(x0, y0, x0 + w, y0 + h, 0xFF101010);
        int fw = Math.round(w * b);
        if (fw > 0) g.fill(x0, y0, x0 + fw, y0 + h, mix(0xFF2E8CFF, 0xFFE01818, b)); // azure -> red
    }

    private static void drawPrompt(GuiGraphicsExtractor g, Minecraft mc, int sw, int sh, float pt) {
        int cx = Math.round(prompt.x() * sw), cy = Math.round(prompt.y() * sh);
        int h0 = 24;                                   // half side of the key
        float t = Math.min(1f, (age + pt) / Math.max(1, prompt.duration()));
        float f = switch (prompt.curve()) {
            case 1 -> t * t;                       // speeds up
            case 2 -> 1f - (1f - t) * (1f - t);    // slows down
            default -> t;
        };
        int ringH = h0 + Math.round((prompt.startRadius() - h0) * (1f - f));

        drawKeyCap(g, cx, cy, h0);
        drawKey(g, mc, prompt.key(), cx, cy);
        frame(g, cx, cy, ringH + 4, 3, 0xFFEAEAEA);    // the shrinking square frame
    }

    private static void drawFlash(GuiGraphicsExtractor g, int sw, int sh) {
        int cx = Math.round(flashX * sw), cy = Math.round(flashY * sh);
        int a = Math.min(255, flashTicks * 32);
        int color = (a << 24) | (flashCode == LazurNet.R_HIT ? 0x3AE05A : 0xE02020);
        int h = 24 + (8 - flashTicks) * 2;
        g.fill(cx - h, cy - h, cx + h, cy + h, color);
    }

    /** Square grey key with a simple bevel. */
    private static void drawKeyCap(GuiGraphicsExtractor g, int cx, int cy, int h) {
        g.fill(cx - h - 2, cy - h - 2, cx + h + 2, cy + h + 2, 0xFF141414);   // outline
        g.fill(cx - h, cy - h, cx + h, cy + h, 0xFF8C8C8C);                    // body
        g.fill(cx - h, cy - h, cx + h, cy - h + 3, 0xFFC2C2C2);                // light top
        g.fill(cx - h, cy - h, cx - h + 3, cy + h, 0xFFB0B0B0);                // light left
        g.fill(cx - h, cy + h - 3, cx + h, cy + h, 0xFF5E5E5E);                // dark bottom
        g.fill(cx + h - 3, cy - h, cx + h, cy + h, 0xFF6C6C6C);                // dark right
    }

    private static void drawKey(GuiGraphicsExtractor g, Minecraft mc, int key, int cx, int cy) {
        KeyMapping[] keys = keys(mc);
        String label = keys[key].getTranslatedKeyMessage().getString();
        String[] glyph = switch (label.toUpperCase()) {
            case "W" -> G_W;
            case "A" -> G_A;
            case "S" -> G_S;
            case "D" -> G_D;
            default -> null;
        };
        if (glyph == null) { // rebound to something else: plain text
            g.text(mc.font, label, cx - mc.font.width(label) / 2, cy - 4, 0xFF1C1C1C, false);
            return;
        }
        int c = 4;                       // pixel size
        int x0 = cx - (5 * c) / 2, y0 = cy - (7 * c) / 2;
        for (int row = 0; row < 7; row++) {
            for (int col = 0; col < 5; col++) {
                if (glyph[row].charAt(col) == 'X') {
                    g.fill(x0 + col * c, y0 + row * c, x0 + col * c + c, y0 + row * c + c, 0xFF1C1C1C);
                }
            }
        }
    }

    private static void frame(GuiGraphicsExtractor g, int cx, int cy, int h, int t, int color) {
        g.fill(cx - h, cy - h, cx + h, cy - h + t, color);
        g.fill(cx - h, cy + h - t, cx + h, cy + h, color);
        g.fill(cx - h, cy - h + t, cx - h + t, cy + h - t, color);
        g.fill(cx + h - t, cy - h + t, cx + h, cy + h - t, color);
    }

    /**
     * Pixel glitch noise over the whole screen: blocky pixel clusters, torn horizontal bands and a few
     * flashes, all snapped to a coarse grid and re-rolled every 2 ticks. Gets denser as the gauge fills.
     */
    private static void drawGlitch(GuiGraphicsExtractor g, int sw, int sh) {
        Random r = new Random((glitchTick / 2) * 7919L + 17L);
        float k = 0.3f + Math.max(0f, Math.min(1f, bar)) * 0.5f; // fewer glitches than before
        int[] palette = {0xFFFFFFFF, 0xFFEAEAEA, 0xFF0A0A0A, 0xFF000000, 0xFF7A7A7A, 0xFFBDBDBD}; // black and white only
        int cell = 6;

        // pixel clusters
        int clusters = (int) (7 * k);
        for (int i = 0; i < clusters; i++) {
            int cxp = r.nextInt(Math.max(1, sw / cell)) * cell, cyp = r.nextInt(Math.max(1, sh / cell)) * cell;
            int n = 4 + r.nextInt(18);
            for (int j = 0; j < n; j++) {
                int x = cxp + (r.nextInt(9) - 4) * cell, y = cyp + (r.nextInt(7) - 3) * cell;
                int c = (r.nextInt(3) == 0 ? 0xFF : 0xB0) << 24 | (palette[r.nextInt(palette.length)] & 0xFFFFFF);
                int w = cell * (1 + r.nextInt(2));
                g.fill(x, y, x + w, y + cell, c);
            }
        }
        // torn horizontal bands
        int bands = (int) (2 * k) + (r.nextInt(4) == 0 ? 2 : 0);
        for (int i = 0; i < bands; i++) {
            int y = r.nextInt(Math.max(1, sh));
            int x = r.nextInt(Math.max(1, sw));
            int w = 30 + r.nextInt(Math.max(1, sw / 2));
            int hh = 2 + r.nextInt(8);
            int c = (0x70 + r.nextInt(0x60)) << 24 | (palette[r.nextInt(palette.length)] & 0xFFFFFF);
            g.fill(x, y, Math.min(sw, x + w), y + hh, c);
            if (r.nextBoolean()) g.fill(Math.max(0, x - 40), y + hh, x, y + hh + 2, 0x90000000 | (palette[1] & 0xFFFFFF));
        }
        // rare short flash of a big block
        if (r.nextInt(14) == 0) {
            int x = r.nextInt(Math.max(1, sw - 40)), y = r.nextInt(Math.max(1, sh - 40));
            g.fill(x, y, x + 20 + r.nextInt(80), y + 10 + r.nextInt(50), 0x40000000 | (palette[r.nextInt(2)] & 0xFFFFFF));
        }
    }

    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int gr = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (gr << 8) | bl;
    }
}
