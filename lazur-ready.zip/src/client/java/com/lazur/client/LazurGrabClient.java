package com.lazur.client;

import com.lazur.LazurMod;
import com.lazur.net.LazurNet;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.CameraType;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Client side of the grab: holds the camera and the player in front of Lazur's face, shakes the camera,
 * draws the line of keys and the air gauge (no text) and reports every fresh W/A/S/D press to the server,
 * which judges it. The server decides everything else.
 */
public final class LazurGrabClient {
    private LazurGrabClient() {}

    private static final float LAZUR_HEAD_Y = 2.78f;   // centre of Lazur's head above his feet
    private static final float PLAYER_EYE_Y = 1.62f;
    private static final int VISIBLE_KEYS = 5;          // at most this many keys of the line are readable, the rest are blurred
    private static final int KEY_HALF = 13;             // half side of a key cap (GUI pixels)
    private static final int KEY_GAP = 5;

    // ---- session ----
    private static boolean active;
    private static int lazurId, missingTicks;
    private static int[] line = new int[0];
    private static int done, errors, totalTicks;
    private static float air = 1f;                      // 1 = full, 0 = empty
    private static CameraType savedCamera;               // camera the player had before the grab
    private static int glitchTick;
    private static float kick;                          // extra camera shake after a mistake
    private static float shift;                         // slide of the key line after a correct key (GUI pixels)
    private static int flashTicks;
    private static final boolean[] prevDown = new boolean[4];

    // ---- cave form is being stared at ----
    private static int caveId, caveStale;
    private static float caveStrength, caveYawOff, cavePitchOff;
    private static Boolean savedHideGui;

    // pixel glyphs (5 x 7) for W A S D, so the key is big and clear without a scaled font
    private static final String[] G_W = {"X...X", "X...X", "X...X", "X.X.X", "X.X.X", "XX.XX", "X...X"};
    private static final String[] G_A = {".XXX.", "X...X", "X...X", "XXXXX", "X...X", "X...X", "X...X"};
    private static final String[] G_S = {".XXXX", "X....", "X....", ".XXX.", "....X", "....X", "XXXX."};
    private static final String[] G_D = {"XXXX.", "X...X", "X...X", "X...X", "X...X", "X...X", "XXXX."};

    public static void init() {
        ClientPlayNetworking.registerGlobalReceiver(LazurNet.GrabStart.TYPE,
                (payload, context) -> start(payload.lazurId(), payload.keys(), payload.totalTicks()));
        ClientPlayNetworking.registerGlobalReceiver(LazurNet.GrabState.TYPE, (payload, context) -> {
            if (!active) return;
            air = payload.air();
            if (payload.done() > done) shift = KEY_HALF * 2 + KEY_GAP;   // a correct key: the line slides one cap to the left
            if (payload.errors() > errors) { kick = 5f; flashTicks = 8; } // a wrong key
            done = payload.done();
            errors = payload.errors();
        });
        ClientPlayNetworking.registerGlobalReceiver(LazurNet.GrabEnd.TYPE, (payload, context) -> end(payload.mode()));
        ClientPlayNetworking.registerGlobalReceiver(LazurNet.CaveGaze.TYPE, (payload, context) -> {
            caveId = payload.lazurId();
            caveStrength = payload.strength();
            caveStale = 0;
        });

        ClientTickEvents.END_CLIENT_TICK.register(LazurGrabClient::tick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> reset());
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, LazurMod.id("grab"), LazurGrabClient::extract);
    }

    // =====================================================================================
    // session
    // =====================================================================================
    private static void start(int id, int[] seq, int total) {
        Minecraft mc = Minecraft.getInstance();
        reset();
        active = true;
        lazurId = id;
        line = seq;
        totalTicks = total;
        air = 1f;
        savedCamera = mc.options.getCameraType();
        mc.options.setCameraType(CameraType.FIRST_PERSON); // forced first person while held
        // keys that are already held when the grab starts must not count as presses
        KeyMapping[] keys = keys(mc);
        for (int i = 0; i < 4; i++) {
            while (keys[i].consumeClick()) { /* drain */ }
            prevDown[i] = keys[i].isDown();
        }
    }

    private static void reset() {
        caveStrength = 0f;
        restoreFov(Minecraft.getInstance());
        if (active && savedCamera != null) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.options != null) mc.options.setCameraType(savedCamera);
        }
        savedCamera = null;
        active = false;
        line = new int[0];
        done = 0;
        errors = 0;
        air = 1f;
        shift = 0f;
        kick = 0f;
        missingTicks = 0;
        flashTicks = 0;
    }

    private static void end(int mode) {
        Minecraft mc = Minecraft.getInstance();
        if (active && mode == LazurNet.END_RELEASED && mc.player != null && mc.level != null) {
            // let go: a push away from Lazur so the 1.5 s head start is not spent on getting up
            Entity lz = mc.level.getEntity(lazurId);
            if (lz != null) {
                Vec3 away = mc.player.position().subtract(lz.position());
                double len = Math.hypot(away.x, away.z);
                if (len > 1.0E-4) {
                    mc.player.setDeltaMovement(away.x / len * 0.55, 0.25, away.z / len * 0.55);
                }
            }
        }
        reset();
    }

    private static KeyMapping[] keys(Minecraft mc) {
        var o = mc.options;
        return new KeyMapping[]{o.keyUp, o.keyLeft, o.keyDown, o.keyRight};
    }

    // =====================================================================================
    // tick: hold, shake, read keys
    // =====================================================================================
    private static void tick(Minecraft mc) {
        if (!active) { caveTick(mc); return; }
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || !p.isAlive()) {
            reset();
            return;
        }
        Entity lz = mc.level.getEntity(lazurId);
        if (lz == null) {
            if (++missingTicks > 60) reset();
            return;
        }
        missingTicks = 0;

        if (mc.options.getCameraType() != CameraType.FIRST_PERSON) mc.options.setCameraType(CameraType.FIRST_PERSON);
        glitchTick++;
        hold(mc, p, lz);
        shake(p, lz);
        readKeys(mc);
        if (flashTicks > 0) flashTicks--;
    }

    private static Integer savedFov;

    private static void restoreFov(Minecraft mc) {
        if (savedFov != null && mc.options != null) {
            try { mc.options.fov().set(savedFov); } catch (Exception ignored) { }
        }
        savedFov = null;
        if (savedHideGui != null && mc.options != null) { // the interface and the hand come back (F1 off)
            mc.options.hideGui = savedHideGui;
        }
        savedHideGui = null;
    }

    /**
     * The cave form's head is turning: the CAMERA (only the view, the player is not moved) locks onto his head
     * and slowly zooms in on him (strength 0..1 = progress of the turn, from the server).
     */
    private static void caveTick(Minecraft mc) {
        if (caveStrength <= 0f) { caveYawOff = cavePitchOff = 0f; restoreFov(mc); return; }
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || !p.isAlive() || ++caveStale > 10) {
            caveStrength = 0f;
            restoreFov(mc);
            return;
        }
        Entity lz = mc.level.getEntity(caveId);
        if (lz == null) return;
        float s = caveStrength;

        double dx = lz.getX() - p.getX(), dz = lz.getZ() - p.getZ();
        double dy = (lz.getY() + lz.getBbHeight() * 0.9) - p.getEyeY();
        double dist = Math.max(0.3, Math.hypot(dx, dz));

        // the view is fixed on his head (a strong pull every tick, so mouse movement cannot take it away)
        float wantYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float wantPitch = (float) -Math.toDegrees(Math.atan2(dy, dist));
        float k = 0.55f;
        float yaw = p.getYRot() + Mth.wrapDegrees(wantYaw - p.getYRot()) * k;
        float pitch = p.getXRot() + (wantPitch - p.getXRot()) * k;
        p.setYRot(yaw);
        p.setXRot(Mth.clamp(pitch, -90f, 90f));

        // like F1: the interface and the hand are hidden for the whole head turn
        if (savedHideGui == null) savedHideGui = mc.options.hideGui;
        mc.options.hideGui = true;

        // "approaching": the field of view narrows step by step, so he grows in the picture (the player stays where he is)
        if (savedFov == null) savedFov = mc.options.fov().get();
        float ease = s * s * (3f - 2f * s);
        int fov = Math.round(savedFov - (savedFov - 30) * ease);
        try { mc.options.fov().set(Math.max(30, fov)); } catch (Exception ignored) { }
    }

    /** The player hangs in front of Lazur's face (eyes at the height of his head). */
    private static void hold(Minecraft mc, LocalPlayer p, Entity lz) {
        double yaw = Math.toRadians(lz.getYRot());
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);
        double[] dists = {com.lazur.LazurConfig.get().grabHoldDistance, 1.0, 0.75};
        double[] heights = {LAZUR_HEAD_Y - PLAYER_EYE_Y, 0.7, 0.2, 0.0};
        for (double dist : dists) {
            for (double h : heights) {
                double x = lz.getX() + fx * dist, y = lz.getY() + h, z = lz.getZ() + fz * dist;
                var box = p.getBoundingBox().move(x - p.getX(), y - p.getY(), z - p.getZ());
                if (mc.level.noCollision(p, box)) {
                    p.setPos(x, y, z);
                    p.setDeltaMovement(Vec3.ZERO);
                    p.resetFallDistance();
                    return;
                }
            }
        }
        p.setDeltaMovement(Vec3.ZERO);   // no free spot at all: at least do not move
        p.resetFallDistance();
    }

    /** The camera is locked on Lazur's face and shakes harder as the gauge fills. */
    private static void shake(LocalPlayer p, Entity lz) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        float baseYaw = lz.getYRot() + 180f;
        double dy = (lz.getY() + LAZUR_HEAD_Y) - p.getEyeY();
        double dist = Math.max(0.3, Math.hypot(p.getX() - lz.getX(), p.getZ() - lz.getZ()));
        float basePitch = (float) -Math.toDegrees(Math.atan2(dy, dist));

        float amp = 1.3f + (1f - air) * 3.2f + kick;
        kick *= 0.72f;
        if (kick < 0.05f) kick = 0f;
        p.setYRot(baseYaw + (r.nextFloat() - 0.5f) * 2f * amp);
        p.setXRot(basePitch + (r.nextFloat() - 0.5f) * 2f * amp * 0.8f);
        p.setYHeadRot(baseYaw);
    }

    /** A fresh press of W/A/S/D is sent to the server, which judges it (right key, wrong key, still being lifted). */
    private static void readKeys(Minecraft mc) {
        KeyMapping[] k = keys(mc);
        for (int i = 0; i < 4; i++) {
            boolean click = false;
            while (k[i].consumeClick()) click = true;
            boolean down = k[i].isDown();
            // a fresh press only: a held key (or OS key repeat) never counts again
            boolean pressed = !prevDown[i] && (click || down);
            prevDown[i] = down;
            if (pressed && done < line.length) ClientPlayNetworking.send(new LazurNet.GrabKey(i));
        }
        shift *= 0.62f;
        if (shift < 0.3f) shift = 0f;
    }

    // =====================================================================================
    // HUD
    // =====================================================================================
    private static void extract(GuiGraphicsExtractor g, DeltaTracker delta) {
        if (!active) return;
        Minecraft mc = Minecraft.getInstance();
        var win = mc.getWindow();
        int sw = win.getGuiScaledWidth(), sh = win.getGuiScaledHeight();

        drawGlitch(g, sw, sh);
        drawAir(g, sw, sh);
        drawKeyLine(g, mc, sw, sh);
        if (flashTicks > 0) { // a wrong key: the whole screen blinks red for a moment
            int a = Math.min(255, flashTicks * 14);
            g.fill(0, 0, sw, sh, (a << 24) | 0xC01010);
        }
    }

    /** The line of keys above the hotbar: the first 5 are readable, the rest are blurred until the line moves on. */
    private static void drawKeyLine(GuiGraphicsExtractor g, Minecraft mc, int sw, int sh) {
        int remaining = line.length - done;
        if (remaining <= 0) return;
        int step = KEY_HALF * 2 + KEY_GAP;
        int shown = Math.min(remaining, VISIBLE_KEYS + 4);            // a few blurred caps hint that there is more
        int cy = sh - 78;
        int total = Math.min(remaining, VISIBLE_KEYS) * step;
        int left = (sw - total) / 2 + KEY_HALF + Math.round(shift);
        for (int i = 0; i < shown; i++) {
            int cx = left + i * step;
            if (i < VISIBLE_KEYS) {
                drawKeyCap(g, cx, cy, KEY_HALF, i == 0);
                drawKey(g, mc, line[done + i], cx, cy);
            } else {
                drawBlurCap(g, cx, cy, KEY_HALF, i - VISIBLE_KEYS);
            }
        }
    }

    /** A cap nobody can read yet: pale, no letter, fading out towards the end of the line. */
    private static void drawBlurCap(GuiGraphicsExtractor g, int cx, int cy, int h, int n) {
        int a = Math.max(24, 120 - n * 28);
        g.fill(cx - h, cy - h, cx + h, cy + h, (a << 24) | 0x8C8C8C);
        g.fill(cx - h + 5, cy - 2, cx + h - 5, cy + 2, (a << 24) | 0x303030); // a smear instead of a letter
    }

    /** The "air" gauge on the right: bubbles that go out from the top as time runs out. */
    private static void drawAir(GuiGraphicsExtractor g, int sw, int sh) {
        int n = 10, size = 9, gap = 3;
        int x = sw - 26;
        int top = sh / 2 - (n * (size + gap)) / 2;
        int left = Math.max(0, Math.min(n, (int) Math.ceil(air * n)));
        boolean low = air < 0.3f;
        boolean blink = low && (glitchTick / 3) % 2 == 0;
        for (int i = 0; i < n; i++) {
            int y = top + i * (size + gap);
            boolean full = i >= n - left;                              // the bubbles at the top are lost first
            if (full) {
                int body = blink ? 0xFFE04040 : 0xFF8FD8FF;
                g.fill(x, y, x + size, y + size, 0xFF0B2A3C);                  // outline
                g.fill(x + 1, y + 1, x + size - 1, y + size - 1, body);
                g.fill(x + 2, y + 2, x + 4, y + 4, 0xFFFFFFFF);                // highlight
            } else {
                g.fill(x + 3, y + 3, x + size - 3, y + size - 3, 0x60303030);  // a popped bubble
            }
        }
    }

    /** Square grey key with a simple bevel. */
    private static void drawKeyCap(GuiGraphicsExtractor g, int cx, int cy, int h, boolean current) {
        g.fill(cx - h - 2, cy - h - 2, cx + h + 2, cy + h + 2, current ? 0xFFEAEAEA : 0xFF141414);   // outline (the key to press now is lit)
        g.fill(cx - h, cy - h, cx + h, cy + h, 0xFF8C8C8C);                    // body
        g.fill(cx - h, cy - h, cx + h, cy - h + 3, 0xFFC2C2C2);                // light top
        g.fill(cx - h, cy - h, cx - h + 3, cy + h, 0xFFB0B0B0);                // light left
        g.fill(cx - h, cy + h - 3, cx + h, cy + h, 0xFF5E5E5E);                // dark bottom
        g.fill(cx + h - 3, cy - h, cx + h, cy + h, 0xFF6C6C6C);                // dark right
    }

    private static void drawKey(GuiGraphicsExtractor g, Minecraft mc, int key, int cx, int cy) {
        KeyMapping[] keys = keys(mc);
        String label = keys[key].getTranslatedKeyMessage().getString();
        String[] glyph = switch (label.toUpperCase()) {
            case "W" -> G_W;
            case "A" -> G_A;
            case "S" -> G_S;
            case "D" -> G_D;
            default -> null;
        };
        if (glyph == null) { // rebound to something else: plain text
            g.text(mc.font, label, cx - mc.font.width(label) / 2, cy - 4, 0xFF1C1C1C, false);
            return;
        }
        int c = 2;                       // pixel size
        int x0 = cx - (5 * c) / 2, y0 = cy - (7 * c) / 2;
        for (int row = 0; row < 7; row++) {
            for (int col = 0; col < 5; col++) {
                if (glyph[row].charAt(col) == 'X') {
                    g.fill(x0 + col * c, y0 + row * c, x0 + col * c + c, y0 + row * c + c, 0xFF1C1C1C);
                }
            }
        }
    }

    private static void frame(GuiGraphicsExtractor g, int cx, int cy, int h, int t, int color) {
        g.fill(cx - h, cy - h, cx + h, cy - h + t, color);
        g.fill(cx - h, cy + h - t, cx + h, cy + h, color);
        g.fill(cx - h, cy - h + t, cx - h + t, cy + h - t, color);
        g.fill(cx + h - t, cy - h + t, cx + h, cy + h - t, color);
    }

    /**
     * Pixel glitch noise over the whole screen: blocky pixel clusters, torn horizontal bands and a few
     * flashes, all snapped to a coarse grid and re-rolled every 2 ticks. Gets denser as the gauge fills.
     */
    private static void drawGlitch(GuiGraphicsExtractor g, int sw, int sh) {
        Random r = new Random((glitchTick / 2) * 7919L + 17L);
        float k = 0.3f + Math.max(0f, Math.min(1f, 1f - air)) * 0.5f; // denser as the air runs out
        int[] palette = {0xFFFFFFFF, 0xFFEAEAEA, 0xFF0A0A0A, 0xFF000000, 0xFF7A7A7A, 0xFFBDBDBD}; // black and white only
        int cell = 6;

        // pixel clusters
        int clusters = (int) (7 * k);
        for (int i = 0; i < clusters; i++) {
            int cxp = r.nextInt(Math.max(1, sw / cell)) * cell, cyp = r.nextInt(Math.max(1, sh / cell)) * cell;
            int n = 4 + r.nextInt(18);
            for (int j = 0; j < n; j++) {
                int x = cxp + (r.nextInt(9) - 4) * cell, y = cyp + (r.nextInt(7) - 3) * cell;
                int c = (r.nextInt(3) == 0 ? 0xFF : 0xB0) << 24 | (palette[r.nextInt(palette.length)] & 0xFFFFFF);
                int w = cell * (1 + r.nextInt(2));
                g.fill(x, y, x + w, y + cell, c);
            }
        }
        // torn horizontal bands
        int bands = (int) (2 * k) + (r.nextInt(4) == 0 ? 2 : 0);
        for (int i = 0; i < bands; i++) {
            int y = r.nextInt(Math.max(1, sh));
            int x = r.nextInt(Math.max(1, sw));
            int w = 30 + r.nextInt(Math.max(1, sw / 2));
            int hh = 2 + r.nextInt(8);
            int c = (0x70 + r.nextInt(0x60)) << 24 | (palette[r.nextInt(palette.length)] & 0xFFFFFF);
            g.fill(x, y, Math.min(sw, x + w), y + hh, c);
            if (r.nextBoolean()) g.fill(Math.max(0, x - 40), y + hh, x, y + hh + 2, 0x90000000 | (palette[1] & 0xFFFFFF));
        }
        // rare short flash of a big block
        if (r.nextInt(14) == 0) {
            int x = r.nextInt(Math.max(1, sw - 40)), y = r.nextInt(Math.max(1, sh - 40));
            g.fill(x, y, x + 20 + r.nextInt(80), y + 10 + r.nextInt(50), 0x40000000 | (palette[r.nextInt(2)] & 0xFFFFFF));
        }
    }

    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int gr = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (gr << 8) | bl;
    }
}
