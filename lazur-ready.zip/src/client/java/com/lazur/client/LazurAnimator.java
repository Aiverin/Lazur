package com.lazur.client;

import com.lazur.entity.LazurEntity;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.Arrays;
import java.util.Random;

/**
 * Port of the prototype lazur-figure.html. Everything is computed in the prototype's space
 * (blocks, y up, character faces +z) and converted to model space at the end.
 * One instance per Lazur entity (kept by LazurRenderer). Client-only, render-only: the server knows nothing about it.
 */
public final class LazurAnimator {
    private static final float PI = (float) Math.PI;
    private static final float TP = PI * 2f;
    public static final float LEG = 1.7f, ARM = 1.85f;
    private static final float GRAV = 7f;

    // the "heavy" look (fixed values chosen in the preview): weight, stance width, bent legs, uneven steps
    private static final float W = .65f, WD = 1f, B = 1f, U = .59f;
    private static final float LOOSE = 1f - .35f * W;   // limbs and head lag a bit more behind the body
    private static final float LEG_GAP = .16f;          // how far a leg joint may be pushed back from the torso

    // smoothed channels
    private static final int CY = 0, BOB = 1, RX = 2, PR = 3, PT = 4, PP = 5, CL = 6, CT = 7, CR = 8,
            HX = 9, HY = 10, HZ = 11, SLX = 12, SRX = 13, SLZ = 14, SRZ = 15, HL = 16, HR = 17, N = 18;
    private static final float[] KS = {170, 130, 50, 55, 60, 60, 70, 70, 60, 70, 70, 70, 45, 45, 50, 50, 170, 170};

    private record Gait(float tc, float d, float hA, float cl, float r, float s, float y,
                        float lean, float hx, float arm, float drop, float kz) {}

    private static final Gait WALK = new Gait(2.4f, .64f, .46f, .18f, .10f, .07f, .18f, .16f, .40f, 1.0f, .12f, .04f);
    private static final Gait CREEP = new Gait(3.0f, .72f, .38f, .14f, .12f, .07f, .14f, .26f, .42f, .7f, .10f, .03f);
    private static final Gait RUN = new Gait(.7f, .42f, .50f, .16f, .08f, .05f, .20f, .34f, .10f, 1.0f, .12f, .04f);

    // strike keyframes: {cycle, shoulder x, chest lean, head x, bob}
    private static final float[][] KF = {
            {0f, 0f, 0f, 0f, 0f}, {.14f, .35f, .12f, .15f, -.08f}, {.42f, -2.62f, -.2f, -.5f, 0f},
            {.55f, -2.62f, -.2f, -.5f, 0f}, {.66f, -.07f, .45f, .45f, -.1f}, {1f, .05f, 0f, 0f, 0f}};

    private static final class Spring {
        final Vector3f p = new Vector3f();
        final Vector3f v = new Vector3f();
        boolean init;
    }

    // ---- outputs (model space; index: 0 torso, 1 head, 2 armL, 3 armR, 4 legL, 5 legR) ----
    public final float[][] pos = new float[6][3];
    public final float[][] rot = new float[6][3];
    public final float[][] scale = new float[6][2];
    public boolean visible = true;

    /** Head turn (radians) of the cave form while it is stared at: full turns forward with stalls and bursts of speed. */
    public float headSpin;
    private float spinLeft, spinSpeed;
    private final java.util.Random spinRnd = new java.util.Random();

    // ---- state ----
    private final float[] cur = new float[N], vel = new float[N], tgt = new float[N];
    private final Spring fc = new Spring(), fh = new Spring();
    private final Spring[] fa = {new Spring(), new Spring()}, ta = {new Spring(), new Spring()};
    private float t, st, stateTime, ghs = 1.7f, gh = 1.7f, gv, gvPrev, gvAcc, kz;
    private final float[] ftz = new float[2], ftyf = new float[2], ftw = new float[2];
    private final float[] legH = new float[2], legDy = new float[2], legDz = new float[2];
    private int lastState = -1;
    private float lastAge = Float.NaN;
    private double lastX, lastZ;
    private boolean hasPos;
    private float speed;
    private float spSmooth = 1f;
    private final float[] mountX = {.11f, .11f}, spl = {0f, 0f};
    private float prevFL, prevFR, impulse, wy, wv;
    // glitch
    private int gFrame = -1;
    private final float[] gJx = new float[6], gJy = new float[6], gSx = new float[6], gSy = new float[6];
    private float gRoot;
    private boolean gHide;
    // scratch
    private final Quaternionf tmpQ = new Quaternionf();
    private final Vector3f tmpV = new Vector3f();

    public LazurAnimator() {
        for (float[] s : scale) { s[0] = 1f; s[1] = 1f; }
    }

    /** Same function is used by the renderer to pick the azure texture on a few glitch frames. */
    /** Seconds since the current state started (the model uses it to time the strike of the player-sized form). */
    public float stateSeconds() { return stateTime; }

    public static boolean glitchBurst(float ageInTicks) {
        int frame = (int) (ageInTicks / (20f / 12f));
        long h = frame * 0x9E3779B97F4A7C15L;
        return ((h >>> 33) % 100) < 15; // fewer flashes of the alternate (grey) texture
    }

    // =========================================================================================
    public void update(LazurRenderState s) {
        float dt = Float.isNaN(lastAge) ? 0.016f : (s.ageInTicks - lastAge) / 20f;
        lastAge = s.ageInTicks;
        if (dt < 0f || dt > 0.3f) dt = 0.016f;
        if (dt < 1e-4f) return; // paused: keep the last pose

        if (hasPos) {
            double dx = s.x - lastX, dz = s.z - lastZ;
            float inst = (float) Math.min(12.0, Math.sqrt(dx * dx + dz * dz) / dt);
            speed += (inst - speed) * Math.min(1f, dt * 8f);
        }
        lastX = s.x; lastZ = s.z; hasPos = true;

        boolean stateChanged = s.lazurState != lastState;
        if (stateChanged) { lastState = s.lazurState; stateTime = 0f; } else stateTime += dt;
        if (stateChanged && s.lazurState == LazurEntity.S_SPIN_FULL) { headSpin = 0f; spinLeft = 0f; } // the committed turn starts from facing forward
        if (s.lazurState == LazurEntity.S_SPIN || s.lazurState == LazurEntity.S_SPIN_FULL) {
            spinLeft -= dt;
            if (spinLeft <= 0f) {                       // a new piece of the movement
                spinLeft = 0.04f + spinRnd.nextFloat() * 0.38f;
                float r = spinRnd.nextFloat();
                // always forward, never back: a full 360 turn takes about as long as the sound (4.3 s),
                // with random freezes (30 %) and bursts of speed in between
                float turn = (float) (Math.PI * 2.0 / 4.3);
                spinSpeed = r < 0.30f ? 0f : turn * (1.0f + spinRnd.nextFloat());
            }
            headSpin += spinSpeed * dt;
            if (s.lazurState == LazurEntity.S_SPIN_FULL) {
                // committed turn: stalls and bursts, but exactly ONE full turn in 4 s, ending facing forward
                float full = (float) (Math.PI * 2.0);
                headSpin = Math.min(full, Math.max(headSpin, full * (stateTime / 4.0f)));
            }
        } else {
            headSpin = 0f;
            spinSpeed = 0f;
            spinLeft = 0f;
        }
        step(dt, s.lazurState);
    }

    // stride parameters: slower, a bit shorter and with a longer double support than the raw Gait values
    private static float tcw(Gait q, boolean runG) { return q.tc() * (1f + .25f * W * (runG ? .5f : 1f)); }
    private static float dBase(Gait q) { return Math.min(.85f, q.d() + .04f * W); }
    private static float hAe(Gait q, boolean runG) { return q.hA() * (runG ? .70f : .62f); }
    private static float zmBase(Gait q, boolean runG) { return LEG * sin(hAe(q, runG) * (1f - .16f * W)); }

    private static float gaitSpeed(Gait q) {
        boolean runG = q == RUN;
        return 2f * zmBase(q, runG) / (dBase(q) * tcw(q, runG));
    }

    private void step(float dt, int state) {
        boolean run = state == LazurEntity.S_RUN;
        boolean attack = state == LazurEntity.S_ATTACK;
        boolean grab = state == LazurEntity.S_GRAB;
        boolean rigid = attack || grab;   // arms follow their target tightly (strike / holding the player)
        // the strike does not stop him: legs keep running (RUN gait), only the upper body does the strike
        boolean gaitState = run || attack || state == LazurEntity.S_WALK || state == LazurEntity.S_CREEP;
        Gait q = state == LazurEntity.S_WALK ? WALK : (state == LazurEntity.S_CREEP ? CREEP : RUN);

        t += dt;
        float spWanted = 1f; // standing still (e.g. /lazur anim run): play the gait at its normal tempo, in place
        if (gaitState && speed >= .3f) spWanted = clamp(speed / gaitSpeed(q), .25f, 3f); // phase follows real speed: planted feet do not slide
        spSmooth += (spWanted - spSmooth) * Math.min(1f, dt * 4f);
        float sp = gaitState ? spSmooth : 1f;
        st += dt * sp;
        target(state, sp, q);
        if (impulse != 0f) wv -= impulse;           // heel strike: the body drops and springs back
        {
            float kb = 110f, cb = 2f * .26f * (float) Math.sqrt(kb);
            int nb = Math.max(1, (int) Math.ceil(dt / .006f));
            float hb = dt / nb;
            for (int i = 0; i < nb; i++) { wv += (-wy * kb - wv * cb) * hb; wy += wv * hb; }
        }

        // ---- spring-smoothed channels ----
        float kq = (rigid || run) ? 2.4f : 1f;
        int sub = 2;
        float hs = dt / sub;
        for (int k = 0; k < sub; k++) {
            for (int i = 0; i < N; i++) {
                boolean fast = i == SLX || i == SRX || i == SLZ || i == SRZ || i == HX || i == HY || i == HZ;
                float kk = KS[i] * kq * (fast && !rigid ? LOOSE : 1f);
                float z = fast ? (rigid ? .85f : .45f - .1f * W) : (i == CY ? .4f : .8f);
                float damp = 2f * z * (float) Math.sqrt(kk);
                vel[i] += ((tgt[i] - cur[i]) * kk - vel[i] * damp) * hs;
                cur[i] += vel[i] * hs;
            }
        }
        ghs += (gh - ghs) * Math.min(1f, dt * 14f);

        // ---- legs: planted foot stays where the step put it, the hip joint moves ----
        float hipY = ghs + cur[BOB] + wy;
        float tb = .1f + cur[CY] - .06f;
        float sA = sin(Math.max(0f, cur[CL] + .03f)), cA = cos(cur[CL]);
        for (int i = 0; i < 2; i++) {
            float lz = ftz[i], yf = ftyf[i], w = ftw[i], cs = cos(spl[i]);
            float ph = (float) Math.sqrt(Math.max(0f, LEG * LEG - lz * lz)) * cs;
            float o = yf + ph - hipY - tb;
            float dz = 0f;
            if (o > -.05f) {
                float oo = Math.max(o, 0f);
                float n0 = (.28f + oo * sA) / cA;
                float n1 = (.28f - lz * oo / LEG) / (1f - oo / LEG);
                dz = Math.min(LEG_GAP, Math.max(0f, Math.max(n0, n1))) * ease((o + .05f) / .08f);
            }
            dz += kz * sin(PI * w);
            float zz = clamp(lz - dz, -.97f * LEG, .97f * LEG);
            ph = (float) Math.sqrt(LEG * LEG - zz * zz) * cs;
            legH[i] = -(float) Math.asin(zz / LEG);
            legDy[i] = yf + ph - hipY;
            legDz[i] = dz;
        }

        // ---- hierarchy (hips -> chest) ----
        Quaternionf hipsQ = new Quaternionf().rotateX(cur[PP]).rotateY(cur[PT]).rotateZ(cur[PR]);
        Vector3f hipsP = new Vector3f(0f, hipY, 0f);
        Quaternionf chestQ = new Quaternionf(hipsQ).mul(new Quaternionf().rotateX(cur[CL]).rotateY(cur[CT]).rotateZ(cur[CR]));
        Vector3f chestAnchor = new Vector3f(cur[RX], .1f + cur[CY], 0f).rotate(hipsQ).add(hipsP);

        // ---- physics: nothing is welded to the body ----
        gvAcc = clamp(-(gv - gvPrev) / dt, -25f, 25f);
        gvPrev = gv;
        float wz = rigid ? 0f : -gv * (run ? 1.2f : .5f) + gvAcc * .3f; // fake "wind": things trail behind
        float f = run ? 2.5f : 1f;

        follow(fc, chestAnchor, 160f * f, .5f, dt, .05f, 0f, 0f, wz * .25f);
        Vector3f chestP = new Vector3f(fc.p);

        Vector3f headAnchor = new Vector3f(0f, .78f, 0f).rotate(chestQ).add(chestP);
        if (rigid) follow(fh, headAnchor, 100f * f, .4f, dt, .05f, 0f, 0f, wz * .5f);
        else follow(fh, headAnchor, 70f * f, .32f, dt, .05f, 0f, 0f, wz * .5f);
        float dX = fh.p.x - headAnchor.x, dY = fh.p.y - headAnchor.y, dZ = fh.p.z - headAnchor.z;
        float tt = t % 50f; // constant head tremor, 25-45 Hz
        final float hj = 1.5f;                                   // head tremor strength
        float hx = cur[HX] + hj * (.02f * sin(tt * 173f) + .012f * sin(tt * 271f + 1f)) + dZ * 3f - dY * 1.5f;
        float hy = cur[HY] + hj * (.025f * sin(tt * 157f + 2f) + .012f * sin(tt * 239f));
        float hz = cur[HZ] + hj * (.018f * sin(tt * 193f + 4f)) - dX * 3f;
        Quaternionf headQ = new Quaternionf(chestQ).rotateX(hx).rotateY(hy).rotateZ(hz).rotateY(PI / 4f); // head is turned 45 deg

        // legs in the prototype's space (needed by the arm collision pass below)
        Vector3f[] legP = new Vector3f[2], legFoot = new Vector3f[2];
        Quaternionf[] legQ = new Quaternionf[2];
        for (int i = 0; i < 2; i++) {
            float side = i == 0 ? 1f : -1f;
            legP[i] = new Vector3f(mountX[i] * side, legDy[i], legDz[i]).rotate(hipsQ).add(hipsP);
            legQ[i] = new Quaternionf(hipsQ).rotateX(legH[i]).rotateZ(side * spl[i]);
            legFoot[i] = new Vector3f(0f, -LEG, 0f).rotate(legQ[i]).add(legP[i]);
        }

        float kT = rigid ? 300f : (run ? 30f : 20f) * LOOSE * (run ? .75f : .4f);
        float cT = 2f * (rigid ? .9f : .3f) * (float) Math.sqrt(kT);
        Vector3f[] armP = new Vector3f[2];
        Quaternionf[] armQ = new Quaternionf[2];
        for (int i = 0; i < 2; i++) {
            float side = i == 0 ? 1f : -1f;
            float xr = i == 0 ? cur[SLX] : cur[SRX];
            float zr = i == 0 ? cur[SLZ] : -cur[SRZ];
            // "elbow": the arm stays one solid block, its mount shifts when swung
            float sx = .29f * side, sy = .72f, sz = 0f;
            float sinx = sin(xr);
            sy += .05f * Math.abs(sinx);
            sz += .08f * sinx;
            sx += Math.signum(sx) * .15f * ease((.15f - cos(xr)) / .5f);

            Vector3f anchor = new Vector3f(sx, sy, sz).rotate(chestQ).add(chestP);
            Quaternionf aq = new Quaternionf(chestQ).rotateX(xr).rotateZ(zr);
            Vector3f tip = new Vector3f(0f, -ARM, 0f).rotate(aq).add(anchor);

            Spring F = fa[i], T = ta[i];
            follow(F, anchor, 160f * f, .5f, dt, .03f, 0f, 0f, wz * .3f);
            if (!T.init) { T.p.set(tip); T.v.zero(); T.init = true; }
            int n = 3;
            float hh = dt / n;
            for (int j = 0; j < n; j++) {
                float ax = (tip.x - T.p.x) * kT - T.v.x * cT;
                float ay = (tip.y - T.p.y) * kT - T.v.y * cT - GRAV;
                float az = (tip.z - T.p.z) * kT - T.v.z * cT + wz;
                T.v.add(ax * hh, ay * hh, az * hh);
                T.p.add(T.v.x * hh, T.v.y * hh, T.v.z * hh);
                float bx = T.p.x - F.p.x, by = T.p.y - F.p.y, bz = T.p.z - F.p.z;
                float l = (float) Math.sqrt(bx * bx + by * by + bz * bz);
                if (l < 1e-6f) l = 1f;
                bx /= l; by /= l; bz /= l;
                T.p.set(F.p.x + bx * ARM, F.p.y + by * ARM, F.p.z + bz * ARM); // the arm length never changes
                float dot = T.v.x * bx + T.v.y * by + T.v.z * bz;
                T.v.sub(bx * dot, by * dot, bz * dot);
            }
            if (!rigid) keepOut(T, F.p, side, chestQ, chestP, legP, legFoot);
            Vector3f dir = new Vector3f(T.p).sub(F.p).normalize();
            armQ[i] = new Quaternionf().rotationTo(new Vector3f(0f, -1f, 0f), dir);
            armP[i] = new Vector3f(F.p);
        }

        // ---- glitch / fade extras ----
        visible = true;
        boolean glitching = state == LazurEntity.S_GLITCH;
        float sink = 0f;
        float[] jx = new float[6];
        float[] jy = new float[6];
        for (float[] s : scale) { s[0] = 1f; s[1] = 1f; }
        if (glitching) {
            int frame = (int) (stateTime * 12f);
            if (frame != gFrame) {
                gFrame = frame;
                Random r = new Random(frame * 7919L + 13L);
                for (int i = 0; i < 6; i++) {
                    gJx[i] = rnd(r, .12f);
                    gJy[i] = rnd(r, .08f);
                    gSx[i] = 1f + Math.abs(rnd(r, .9f)) * (i % 3 != 0 ? .2f : 1f);
                    gSy[i] = 1f + Math.abs(rnd(r, 1.2f)) * (i % 2 != 0 ? 1f : .2f);
                }
                gRoot = rnd(r, .08f);
                gHide = r.nextFloat() < .08f;
            }
            for (int i = 0; i < 6; i++) {
                jx[i] = gJx[i] + gRoot;
                jy[i] = gJy[i];
                scale[i][0] = gSx[i];
                scale[i][1] = gSy[i];
            }
            visible = !gHide;
        } else {
            gFrame = -1;
        }
        if (state == LazurEntity.S_FADE) {
            float fadeT = stateTime;
            float ff = Math.min(1f, fadeT / 2.4f);
            float op = (1f - ff) * (.65f + .35f * sin(t * 50f * (1f + ff)));
            if (fadeT > 2.4f) op = 0f;
            visible = op > .4f;   // no translucent render type: flicker instead of alpha
            sink = -ff * .25f;
            for (int i = 0; i < 6; i++) jx[i] = .03f * ff * sin(t * 60f + i * 3f);
        }

        // body tremor: every part trembles a little (rotation only, so nothing comes off or clips)
        put(0, chestP, new Quaternionf(chestQ).mul(shake(tt, 1f, 1f)), jx[0], jy[0] + sink);
        put(1, fh.p, headQ, jx[1], jy[1] + sink);
        put(2, armP[0], new Quaternionf(armQ[0]).mul(shake(tt, 2f, 1f)), jx[2], jy[2] + sink);
        put(3, armP[1], new Quaternionf(armQ[1]).mul(shake(tt, 3f, 1f)), jx[3], jy[3] + sink);
        put(4, legP[0], new Quaternionf(legQ[0]).mul(shake(tt, 4f, .7f)), jx[4], jy[4] + sink);
        put(5, legP[1], new Quaternionf(legQ[1]).mul(shake(tt, 5f, .7f)), jx[5], jy[5] + sink);
    }

    private static Quaternionf shake(float tt, float k, float amount) {
        float a = amount * .5f;
        return new Quaternionf().rotateX(a * (.02f * sin(tt * 173f + k * 1.7f) + .012f * sin(tt * 271f + k)))
                .rotateY(a * (.025f * sin(tt * 157f + k * 2.3f) + .012f * sin(tt * 239f + k * .6f)))
                .rotateZ(a * .018f * sin(tt * 193f + k * 3.1f));
    }

    /** No part goes through another: the arm is pushed out of the torso box and away from the legs. */
    private static void keepOut(Spring T, Vector3f F, float side, Quaternionf chestQ, Vector3f chestP, Vector3f[] legP, Vector3f[] legFoot) {
        Quaternionf inv = new Quaternionf(chestQ).conjugate();
        for (int it = 0; it < 3; it++) {
            Vector3f lf = new Vector3f(F).sub(chestP).rotate(inv), lt = new Vector3f(T.p).sub(chestP).rotate(inv);
            float worst = 0f;
            for (int k = 1; k <= 10; k++) {              // samples along the arm, in the chest's own frame
                float sm = k / 10f;
                float x = lf.x + (lt.x - lf.x) * sm, y = lf.y + (lt.y - lf.y) * sm, z = lf.z + (lt.z - lf.z) * sm;
                if (y > -.1f && y < .85f && Math.abs(z) < .19f) {
                    float need = .28f - side * x;        // keep the arm's centre .28 off the torso centre line
                    if (need > 0f) worst = Math.max(worst, need / sm);
                }
            }
            if (worst > 0f) T.p.add(new Vector3f(side * Math.min(worst, .5f), 0f, 0f).rotate(chestQ));
            for (int l = 0; l < 2; l++) {                // arm vs leg: two .16 wide limbs need .16 between their axes
                float[] r = closest(F, T.p, legP[l], legFoot[l]);
                Vector3f c1 = new Vector3f(F).lerp(T.p, r[0]), c2 = new Vector3f(legP[l]).lerp(legFoot[l], r[1]);
                Vector3f dir = new Vector3f(c1).sub(c2);
                float d = dir.length();
                if (d < .17f) {
                    dir.y = 0f;
                    if (dir.length() < 1e-4f) dir.set(side, 0f, 0f); else dir.normalize();
                    T.p.add(dir.mul((.17f - d) / Math.max(.3f, r[0])));
                }
            }
            Vector3f b = new Vector3f(T.p).sub(F);
            if (b.lengthSquared() < 1e-8f) b.set(0f, -1f, 0f); else b.normalize();
            T.p.set(F).add(b.mul(ARM));
        }
    }

    /** Parameters (s on the first segment, t on the second) of the closest points of two segments. */
    private static float[] closest(Vector3f p1, Vector3f q1, Vector3f p2, Vector3f q2) {
        Vector3f d1 = new Vector3f(q1).sub(p1), d2 = new Vector3f(q2).sub(p2), r = new Vector3f(p1).sub(p2);
        float a = d1.dot(d1), e = d2.dot(d2), f = d2.dot(r), c = d1.dot(r), b = d1.dot(d2), den = a * e - b * b;
        float sp = den > 1e-9f ? clamp((b * f - c * e) / den, 0f, 1f) : 0f, tp = (b * sp + f) / (e == 0f ? 1f : e);
        if (tp < 0f) { tp = 0f; sp = clamp(-c / (a == 0f ? 1f : a), 0f, 1f); }
        else if (tp > 1f) { tp = 1f; sp = clamp((b - c) / (a == 0f ? 1f : a), 0f, 1f); }
        return new float[]{sp, tp};
    }

    /** prototype space (y up, +z forward) -> model space (y down, -z forward, feet at y = 24). */
    private void put(int i, Vector3f p, Quaternionf q, float jx, float jy) {
        pos[i][0] = (p.x + jx) * 16f;
        pos[i][1] = 24f - (p.y + jy) * 16f;
        pos[i][2] = -p.z * 16f;
        // the flip (x, y, z) -> (x, -y, -z) is a 180 degree turn about X: it conjugates the quaternion like this
        tmpQ.set(q.x, -q.y, -q.z, q.w).getEulerAnglesZYX(tmpV);
        rot[i][0] = tmpV.x;
        rot[i][1] = tmpV.y;
        rot[i][2] = tmpV.z;
    }

    // =========================================================================================
    // target pose per state (copied from the prototype)
    // =========================================================================================
    private void target(int state, float s, Gait q) {
        Arrays.fill(tgt, 0f);
        tgt[SLZ] = tgt[SRZ] = .1f;
        gh = 1.7f; gv = 0f; kz = 0f;
        ftz[0] = ftz[1] = 0f; ftyf[0] = ftyf[1] = 0f; ftw[0] = ftw[1] = 0f;
        mountX[0] = mountX[1] = .11f; spl[0] = spl[1] = 0f; impulse = 0f;
        boolean run = state == LazurEntity.S_RUN;

        boolean gait = state == LazurEntity.S_WALK || state == LazurEntity.S_CREEP || state == LazurEntity.S_RUN
                || state == LazurEntity.S_ATTACK;
        if (!gait) { // idle, glitch, fade, listen, grab
            float b = sin(t * 1.8f * s), u = t * s;
            float bb = .5f + .5f * sin(t * 2.6f * s);
            tgt[CY] = -.02f * bb * (1f + .8f * W);
            tgt[CL] = .03f + .02f * b;
            tgt[HY] = .15f * sin(u * .35f) + .08f * sin(u * .9f);
            tgt[HX] = .05f + .03f * sin(u * .5f);
            tgt[PR] = .015f * sin(u * .5f);
            tgt[PT] = .03f * sin(u * .6f);
            tgt[RX] = .015f * sin(u * .5f);
            tgt[HL] = .03f * sin(u * .5f);
            tgt[HR] = -tgt[HL];
            // heavy stance: legs apart and bent "mid-step" (left one ahead, right one behind), the body sags,
            // the weight slowly moves from one leg to the other
            float ang = .03f + .05f * B, z0 = LEG * sin(ang);
            float shf = (float) Math.tanh(2.2f * sin(t * .42f * s));
            ftz[0] = z0 * (1f + .12f * shf);
            ftz[1] = -z0 * .75f * (1f - .12f * shf);
            gh = LEG * cos(ang) * (1f - .03f * B) + .05f;
            tgt[CL] += .06f * B + .03f * W;
            tgt[HX] += .05f * B + .04f * W;
            tgt[PT] += .05f * B;
            tgt[CT] += -.04f * B;
            float k3 = .03f * shf * (.4f + .6f * W);
            tgt[RX] += k3; tgt[PR] += k3; tgt[CR] += -k3;
            // the arms simply hang
            tgt[SLZ] = tgt[SRZ] = .05f + .02f * b;
            tgt[SLX] = .02f + .03f * sin(u * 1.1f - .6f);
            tgt[SRX] = .02f + .03f * sin(u * 1.1f - 1.9f);
            mountX[0] = mountX[1] = .11f + .02f * WD;
            spl[0] = spl[1] = .05f * WD;
            tgt[BOB] = -.06f * bb * (1f + .5f * W);
            if (state == LazurEntity.S_LISTEN) {       // stands bent forward, head cocked, slowly turning to catch a sound
                tgt[CL] = .22f + .02f * b + .08f * B;
                tgt[HX] = .16f + .03f * sin(u * .7f) + .04f * B;
                tgt[HZ] = .30f + .06f * sin(u * 1.4f);
                tgt[HY] = .55f * sin(u * .45f);
                tgt[SLX] = tgt[SRX] = -.03f + .03f * sin(u * 1.1f);
                tgt[BOB] = -.12f * (.5f + .5f * bb) - .05f * B;
            }
            if (state == LazurEntity.S_GRAB) {         // holds the player in one hand, in front of his face
                // arm hangs from the shoulder: rotating it about X by -1.2 rad swings the hand forward and up
                // to about 1.7 blocks ahead at hip height of the held player; the Z turn brings it to the centre line
                tgt[SRX] = -1.2f;
                tgt[SRZ] = -.16f;
                tgt[SLX] = .12f + .03f * sin(u * 2.7f);   // the free arm hangs and trembles
                tgt[CL] = .03f;
                tgt[CT] = 0f;
                tgt[HX] = .05f;
                tgt[HY] = 0f;                              // looks straight at the face in front of him
                tgt[HZ] = 0f;
                tgt[BOB] = -.03f;
            }
        } else {
            boolean runG = q == RUN, creep = state == LazurEntity.S_CREEP;
            float tc = tcw(q, runG), dB = dBase(q), hAv = hAe(q, runG), zmB = zmBase(q, runG);
            float sL = 1f - .12f * U, sR = 1f + .10f * U;          // the left step is shorter, the right one longer
            float dL = Math.min(.88f, dB * sL), dR = Math.min(.88f, dB * sR);
            float zmL = zmB * sL, zmR = zmB * sR, offR = .5f + .045f * U;
            float fL = (st / tc) % 1f, fR = (fL + offR) % 1f;
            boolean stA = fL < dL, stB = fR < dR;
            float wA = stA ? 0f : (fL - dL) / (1f - dL), wB = stB ? 0f : (fR - dR) / (1f - dR);

            float zA = footZ(fL, dL, zmL), zB = footZ(fR, dR, zmR);
            float clq = q.cl() * .6f;
            float yA = stA ? 0f : clq * sin(PI * wA), yB = stB ? 0f : clq * sin(PI * wB);

            float H = LEG * cos(hAv) * .96f + .08f;
            if (!stA && !stB) {
                float ph = clamp(((fL % .5f) - dB) / (.5f - dB), 0f, 1f);
                H += .05f * sin(PI * ph);
            }
            tgt[HL] = -(float) Math.asin(clamp(zA / LEG, -1f, 1f));
            tgt[HR] = -(float) Math.asin(clamp(zB / LEG, -1f, 1f));
            ftz[0] = zA; ftz[1] = zB;
            ftyf[0] = yA; ftyf[1] = yB;
            ftw[0] = wA; ftw[1] = wB;
            kz = q.kz();
            gh = H;
            gv = 2f * zmB / (dB * tc) * s;     // planted feet slide back at one speed: no skating

            float dip = Math.max(0f, 1f - fL / .15f) + Math.max(0f, 1f - fR / .15f);
            float wc = cos(TP * (fL - dL / 2f));
            float am = run ? 1.2f : .45f;       // the arms hang and swing only a little (a bit more when running)
            tgt[SLX] = -.05f + q.arm() * am * tgt[HR] * (1f - .25f * U);
            tgt[SRX] = -.05f + q.arm() * am * tgt[HL] * (1f + .10f * U);
            tgt[SLZ] = tgt[SRZ] = (run ? .09f : .05f) + .02f * Math.abs(wc);
            tgt[PR] = 0f;
            tgt[RX] = q.s() * wc + W * .045f * wc;          // the hips go over the standing leg
            tgt[PT] = 0f;
            tgt[CT] = .35f * q.y() * cos(TP * fL);
            tgt[PP] = 0f;
            tgt[CL] = q.lean() + .02f * cos(2f * TP * fL) + .08f * dip + .05f * W;
            tgt[CR] = -q.r() * wc - W * .03f * wc;
            tgt[HX] = q.hx() + .16f * dip + .06f * W;
            tgt[HY] = -.8f * (tgt[PT] + tgt[CT]);
            tgt[HZ] = -(tgt[PR] + tgt[CR]) * .6f + (creep ? .25f : 0f) + .05f * U * sin(TP * fL);
            tgt[BOB] = 0f;
            float uu = (fL * 2f) % 1f;
            tgt[CY] = -q.drop() * (1f + .3f * W) * (1f - ease(uu / .65f)) + .03f * sin(PI * uu);

            float sBase = WD * (runG ? .02f : .045f);
            spl[0] = sBase * .7f + WD * .015f * sin(PI * wA);
            spl[1] = sBase * .7f + WD * .015f * sin(PI * wB);
            mountX[0] = mountX[1] = .11f + .035f * WD * (runG ? .4f : 1f);
            float kb = runG ? 1.4f : 1f;                // heel strike: the body drops and bounces
            if (fL < prevFL) impulse += W * .9f * kb * (1f - .35f * U);
            if (fR < prevFR) impulse += W * .9f * kb * (1f + .6f * U);
            prevFL = fL; prevFR = fR;

            if (state == LazurEntity.S_ATTACK) {       // strike on top of the run: arms, lean, head
                float c = Math.min(stateTime * .85f, .999f);
                float[] k = kf(c);
                tgt[SLX] = tgt[SRX] = k[0];
                tgt[SLZ] = tgt[SRZ] = .3f;
                tgt[CL] = k[1];
                tgt[HX] = k[2];
                tgt[BOB] = k[3] * 1.2f;
            }
        }
    }

    // =========================================================================================
    // math helpers
    // =========================================================================================
    private static float footZ(float f, float D, float zm) {
        if (f < D) return zm * (1f - 2f * f / D);
        float u = (f - D) / (1f - D), m = -2f * zm / D * (1f - D), u2 = u * u, u3 = u2 * u;
        return (2f * u3 - 3f * u2 + 1f) * -zm + (u3 - 2f * u2 + u) * m + (-2f * u3 + 3f * u2) * zm + (u3 - u2) * m;
    }

    private static float[] kf(float c) {
        int i = 0;
        while (i < KF.length - 2 && c >= KF[i + 1][0]) i++;
        float[] a = KF[i], b = KF[i + 1];
        float e = ease((c - a[0]) / (b[0] - a[0]));
        float[] out = new float[4];
        for (int j = 0; j < 4; j++) out[j] = a[j + 1] + (b[j + 1] - a[j + 1]) * e;
        return out;
    }

    private static void follow(Spring f, Vector3f a, float k, float z, float dt, float max, float ex, float ey, float ez) {
        if (!f.init) { f.p.set(a); f.v.zero(); f.init = true; }
        float cc = 2f * z * (float) Math.sqrt(k);
        int n = 2;
        float h = dt / n;
        for (int i = 0; i < n; i++) {
            float ax = (a.x - f.p.x) * k - f.v.x * cc + ex;
            float ay = (a.y - f.p.y) * k - f.v.y * cc + ey;
            float az = (a.z - f.p.z) * k - f.v.z * cc + ez;
            f.v.add(ax * h, ay * h, az * h);
            f.p.add(f.v.x * h, f.v.y * h, f.v.z * h);
        }
        float bx = f.p.x - a.x, by = f.p.y - a.y, bz = f.p.z - a.z;
        float l = (float) Math.sqrt(bx * bx + by * by + bz * bz);
        if (l > max) {
            float sc = max / l;
            f.p.set(a.x + bx * sc, a.y + by * sc, a.z + bz * sc);
        }
    }

    private static float rnd(Random r, float a) { return (r.nextFloat() - .5f) * 2f * a; }
    private static float ease(float x) { x = clamp(x, 0f, 1f); return x * x * (3f - 2f * x); }
    private static float clamp(float x, float lo, float hi) { return Math.max(lo, Math.min(hi, x)); }
    private static float sin(float x) { return (float) Math.sin(x); }
    private static float cos(float x) { return (float) Math.cos(x); }
}
