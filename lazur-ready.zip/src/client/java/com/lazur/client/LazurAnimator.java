package com.lazur.client;

import com.lazur.entity.LazurEntity;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.Arrays;
import java.util.Random;

/**
 * Port of the prototype lazur-figure.html. Everything is computed in the prototype's space
 * (blocks, y up, character faces +z) and converted to model space at the end.
 * One instance per Lazur entity (kept by LazurRenderer). Client-only, render-only: the server knows nothing about it.
 */
public final class LazurAnimator {
    private static final float PI = (float) Math.PI;
    private static final float TP = PI * 2f;
    public static final float LEG = 1.7f, ARM = 1.85f;
    private static final float GRAV = 7f;

    // smoothed channels
    private static final int CY = 0, BOB = 1, RX = 2, PR = 3, PT = 4, PP = 5, CL = 6, CT = 7, CR = 8,
            HX = 9, HY = 10, HZ = 11, SLX = 12, SRX = 13, SLZ = 14, SRZ = 15, HL = 16, HR = 17, N = 18;
    private static final float[] KS = {170, 130, 50, 55, 60, 60, 70, 70, 60, 70, 70, 70, 45, 45, 50, 50, 170, 170};

    private record Gait(float tc, float d, float hA, float cl, float r, float s, float y,
                        float lean, float hx, float arm, float drop, float kz) {}

    private static final Gait WALK = new Gait(2.4f, .64f, .46f, .18f, .10f, .07f, .18f, .16f, .40f, 1.0f, .12f, .04f);
    private static final Gait CREEP = new Gait(3.0f, .72f, .38f, .14f, .12f, .07f, .14f, .26f, .42f, .7f, .10f, .03f);
    private static final Gait RUN = new Gait(.7f, .42f, .50f, .16f, .08f, .05f, .20f, .34f, .10f, 1.0f, .12f, .04f);

    // strike keyframes: {cycle, shoulder x, chest lean, head x, bob}
    private static final float[][] KF = {
            {0f, 0f, 0f, 0f, 0f}, {.14f, .35f, .12f, .15f, -.08f}, {.42f, -2.62f, -.2f, -.5f, 0f},
            {.55f, -2.62f, -.2f, -.5f, 0f}, {.66f, -.07f, .45f, .45f, -.1f}, {1f, .05f, 0f, 0f, 0f}};

    private static final class Spring {
        final Vector3f p = new Vector3f();
        final Vector3f v = new Vector3f();
        boolean init;
    }

    // ---- outputs (model space; index: 0 torso, 1 head, 2 armL, 3 armR, 4 legL, 5 legR) ----
    public final float[][] pos = new float[6][3];
    public final float[][] rot = new float[6][3];
    public final float[][] scale = new float[6][2];
    public boolean visible = true;

    // ---- state ----
    private final float[] cur = new float[N], vel = new float[N], tgt = new float[N];
    private final Spring fc = new Spring(), fh = new Spring();
    private final Spring[] fa = {new Spring(), new Spring()}, ta = {new Spring(), new Spring()};
    private float t, st, stateTime, ghs = 1.7f, gh = 1.7f, gv, gvPrev, gvAcc, kz;
    private final float[] ftz = new float[2], ftyf = new float[2], ftw = new float[2];
    private final float[] legH = new float[2], legDy = new float[2], legDz = new float[2];
    private int lastState = -1;
    private float lastAge = Float.NaN;
    private double lastX, lastZ;
    private boolean hasPos;
    private float speed;
    private float spSmooth = 1f;
    // glitch
    private int gFrame = -1;
    private final float[] gJx = new float[6], gJy = new float[6], gSx = new float[6], gSy = new float[6];
    private float gRoot;
    private boolean gHide;
    // scratch
    private final Quaternionf tmpQ = new Quaternionf();
    private final Vector3f tmpV = new Vector3f();

    public LazurAnimator() {
        for (float[] s : scale) { s[0] = 1f; s[1] = 1f; }
    }

    /** Same function is used by the renderer to pick the azure texture on a few glitch frames. */
    public static boolean glitchBurst(float ageInTicks) {
        int frame = (int) (ageInTicks / (20f / 12f));
        long h = frame * 0x9E3779B97F4A7C15L;
        return ((h >>> 33) % 100) < 35;
    }

    // =========================================================================================
    public void update(LazurRenderState s) {
        float dt = Float.isNaN(lastAge) ? 0.016f : (s.ageInTicks - lastAge) / 20f;
        lastAge = s.ageInTicks;
        if (dt < 0f || dt > 0.3f) dt = 0.016f;
        if (dt < 1e-4f) return; // paused: keep the last pose

        if (hasPos) {
            double dx = s.x - lastX, dz = s.z - lastZ;
            float inst = (float) Math.min(12.0, Math.sqrt(dx * dx + dz * dz) / dt);
            speed += (inst - speed) * Math.min(1f, dt * 8f);
        }
        lastX = s.x; lastZ = s.z; hasPos = true;

        if (s.lazurState != lastState) { lastState = s.lazurState; stateTime = 0f; } else stateTime += dt;
        step(dt, s.lazurState);
    }

    private static float gaitSpeed(Gait q) {
        return 2f * LEG * sin(q.hA) / (q.d * q.tc);
    }

    private void step(float dt, int state) {
        boolean run = state == LazurEntity.S_RUN;
        boolean attack = state == LazurEntity.S_ATTACK;
        boolean grab = state == LazurEntity.S_GRAB;
        boolean rigid = attack || grab;   // arms follow their target tightly (strike / holding the player)
        // the strike does not stop him: legs keep running (RUN gait), only the upper body does the strike
        boolean gaitState = run || attack || state == LazurEntity.S_WALK || state == LazurEntity.S_CREEP;
        Gait q = state == LazurEntity.S_WALK ? WALK : (state == LazurEntity.S_CREEP ? CREEP : RUN);

        t += dt;
        float spWanted = 1f; // standing still (e.g. /lazur anim run): play the gait at its normal tempo, in place
        if (gaitState && speed >= .3f) spWanted = clamp(speed / gaitSpeed(q), .25f, 3f); // phase follows real speed: planted feet do not slide
        spSmooth += (spWanted - spSmooth) * Math.min(1f, dt * 4f);
        float sp = gaitState ? spSmooth : 1f;
        st += dt * sp;
        target(state, sp, q);

        // ---- spring-smoothed channels ----
        float kq = (rigid || run) ? 2.4f : 1f;
        int sub = 2;
        float hs = dt / sub;
        for (int k = 0; k < sub; k++) {
            for (int i = 0; i < N; i++) {
                float kk = KS[i] * kq;
                boolean fast = i == SLX || i == SRX || i == SLZ || i == SRZ || i == HX || i == HY || i == HZ;
                float z = fast ? (rigid ? .85f : .45f) : (i == CY ? .4f : .8f);
                float damp = 2f * z * (float) Math.sqrt(kk);
                vel[i] += ((tgt[i] - cur[i]) * kk - vel[i] * damp) * hs;
                cur[i] += vel[i] * hs;
            }
        }
        ghs += (gh - ghs) * Math.min(1f, dt * 14f);

        // ---- legs: planted foot stays where the step put it, the hip joint moves ----
        float hipY = ghs + cur[BOB];
        float tb = .1f + cur[CY] - .06f;
        float sA = sin(Math.max(0f, cur[CL] + .03f)), cA = cos(cur[CL]);
        for (int i = 0; i < 2; i++) {
            float lz = ftz[i], yf = ftyf[i], w = ftw[i];
            float ph = (float) Math.sqrt(Math.max(0f, LEG * LEG - lz * lz));
            float o = yf + ph - hipY - tb;
            float dz = 0f;
            if (o > -.05f) {
                float oo = Math.max(o, 0f);
                float n0 = (.28f + oo * sA) / cA;
                float n1 = (.28f - lz * oo / LEG) / (1f - oo / LEG);
                dz = Math.min(.5f, Math.max(0f, Math.max(n0, n1))) * ease((o + .05f) / .08f);
            }
            dz += kz * sin(PI * w);
            float zz = clamp(lz - dz, -.97f * LEG, .97f * LEG);
            ph = (float) Math.sqrt(LEG * LEG - zz * zz);
            legH[i] = -(float) Math.asin(zz / LEG);
            legDy[i] = yf + ph - hipY;
            legDz[i] = dz;
        }

        // ---- hierarchy (hips -> chest) ----
        Quaternionf hipsQ = new Quaternionf().rotateX(cur[PP]).rotateY(cur[PT]).rotateZ(cur[PR]);
        Vector3f hipsP = new Vector3f(0f, hipY, 0f);
        Quaternionf chestQ = new Quaternionf(hipsQ).mul(new Quaternionf().rotateX(cur[CL]).rotateY(cur[CT]).rotateZ(cur[CR]));
        Vector3f chestAnchor = new Vector3f(cur[RX], .1f + cur[CY], 0f).rotate(hipsQ).add(hipsP);

        // ---- physics: nothing is welded to the body ----
        gvAcc = clamp(-(gv - gvPrev) / dt, -25f, 25f);
        gvPrev = gv;
        float wz = rigid ? 0f : -gv * (run ? 1.2f : .5f) + gvAcc * .3f; // fake "wind": things trail behind
        float f = run ? 2.5f : 1f;

        follow(fc, chestAnchor, 160f * f, .5f, dt, .05f, 0f, 0f, wz * .25f);
        Vector3f chestP = new Vector3f(fc.p);

        Vector3f headAnchor = new Vector3f(0f, .78f, 0f).rotate(chestQ).add(chestP);
        follow(fh, headAnchor, 100f * f, .4f, dt, .05f, 0f, 0f, wz * .5f);
        float dX = fh.p.x - headAnchor.x, dY = fh.p.y - headAnchor.y, dZ = fh.p.z - headAnchor.z;
        float tt = t % 50f; // constant head tremor, 25-45 Hz
        float hx = cur[HX] + .02f * sin(tt * 173f) + .012f * sin(tt * 271f + 1f) + dZ * 3f - dY * 1.5f;
        float hy = cur[HY] + .025f * sin(tt * 157f + 2f) + .012f * sin(tt * 239f);
        float hz = cur[HZ] + .018f * sin(tt * 193f + 4f) - dX * 3f;
        Quaternionf headQ = new Quaternionf(chestQ).rotateX(hx).rotateY(hy).rotateZ(hz).rotateY(PI / 4f); // head is turned 45 deg

        float kT = rigid ? 300f : (run ? 30f : 20f);
        float cT = 2f * (rigid ? .9f : .3f) * (float) Math.sqrt(kT);
        Vector3f[] armP = new Vector3f[2];
        Quaternionf[] armQ = new Quaternionf[2];
        for (int i = 0; i < 2; i++) {
            float side = i == 0 ? 1f : -1f;
            float xr = i == 0 ? cur[SLX] : cur[SRX];
            float zr = i == 0 ? cur[SLZ] : -cur[SRZ];
            // "elbow": the arm stays one solid block, its mount shifts when swung
            float sx = .29f * side, sy = .72f, sz = 0f;
            float sinx = sin(xr);
            sy += .05f * Math.abs(sinx);
            sz += .08f * sinx;
            sx += Math.signum(sx) * .15f * ease((.15f - cos(xr)) / .5f);

            Vector3f anchor = new Vector3f(sx, sy, sz).rotate(chestQ).add(chestP);
            Quaternionf aq = new Quaternionf(chestQ).rotateX(xr).rotateZ(zr);
            Vector3f tip = new Vector3f(0f, -ARM, 0f).rotate(aq).add(anchor);

            Spring F = fa[i], T = ta[i];
            follow(F, anchor, 160f * f, .5f, dt, .03f, 0f, 0f, wz * .3f);
            if (!T.init) { T.p.set(tip); T.v.zero(); T.init = true; }
            int n = 3;
            float hh = dt / n;
            for (int j = 0; j < n; j++) {
                float ax = (tip.x - T.p.x) * kT - T.v.x * cT;
                float ay = (tip.y - T.p.y) * kT - T.v.y * cT - GRAV;
                float az = (tip.z - T.p.z) * kT - T.v.z * cT + wz;
                T.v.add(ax * hh, ay * hh, az * hh);
                T.p.add(T.v.x * hh, T.v.y * hh, T.v.z * hh);
                float bx = T.p.x - F.p.x, by = T.p.y - F.p.y, bz = T.p.z - F.p.z;
                float l = (float) Math.sqrt(bx * bx + by * by + bz * bz);
                if (l < 1e-6f) l = 1f;
                bx /= l; by /= l; bz /= l;
                T.p.set(F.p.x + bx * ARM, F.p.y + by * ARM, F.p.z + bz * ARM); // the arm length never changes
                float dot = T.v.x * bx + T.v.y * by + T.v.z * bz;
                T.v.sub(bx * dot, by * dot, bz * dot);
            }
            Vector3f dir = new Vector3f(T.p).sub(F.p).normalize();
            armQ[i] = new Quaternionf().rotationTo(new Vector3f(0f, -1f, 0f), dir);
            armP[i] = new Vector3f(F.p);
        }

        Vector3f[] legP = new Vector3f[2];
        Quaternionf[] legQ = new Quaternionf[2];
        for (int i = 0; i < 2; i++) {
            float side = i == 0 ? 1f : -1f;
            legP[i] = new Vector3f(.11f * side, legDy[i], legDz[i]).rotate(hipsQ).add(hipsP);
            legQ[i] = new Quaternionf(hipsQ).rotateX(legH[i]);
        }

        // ---- glitch / fade extras ----
        visible = true;
        boolean glitching = state == LazurEntity.S_GLITCH;
        float sink = 0f;
        float[] jx = new float[6];
        float[] jy = new float[6];
        for (float[] s : scale) { s[0] = 1f; s[1] = 1f; }
        if (glitching) {
            int frame = (int) (stateTime * 12f);
            if (frame != gFrame) {
                gFrame = frame;
                Random r = new Random(frame * 7919L + 13L);
                for (int i = 0; i < 6; i++) {
                    gJx[i] = rnd(r, .12f);
                    gJy[i] = rnd(r, .08f);
                    gSx[i] = 1f + Math.abs(rnd(r, .9f)) * (i % 3 != 0 ? .2f : 1f);
                    gSy[i] = 1f + Math.abs(rnd(r, 1.2f)) * (i % 2 != 0 ? 1f : .2f);
                }
                gRoot = rnd(r, .08f);
                gHide = r.nextFloat() < .08f;
            }
            for (int i = 0; i < 6; i++) {
                jx[i] = gJx[i] + gRoot;
                jy[i] = gJy[i];
                scale[i][0] = gSx[i];
                scale[i][1] = gSy[i];
            }
            visible = !gHide;
        } else {
            gFrame = -1;
        }
        if (state == LazurEntity.S_FADE) {
            float fadeT = stateTime;
            float ff = Math.min(1f, fadeT / 2.4f);
            float op = (1f - ff) * (.65f + .35f * sin(t * 50f * (1f + ff)));
            if (fadeT > 2.4f) op = 0f;
            visible = op > .4f;   // no translucent render type: flicker instead of alpha
            sink = -ff * .25f;
            for (int i = 0; i < 6; i++) jx[i] = .03f * ff * sin(t * 60f + i * 3f);
        }

        put(0, chestP, chestQ, jx[0], jy[0] + sink);
        put(1, fh.p, headQ, jx[1], jy[1] + sink);
        put(2, armP[0], armQ[0], jx[2], jy[2] + sink);
        put(3, armP[1], armQ[1], jx[3], jy[3] + sink);
        put(4, legP[0], legQ[0], jx[4], jy[4] + sink);
        put(5, legP[1], legQ[1], jx[5], jy[5] + sink);
    }

    /** prototype space (y up, +z forward) -> model space (y down, -z forward, feet at y = 24). */
    private void put(int i, Vector3f p, Quaternionf q, float jx, float jy) {
        pos[i][0] = (p.x + jx) * 16f;
        pos[i][1] = 24f - (p.y + jy) * 16f;
        pos[i][2] = -p.z * 16f;
        // the flip (x, y, z) -> (x, -y, -z) is a 180 degree turn about X: it conjugates the quaternion like this
        tmpQ.set(q.x, -q.y, -q.z, q.w).getEulerAnglesZYX(tmpV);
        rot[i][0] = tmpV.x;
        rot[i][1] = tmpV.y;
        rot[i][2] = tmpV.z;
    }

    // =========================================================================================
    // target pose per state (copied from the prototype)
    // =========================================================================================
    private void target(int state, float s, Gait q) {
        Arrays.fill(tgt, 0f);
        tgt[SLZ] = tgt[SRZ] = .1f;
        gh = 1.7f; gv = 0f; kz = 0f;
        ftz[0] = ftz[1] = 0f; ftyf[0] = ftyf[1] = 0f; ftw[0] = ftw[1] = 0f;

        boolean gait = state == LazurEntity.S_WALK || state == LazurEntity.S_CREEP || state == LazurEntity.S_RUN
                || state == LazurEntity.S_ATTACK;
        if (!gait) { // idle, glitch, fade, listen, grab
            float b = sin(t * 1.8f * s), u = t * s;
            float bb = .5f + .5f * sin(t * 2.6f * s);
            tgt[CY] = -.02f * bb;
            tgt[CL] = .03f + .02f * b;
            tgt[SLX] = .05f + .06f * sin(u * 1.1f - .6f);
            tgt[SRX] = .05f + .06f * sin(u * 1.1f - 1.9f);
            tgt[SLZ] = tgt[SRZ] = .12f + .03f * b;
            tgt[HY] = .15f * sin(u * .35f) + .08f * sin(u * .9f);
            tgt[HX] = .05f + .03f * sin(u * .5f);
            tgt[PR] = .015f * sin(u * .5f);
            tgt[PT] = .03f * sin(u * .6f);
            tgt[RX] = .015f * sin(u * .5f);
            tgt[HL] = .03f * sin(u * .5f);
            tgt[HR] = -tgt[HL];
            tgt[BOB] = -.06f * bb;
            if (state == LazurEntity.S_LISTEN) {       // stands bent forward, head cocked, slowly turning to catch a sound
                tgt[CL] = .22f + .02f * b;
                tgt[HX] = .16f + .03f * sin(u * .7f);
                tgt[HZ] = .30f + .06f * sin(u * 1.4f);
                tgt[HY] = .55f * sin(u * .45f);
                tgt[SLX] = tgt[SRX] = -.12f + .04f * sin(u * 1.1f);
                tgt[BOB] = -.12f * (.5f + .5f * bb);
            }
            if (state == LazurEntity.S_GRAB) {         // holds the player in one hand, in front of his face
                // arm hangs from the shoulder: rotating it about X by -1.2 rad swings the hand forward and up
                // to about 1.7 blocks ahead at hip height of the held player; the Z turn brings it to the centre line
                tgt[SRX] = -1.2f;
                tgt[SRZ] = -.16f;
                tgt[SLX] = .12f + .03f * sin(u * 2.7f);   // the free arm hangs and trembles
                tgt[CL] = .03f;
                tgt[CT] = 0f;
                tgt[HX] = .05f;
                tgt[HY] = 0f;                              // looks straight at the face in front of him
                tgt[HZ] = 0f;
                tgt[BOB] = -.03f;
            }
        } else {
            float zm = LEG * sin(q.hA);
            float fL = (st / q.tc) % 1f, fR = (fL + .5f) % 1f;
            float hc = LEG * cos(q.hA) * .96f;

            float zA = footZ(fL, q.d, zm), zB = footZ(fR, q.d, zm);
            boolean stA = fL < q.d, stB = fR < q.d;
            float wA = stA ? 0f : (fL - q.d) / (1f - q.d), wB = stB ? 0f : (fR - q.d) / (1f - q.d);
            float yA = stA ? 0f : q.cl * sin(PI * wA), yB = stB ? 0f : q.cl * sin(PI * wB);

            float H = hc;
            if (!stA && !stB) {
                float ph = clamp(((fL % .5f) - q.d) / (.5f - q.d), 0f, 1f);
                H += .05f * sin(PI * ph);
            }
            tgt[HL] = -(float) Math.asin(zA / LEG);
            tgt[HR] = -(float) Math.asin(zB / LEG);
            ftz[0] = zA; ftz[1] = zB;
            ftyf[0] = yA; ftyf[1] = yB;
            ftw[0] = wA; ftw[1] = wB;
            kz = q.kz;
            gh = H;
            gv = 2f * zm / (q.d * q.tc) * s;

            float dip = Math.max(0f, 1f - fL / .15f) + Math.max(0f, 1f - fR / .15f);
            float wc = cos(TP * (fL - q.d / 2f));
            tgt[SLX] = -.05f + q.arm * tgt[HR];
            tgt[SRX] = -.05f + q.arm * tgt[HL];
            tgt[SLZ] = tgt[SRZ] = .1f + .04f * Math.abs(wc);
            tgt[PR] = 0f;
            tgt[RX] = q.s * wc;
            tgt[PT] = 0f;
            tgt[CT] = .35f * q.y * cos(TP * fL);
            tgt[PP] = 0f;
            tgt[CL] = q.lean + .02f * cos(2f * TP * fL) + .08f * dip;
            tgt[CR] = -q.r * wc;
            tgt[HX] = q.hx + .16f * dip;
            tgt[HY] = -.8f * (tgt[PT] + tgt[CT]);
            tgt[HZ] = -(tgt[PR] + tgt[CR]) * .6f + (state == LazurEntity.S_CREEP ? .25f : 0f);
            tgt[BOB] = 0f;
            float u = (fL * 2f) % 1f;
            tgt[CY] = -q.drop * (1f - ease(u / .65f)) + .03f * sin(PI * u);

            if (state == LazurEntity.S_ATTACK) {       // strike on top of the run: arms, lean, head
                float c = Math.min(stateTime * .85f, .999f);
                float[] k = kf(c);
                tgt[SLX] = tgt[SRX] = k[0];
                tgt[SLZ] = tgt[SRZ] = .3f;
                tgt[CL] = k[1];
                tgt[HX] = k[2];
                tgt[BOB] = k[3] * 1.2f;
            }
        }
    }

    // =========================================================================================
    // math helpers
    // =========================================================================================
    private static float footZ(float f, float D, float zm) {
        if (f < D) return zm * (1f - 2f * f / D);
        float u = (f - D) / (1f - D), m = -2f * zm / D * (1f - D), u2 = u * u, u3 = u2 * u;
        return (2f * u3 - 3f * u2 + 1f) * -zm + (u3 - 2f * u2 + u) * m + (-2f * u3 + 3f * u2) * zm + (u3 - u2) * m;
    }

    private static float[] kf(float c) {
        int i = 0;
        while (i < KF.length - 2 && c >= KF[i + 1][0]) i++;
        float[] a = KF[i], b = KF[i + 1];
        float e = ease((c - a[0]) / (b[0] - a[0]));
        float[] out = new float[4];
        for (int j = 0; j < 4; j++) out[j] = a[j + 1] + (b[j + 1] - a[j + 1]) * e;
        return out;
    }

    private static void follow(Spring f, Vector3f a, float k, float z, float dt, float max, float ex, float ey, float ez) {
        if (!f.init) { f.p.set(a); f.v.zero(); f.init = true; }
        float cc = 2f * z * (float) Math.sqrt(k);
        int n = 2;
        float h = dt / n;
        for (int i = 0; i < n; i++) {
            float ax = (a.x - f.p.x) * k - f.v.x * cc + ex;
            float ay = (a.y - f.p.y) * k - f.v.y * cc + ey;
            float az = (a.z - f.p.z) * k - f.v.z * cc + ez;
            f.v.add(ax * h, ay * h, az * h);
            f.p.add(f.v.x * h, f.v.y * h, f.v.z * h);
        }
        float bx = f.p.x - a.x, by = f.p.y - a.y, bz = f.p.z - a.z;
        float l = (float) Math.sqrt(bx * bx + by * by + bz * bz);
        if (l > max) {
            float sc = max / l;
            f.p.set(a.x + bx * sc, a.y + by * sc, a.z + bz * sc);
        }
    }

    private static float rnd(Random r, float a) { return (r.nextFloat() - .5f) * 2f * a; }
    private static float ease(float x) { x = clamp(x, 0f, 1f); return x * x * (3f - 2f * x); }
    private static float clamp(float x, float lo, float hi) { return Math.max(lo, Math.min(hi, x)); }
    private static float sin(float x) { return (float) Math.sin(x); }
    private static float cos(float x) { return (float) Math.cos(x); }
}
