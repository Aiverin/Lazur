package com.lazur.client;

import com.lazur.LazurMod;
import com.lazur.entity.LazurEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

import java.util.Random;

/**
 * One model, two looks (parts are shown/hidden):
 *  - SKIN: a plain player body (classic or slim arms) textured with the local player's skin
 *  - FIGURE: the tall faceless black figure from the HTML prototype (6 detached boxes)
 * Figure parts are direct children of the root; LazurAnimator computes their final position/rotation.
 */
public class LazurModel extends EntityModel<LazurRenderState> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(LazurMod.id("lazur"), "main");
    private static final float DEG = (float) (Math.PI / 180.0);

    private final ModelPart sHead, sBody, sRArm, sLArm, sRArmSlim, sLArmSlim, sRLeg, sLLeg;
    private final ModelPart fTorso, fHead, fArmL, fArmR, fLegL, fLegR;
    private final ModelPart sHat, sJacket, sRSleeve, sLSleeve, sRSleeveSlim, sLSleeveSlim, sRPants, sLPants;
    private final ModelPart[] figure;
    private final ModelPart[] skinByIndex;
    private static final int GLITCH_CUBES = 6; // few pieces, each one a flat 2D patch
    private final ModelPart[] glitch = new ModelPart[GLITCH_CUBES];

    public LazurModel(ModelPart root) {
        super(root);
        sHead = root.getChild("s_head");
        sBody = root.getChild("s_body");
        sRArm = root.getChild("s_rarm");
        sLArm = root.getChild("s_larm");
        sRArmSlim = root.getChild("s_rarm_slim");
        sLArmSlim = root.getChild("s_larm_slim");
        sRLeg = root.getChild("s_rleg");
        sLLeg = root.getChild("s_lleg");
        sHat = root.getChild("s_hat");
        sJacket = root.getChild("s_jacket");
        sRSleeve = root.getChild("s_rsleeve");
        sLSleeve = root.getChild("s_lsleeve");
        sRSleeveSlim = root.getChild("s_rsleeve_slim");
        sLSleeveSlim = root.getChild("s_lsleeve_slim");
        sRPants = root.getChild("s_rpants");
        sLPants = root.getChild("s_lpants");
        fTorso = root.getChild("f_torso");
        fHead = root.getChild("f_head");
        fArmL = root.getChild("f_arm_l");
        fArmR = root.getChild("f_arm_r");
        fLegL = root.getChild("f_leg_l");
        fLegR = root.getChild("f_leg_r");
        figure = new ModelPart[]{fTorso, fHead, fArmL, fArmR, fLegL, fLegR};
        // same index order as the animator: 0 torso, 1 head, 2 armL, 3 armR, 4 legL, 5 legR
        skinByIndex = new ModelPart[]{sBody, sHead, sLArm, sRArm, sLLeg, sRLeg};
        for (int i = 0; i < GLITCH_CUBES; i++) glitch[i] = root.getChild("g" + i);
    }

    public static LayerDefinition getTexturedModelData() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // ---- SKIN look (standard 64x64 skin layout, no overlay layers yet) ----
        root.addOrReplaceChild("s_head", CubeListBuilder.create().texOffs(0, 0).addBox(-4, -8, -4, 8, 8, 8), PartPose.offset(0, 0, 0));
        root.addOrReplaceChild("s_body", CubeListBuilder.create().texOffs(16, 16).addBox(-4, 0, -2, 8, 12, 4), PartPose.offset(0, 0, 0));
        root.addOrReplaceChild("s_rarm", CubeListBuilder.create().texOffs(40, 16).addBox(-3, -2, -2, 4, 12, 4), PartPose.offset(-5, 2, 0));
        root.addOrReplaceChild("s_larm", CubeListBuilder.create().texOffs(32, 48).addBox(-1, -2, -2, 4, 12, 4), PartPose.offset(5, 2, 0));
        root.addOrReplaceChild("s_rarm_slim", CubeListBuilder.create().texOffs(40, 16).addBox(-2, -2, -2, 3, 12, 4), PartPose.offset(-5, 2.5f, 0));
        root.addOrReplaceChild("s_larm_slim", CubeListBuilder.create().texOffs(32, 48).addBox(-1, -2, -2, 3, 12, 4), PartPose.offset(5, 2.5f, 0));
        root.addOrReplaceChild("s_rleg", CubeListBuilder.create().texOffs(0, 16).addBox(-2, 0, -2, 4, 12, 4), PartPose.offset(-1.9f, 12, 0));
        root.addOrReplaceChild("s_lleg", CubeListBuilder.create().texOffs(16, 48).addBox(-2, 0, -2, 4, 12, 4), PartPose.offset(1.9f, 12, 0));

        // ---- SKIN second layer (hat, jacket, sleeves, pants), same offsets as the vanilla player model ----
        CubeDeformation hatGrow = new CubeDeformation(0.5f);
        CubeDeformation grow = new CubeDeformation(0.25f);
        root.addOrReplaceChild("s_hat", CubeListBuilder.create().texOffs(32, 0).addBox(-4, -8, -4, 8, 8, 8, hatGrow), PartPose.offset(0, 0, 0));
        root.addOrReplaceChild("s_jacket", CubeListBuilder.create().texOffs(16, 32).addBox(-4, 0, -2, 8, 12, 4, grow), PartPose.offset(0, 0, 0));
        root.addOrReplaceChild("s_rsleeve", CubeListBuilder.create().texOffs(40, 32).addBox(-3, -2, -2, 4, 12, 4, grow), PartPose.offset(-5, 2, 0));
        root.addOrReplaceChild("s_lsleeve", CubeListBuilder.create().texOffs(48, 48).addBox(-1, -2, -2, 4, 12, 4, grow), PartPose.offset(5, 2, 0));
        root.addOrReplaceChild("s_rsleeve_slim", CubeListBuilder.create().texOffs(40, 32).addBox(-2, -2, -2, 3, 12, 4, grow), PartPose.offset(-5, 2.5f, 0));
        root.addOrReplaceChild("s_lsleeve_slim", CubeListBuilder.create().texOffs(48, 48).addBox(-1, -2, -2, 3, 12, 4, grow), PartPose.offset(5, 2.5f, 0));
        root.addOrReplaceChild("s_rpants", CubeListBuilder.create().texOffs(0, 32).addBox(-2, 0, -2, 4, 12, 4, grow), PartPose.offset(-1.9f, 12, 0));
        root.addOrReplaceChild("s_lpants", CubeListBuilder.create().texOffs(0, 48).addBox(-2, 0, -2, 4, 12, 4, grow), PartPose.offset(1.9f, 12, 0));

        // ---- FIGURE look: sizes are blocks * 16 from the prototype ----
        // origin of torso = chest pivot (box goes up), head = head pivot (box goes up), arms/legs hang down from the joint
        root.addOrReplaceChild("f_torso", CubeListBuilder.create().texOffs(0, 0).addBox(-3.04f, -12f, -1.6f, 6.08f, 12f, 3.2f), PartPose.ZERO);
        root.addOrReplaceChild("f_head", CubeListBuilder.create().texOffs(0, 0).addBox(-3.2f, -6.4f, -3.2f, 6.4f, 6.4f, 6.4f), PartPose.ZERO);
        root.addOrReplaceChild("f_arm_l", CubeListBuilder.create().texOffs(0, 0).addBox(-1.28f, 0f, -1.28f, 2.56f, 29.6f, 2.56f), PartPose.ZERO);
        root.addOrReplaceChild("f_arm_r", CubeListBuilder.create().texOffs(0, 0).addBox(-1.28f, 0f, -1.28f, 2.56f, 29.6f, 2.56f), PartPose.ZERO);
        root.addOrReplaceChild("f_leg_l", CubeListBuilder.create().texOffs(0, 0).addBox(-1.28f, 0f, -1.28f, 2.56f, 27.2f, 2.56f), PartPose.ZERO);
        root.addOrReplaceChild("f_leg_r", CubeListBuilder.create().texOffs(0, 0).addBox(-1.28f, 0f, -1.28f, 2.56f, 27.2f, 2.56f), PartPose.ZERO);

        // ---- GLITCH pixels around the black forms: completely FLAT 2x2 patches (zero depth, like a picture),
        //      whose UV points into a black/white/grey strip of the texture (x 56..64, y 16..48, unused by the
        //      player layout), 8 shades of 8x4 px each ----
        for (int i = 0; i < GLITCH_CUBES; i++) {
            root.addOrReplaceChild("g" + i, CubeListBuilder.create().texOffs(56, 16 + 4 * (i % 8)).addBox(-1f, -1f, 0f, 2f, 2f, 0f), PartPose.ZERO);
        }

        return LayerDefinition.create(mesh, 64, 64);
    }

    /** ModelPart.copyFrom(...) was removed in newer Minecraft versions, so the pose is copied by hand. */
    private static void copyPart(ModelPart to, ModelPart from) {
        to.x = from.x;
        to.y = from.y;
        to.z = from.z;
        to.xRot = from.xRot;
        to.yRot = from.yRot;
        to.zRot = from.zRot;
        to.xScale = from.xScale;
        to.yScale = from.yScale;
    }

    @Override
    public void setupAnim(LazurRenderState state) {
        super.setupAnim(state);
        boolean fig = state.appearance == LazurEntity.A_FIGURE;
        boolean blackPlayer = state.appearance == LazurEntity.A_BLACK_PLAYER;
        for (ModelPart g : glitch) g.visible = false;

        sHead.visible = sBody.visible = sRLeg.visible = sLLeg.visible = !fig;
        sRArm.visible = sLArm.visible = !fig && !state.slim;
        sRArmSlim.visible = sLArmSlim.visible = !fig && state.slim;
        for (ModelPart p : figure) p.visible = fig;

        LazurAnimator an = state.animator;
        if (an == null) return;
        an.update(state);

        if (fig) {
            for (int i = 0; i < 6; i++) {
                ModelPart p = figure[i];
                p.visible = an.visible;
                p.x = an.pos[i][0];
                p.y = an.pos[i][1];
                p.z = an.pos[i][2];
                p.xRot = an.rot[i][0];
                p.yRot = an.rot[i][1];
                p.zRot = an.rot[i][2];
                p.xScale = an.scale[i][0];
                p.yScale = an.scale[i][1];
            }
        } else {
            // skin look: stands still, head follows its yaw, tiny arm sway, glitch jitter
            sHead.yRot = state.yRot * DEG + (state.lazurState == LazurEntity.S_SPIN ? an.headSpin : 0f);
            sHead.xRot = state.xRot * DEG;
            float sway = (float) Math.sin(state.ageInTicks * 0.067f) * 0.03f;
            ModelPart rArm = state.slim ? sRArmSlim : sRArm;
            ModelPart lArm = state.slim ? sLArmSlim : sLArm;
            rArm.xRot = sway;
            lArm.xRot = -sway;
            if (blackPlayer) {
                // the black player runs and strikes: ordinary humanoid gait, arms up for the hit
                float spd = Math.min(1f, state.walkAnimationSpeed) * 1.2f;
                float ph = state.walkAnimationPos * 0.6662f;
                sRLeg.xRot = (float) Math.cos(ph) * 1.4f * spd;
                sLLeg.xRot = (float) Math.cos(ph + Math.PI) * 1.4f * spd;
                rArm.xRot = (float) Math.cos(ph + Math.PI) * 1.6f * spd;
                lArm.xRot = (float) Math.cos(ph) * 1.6f * spd;
                if (state.lazurState == LazurEntity.S_ATTACK) {
                    float p = Math.min(1f, an.stateSeconds() / 0.5f);
                    float swing = (float) Math.sin(p * Math.PI);
                    rArm.xRot = -swing * 2.5f - 0.2f;
                    lArm.xRot = -swing * 1.9f;
                }
            }
            if (state.lazurState == LazurEntity.S_GLITCH) {
                Random r = new Random((long) (state.ageInTicks / (20f / 12f)) * 7919L + 5L);
                for (int i = 0; i < 6; i++) {
                    ModelPart p = skinByIndex[i];
                    if (i == 2) p = lArm;
                    if (i == 3) p = rArm;
                    p.x += (r.nextFloat() - 0.5f) * 3.2f;
                    p.y += (r.nextFloat() - 0.5f) * 2.0f;
                    p.xScale = 1f + Math.abs((r.nextFloat() - 0.5f) * 1.8f) * (i % 3 != 0 ? 0.2f : 1f);
                    p.yScale = 1f + Math.abs((r.nextFloat() - 0.5f) * 2.4f) * (i % 2 != 0 ? 1f : 0.2f);
                }
                if (r.nextFloat() < 0.08f) {
                    sHead.visible = sBody.visible = sRLeg.visible = sLLeg.visible = false;
                    rArm.visible = lArm.visible = false;
                }
            }
        }

        // second layer follows the base layer exactly
        boolean show = !fig;
        ModelPart rArmNow = state.slim ? sRArmSlim : sRArm;
        ModelPart lArmNow = state.slim ? sLArmSlim : sLArm;
        copyPart(sHat, sHead);   sHat.visible = show && sHead.visible;
        copyPart(sJacket, sBody); sJacket.visible = show && sBody.visible;
        copyPart(sRPants, sRLeg); sRPants.visible = show && sRLeg.visible;
        copyPart(sLPants, sLLeg); sLPants.visible = show && sLLeg.visible;
        copyPart(sRSleeve, sRArm); copyPart(sLSleeve, sLArm);
        copyPart(sRSleeveSlim, sRArmSlim); copyPart(sLSleeveSlim, sLArmSlim);
        sRSleeve.visible = show && !state.slim && rArmNow.visible;
        sLSleeve.visible = show && !state.slim && lArmNow.visible;
        sRSleeveSlim.visible = show && state.slim && rArmNow.visible;
        sLSleeveSlim.visible = show && state.slim && lArmNow.visible;

        if (fig ? an.visible : blackPlayer) glitchAround(state, fig);
    }

    /** A few flat black-and-white pixel patches around the model, a new random pattern every 3 ticks. */
    private void glitchAround(LazurRenderState state, boolean tall) {
        Random r = new Random((long) (state.ageInTicks / 3f) * 6151L + 11L);
        float hx = tall ? 16f : 9f, hz = tall ? 8f : 5f;
        float y0 = tall ? -26f : -10f, y1 = tall ? 28f : 26f;
        for (int i = 0; i < GLITCH_CUBES; i++) {
            ModelPart g = glitch[i];
            if (r.nextFloat() > (tall ? 0.5f : 0.4f)) continue; // this patch is off in this pattern (so only ~2-3 show at once)
            g.visible = true;
            g.x = (r.nextFloat() * 2f - 1f) * hx;
            g.y = y0 + r.nextFloat() * (y1 - y0);
            g.z = (r.nextFloat() * 2f - 1f) * hz;
            g.xRot = g.yRot = g.zRot = 0f;
            if (r.nextInt(5) == 0) { // a torn horizontal band
                g.xScale = 5f + r.nextInt(6);
                g.yScale = 0.4f;
            } else {
                g.xScale = 1f + r.nextInt(5);
                g.yScale = 1f + r.nextInt(3) * 0.5f;
            }
        }
    }
}
