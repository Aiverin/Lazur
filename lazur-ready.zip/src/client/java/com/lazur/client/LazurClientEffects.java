package com.lazur.client;

import com.lazur.LazurMod;
import com.lazur.net.LazurNet;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.contents.TranslatableContents;

import java.util.Random;

/**
 * Small client effects:
 *  - the screen glitch that grows with every hit of the black player (from the sides to the whole screen, fades by itself)
 *  - during a chase the game cannot be paused (the pause menu does not stop the world) and the "save and quit" button
 *    of that menu is hidden and cannot be used. The world is NOT opened to the network for this.
 */
public final class LazurClientEffects {
    private LazurClientEffects() {}

    /** A chase is on (the server says so once a second and whenever it changes). */
    public static boolean chase;
    private static float glitch;   // 0..1
    private static int tick;

    public static void init() {
        ClientPlayNetworking.registerGlobalReceiver(LazurNet.ChaseFlag.TYPE, (payload, context) -> chase = payload.on());
        ClientPlayNetworking.registerGlobalReceiver(LazurNet.GlitchHit.TYPE,
                (payload, context) -> glitch = Math.min(1f, glitch + 0.24f));
        ClientTickEvents.END_CLIENT_TICK.register(LazurClientEffects::tick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> { chase = false; glitch = 0f; });
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, LazurMod.id("hit_glitch"), LazurClientEffects::extract);
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> onScreen(client, screen));
    }

    private static void tick(Minecraft mc) {
        tick++;
        if (mc.player == null || !mc.player.isAlive()) { glitch = 0f; return; }
        if (glitch > 0f) glitch = Math.max(0f, glitch - 0.0025f);   // from the top in about 20 s
    }

    // ---- pause / quit ----
    /** The pause menu that does not pause (isPauseScreen() is what makes a singleplayer game stop). */
    private static final class NoPausePauseScreen extends PauseScreen {
        NoPausePauseScreen(boolean showPauseMenu) { super(showPauseMenu); }

        @Override
        public boolean isPauseScreen() { return false; }
    }

    private static void onScreen(Minecraft client, Screen screen) {
        if (!chase) return;
        if (screen.getClass() == PauseScreen.class) {
            client.execute(() -> Compat.setScreen(client, new NoPausePauseScreen(true)));
            return;
        }
        if (screen instanceof PauseScreen) hideQuit(screen);
    }

    private static void hideQuit(Screen screen) {
        for (var child : screen.children()) {
            if (child instanceof AbstractWidget w && w.getMessage().getContents() instanceof TranslatableContents tc) {
                String key = tc.getKey();
                if (key.equals("menu.returnToMenu") || key.equals("menu.disconnect")) {
                    w.visible = false;
                    w.active = false;
                }
            }
        }
    }

    // ---- hit glitch ----
    private static void extract(GuiGraphicsExtractor g, DeltaTracker delta) {
        if (glitch <= 0.02f) return;
        var win = Minecraft.getInstance().getWindow();
        int sw = win.getGuiScaledWidth(), sh = win.getGuiScaledHeight();
        Random r = new Random((tick / 2) * 7919L + 31L);       // re-rolled every 2 ticks
        int cell = 6;
        int[] palette = {0xFFFFFF, 0xEAEAEA, 0x000000, 0x0A0A0A, 0x7A7A7A, 0xBDBDBD};   // black and white only
        for (int y = 0; y < sh; y += cell) {
            for (int x = 0; x < sw; x += cell) {
                float edge = Math.min(x, sw - x) / (sw * 0.5f);              // 0 at the sides, 1 in the middle
                float reach = glitch * 1.25f - edge * 0.9f;                  // grows from the sides, fills the screen at 1
                if (reach <= 0f || r.nextFloat() > Math.min(1f, reach * 1.6f)) continue;
                int w = cell * (1 + r.nextInt(3));
                int a = 0x90 + r.nextInt(0x70);
                g.fill(x, y, x + w, y + cell, (a << 24) | palette[r.nextInt(palette.length)]);
            }
        }
    }
}
