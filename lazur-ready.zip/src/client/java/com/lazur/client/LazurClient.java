package com.lazur.client;

import com.lazur.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.minecraft.client.renderer.entity.EntityRenderers;

public class LazurClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ModelLayerRegistry.registerModelLayer(LazurModel.LAYER, LazurModel::getTexturedModelData);
        EntityRenderers.register(ModEntities.LAZUR, LazurRenderer::new);
    }
}
