package com.lazur.client;

import com.lazur.LazurMod;
import com.lazur.entity.LazurEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.contents.TranslatableContents;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.RecordComponent;
import java.util.List;
import java.util.Random;

/**
 * Death messages name Lazur with a scrambled (obfuscated) name. The server sends it once; here the name in already
 * received chat lines is rewritten every 0.2-1.5 s to a new random text of 3-6 characters, so it "lags" in length.
 * It works through reflection on the chat list; if anything about it differs in this Minecraft version the effect
 * switches itself off and the name simply stays as a normal obfuscated "Lazur".
 */
public final class LazurChatGlitch {
    private static final Random R = new Random();
    private static final String CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private static long ticks, nextAt;
    private static boolean broken;
    private static Field allField;
    private static Method refresh;

    private LazurChatGlitch() {}

    @SuppressWarnings("unchecked")
    public static void tick(Minecraft mc) {
        if (broken || mc.gui == null) return;
        if (++ticks < nextAt) return;
        nextAt = ticks + 4 + R.nextInt(27);                 // 0.2 - 1.5 s
        try {
            ChatComponent chat = mc.gui.getChat();
            if (allField == null) {
                allField = ChatComponent.class.getDeclaredField("allMessages");
                allField.setAccessible(true);
                refresh = ChatComponent.class.getDeclaredMethod("refreshTrimmedMessages");
                refresh.setAccessible(true);
            }
            List<Object> all = (List<Object>) allField.get(chat);
            StringBuilder g = new StringBuilder();
            int len = 3 + R.nextInt(4);                      // 3 - 6 characters
            for (int i = 0; i < len; i++) g.append(CHARS.charAt(R.nextInt(CHARS.length())));
            boolean changed = false;
            for (int i = 0, n = Math.min(all.size(), 60); i < n; i++) {
                Object m = all.get(i);
                Component c = (Component) m.getClass().getMethod("content").invoke(m);
                if (!hasMark(c)) continue;
                all.set(i, copyWith(m, rebuild(c, g.toString())));
                changed = true;
            }
            if (changed) refresh.invoke(chat);
        } catch (Throwable t) {
            broken = true;
            LazurMod.LOGGER.warn("Lazur chat glitch disabled: {}", t.toString());
        }
    }

    private static boolean marked(Component c) {
        return LazurEntity.GLITCH_MARK.equals(c.getStyle().getInsertion());
    }

    private static boolean hasMark(Component c) {
        if (marked(c)) return true;
        if (c.getContents() instanceof TranslatableContents tc) {
            for (Object a : tc.getArgs()) if (a instanceof Component ac && hasMark(ac)) return true;
        }
        for (Component s : c.getSiblings()) if (hasMark(s)) return true;
        return false;
    }

    private static Component rebuild(Component c, String glitch) {
        if (marked(c)) return Component.literal(glitch).setStyle(c.getStyle());
        MutableComponent out;
        if (c.getContents() instanceof TranslatableContents tc) {
            Object[] args = tc.getArgs().clone();
            for (int i = 0; i < args.length; i++) if (args[i] instanceof Component ac) args[i] = rebuild(ac, glitch);
            out = Component.translatable(tc.getKey(), args);
        } else {
            out = c.plainCopy();
        }
        out.setStyle(c.getStyle());
        for (Component s : c.getSiblings()) out.append(rebuild(s, glitch));
        return out;
    }

    /** The chat line is a record (time, text, signature, tag): the same record with another text. */
    private static Object copyWith(Object m, Component text) throws Exception {
        Class<?> k = m.getClass();
        RecordComponent[] rc = k.getRecordComponents();
        Class<?>[] types = new Class<?>[rc.length];
        Object[] vals = new Object[rc.length];
        for (int i = 0; i < rc.length; i++) {
            types[i] = rc[i].getType();
            vals[i] = rc[i].getName().equals("content") ? text : rc[i].getAccessor().invoke(m);
        }
        Constructor<?> ctor = k.getDeclaredConstructor(types);
        ctor.setAccessible(true);
        return ctor.newInstance(vals);
    }
}
