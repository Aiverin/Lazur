package com.lazur.logic;

import com.lazur.state.LazurData;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/**
 * Debug commands: the real cooldowns are days long, so you need these to test.
 * NOTE: no permission check on purpose (singleplayer). Add .requires(...) before multiplayer.
 */
public final class LazurCommands {

    private static int msg(CommandContext<CommandSourceStack> c, String text) {
        c.getSource().sendSuccess(() -> Component.literal(text), false);
        return 1;
    }

    private static int result(CommandContext<CommandSourceStack> c, boolean ok, String yes, String no) {
        return msg(c, ok ? yes : no);
    }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(Commands.literal("lazur")
                        .then(Commands.literal("status").executes(c -> msg(c, LazurManager.status(c.getSource().getServer()))))
                        .then(Commands.literal("time").executes(c -> msg(c, "dawn clock: " + LazurTime.describe())))
                        .then(Commands.literal("silhouette").executes(c -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            return result(c, LazurManager.debugSilhouette(p), "silhouette spawned", "could not spawn (busy or no loaded spot)");
                        }))
                        .then(Commands.literal("sub").executes(c -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            return result(c, LazurManager.debugSubstitute(p), "substitution created (see /lazur status)", "no target in range (or something is already active)");
                        }))
                        .then(Commands.literal("reveal").executes(c -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            return result(c, LazurManager.debugReveal(p), "revealing", "no active substitution");
                        }))
                        .then(Commands.literal("chase").executes(c -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            return result(c, LazurManager.debugChase(p), "chase started", "busy");
                        }))
                        .then(Commands.literal("cave").executes(c -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            return result(c, LazurManager.debugCave(c.getSource().getServer(), p), "cave form placed: stare at him or walk up to him", "no room / something is already active");
                        }))
                        .then(Commands.literal("mob").executes(c -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            return result(c, LazurManager.debugMob(p), "Lazur now imitates a nearby animal (see /lazur status)", "no suitable animal in range (or something is already active)");
                        }))
                        .then(Commands.literal("grab").executes(c -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            return result(c, LazurManager.debugGrab(p), "grabbed (counts as a real grab: 7, 10, 13 hits...)", "busy, use /lazur clear first");
                        }))
                        .then(Commands.literal("dawn").executes(c -> {
                            int n = LazurManager.triggerDawn(LazurData.get(c.getSource().getServer()));
                            return msg(c, "dawn forced, " + n + " block(s) due to return");
                        }))
                        .then(Commands.literal("anim")
                                .then(Commands.argument("state", StringArgumentType.word()).executes(c -> {
                                    ServerPlayer p = c.getSource().getPlayerOrException();
                                    String name = StringArgumentType.getString(c, "state");
                                    return result(c, LazurManager.debugAnim(p, name),
                                            "spawned test model: " + name + " (idle walk creep run attack grab glitch fade skin). /lazur clear removes it",
                                            "busy, use /lazur clear first");
                                })))
                        .then(Commands.literal("ambient").executes(c -> {
                            LazurManager.debugAmbient(c.getSource().getPlayerOrException());
                            return msg(c, "ambient sound played");
                        }))
                        .then(Commands.literal("clear").executes(c -> {
                            LazurManager.debugClear(c.getSource().getServer());
                            return msg(c, "cleared");
                        }))
                        .then(Commands.literal("reset").executes(c -> {
                            LazurManager.debugClear(c.getSource().getServer());
                            LazurData.get(c.getSource().getServer()).resetAll();
                            return msg(c, "all Lazur data reset");
                        }))));
    }

    private LazurCommands() {}
}
