package com.lazur.logic;

import com.lazur.LazurMod;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;

import java.lang.reflect.Method;

/**
 * Minecraft 26.1 introduced world clocks and the old day-time getter may have moved.
 * Instead of guessing, this tries the known names via reflection and falls back to game time.
 * /lazur time prints which one is used. Once you know the right call, replace readTime() with it.
 */
public final class LazurTime {
    private static Method method;
    private static String used = "unresolved";
    private static boolean resolved;

    public static long dayIndex(MinecraftServer server) {
        return Math.floorDiv(readTime(server.overworld()), 24000L);
    }

    public static long gameTimeOf(MinecraftServer server) {
        return server.overworld().getGameTime();
    }

    public static String describe() {
        return used;
    }

    private static long readTime(ServerLevel level) {
        if (!resolved) {
            resolved = true;
            used = "gameTime fallback (dawn will not follow sleeping!)";
            for (String name : new String[]{"getDayTime", "getDefaultClockTime", "getOverworldClockTime", "getClockTime"}) {
                try {
                    Method m = level.getClass().getMethod(name);
                    Class<?> rt = m.getReturnType();
                    if (rt == long.class || rt == int.class) {
                        method = m;
                        used = name + "()";
                        break;
                    }
                } catch (NoSuchMethodException ignored) { }
            }
            LazurMod.LOGGER.info("Lazur dawn clock source: {}", used);
        }
        if (method != null) {
            try {
                return ((Number) method.invoke(level)).longValue();
            } catch (ReflectiveOperationException e) {
                method = null;
                used = "gameTime fallback (reflection failed)";
            }
        }
        return level.getGameTime();
    }

    private LazurTime() {}
}
