package com.lazur.logic;

import com.lazur.LazurConfig;
import com.lazur.entity.LazurEntity;
import com.lazur.net.LazurNet;
import com.lazur.state.LazurData;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

/**
 * The grab. When the tall Lazur's strike lands he picks the player up in one hand, face to face, and a mini-game starts:
 *  - 1.2 s of lifting (no keys yet), then a line of W/A/S/D keys that must be pressed IN ORDER (5 keys the first time,
 *    then 8, 11, 14, 17; the counter resets when the player dies)
 *  - an "air" gauge on the right runs down: 15 s the first time, then 13, 11, 9, never less than 7
 *  - all keys pressed correctly in time: Lazur lets go (the player gets 2 s to run)
 *  - the 2nd wrong key or an empty gauge kills the player at once; the death handler sends him to the world spawn
 *
 * The server owns everything (the sequence, the timer, the judging); the client only draws it and reports key presses.
 * Singleplayer only, like the rest of the mod: one grab at a time.
 */
public final class LazurGrab {
    private static Session s;
    /** After a release Lazur stands still for this many ticks (counted down by LazurManager). */
    public static int releaseTicks;

    private LazurGrab() {}

    private static final class Session {
        final ServerPlayer player;
        final LazurEntity lz;
        final float yaw;
        final int[] keys;
        final int totalTicks;
        int done, errors, age;

        Session(ServerPlayer player, LazurEntity lz, float yaw, int[] keys, int totalTicks) {
            this.player = player;
            this.lz = lz;
            this.yaw = yaw;
            this.keys = keys;
            this.totalTicks = totalTicks;
        }
    }

    public static boolean active() { return s != null; }

    // =====================================================================================
    // start
    // =====================================================================================
    public static void begin(LazurData d, ServerPlayer p, LazurEntity lz) {
        if (s != null) return;
        LazurConfig cfg = LazurConfig.get();
        ServerLevel level = (ServerLevel) p.level();

        int level0 = d.grabLevel;                                                       // 0 for the first grab since the last death
        int count = Math.min(cfg.grabMaxKeys, cfg.grabBaseKeys + cfg.grabKeysStep * level0); // 5, 8, 11, 14, 17
        int seconds = Math.max(cfg.grabTimeMinSec, cfg.grabTimeStartSec - cfg.grabTimeStepSec * level0); // 15, 13, 11, 9, 7
        d.grabLevel++;
        d.setDirty();

        RandomSource r = level.getRandom();
        int[] keys = new int[count];
        for (int i = 0; i < count; i++) keys[i] = r.nextInt(4);

        float yaw = (float) Math.toDegrees(Math.atan2(-(p.getX() - lz.getX()), p.getZ() - lz.getZ()));
        s = new Session(p, lz, yaw, keys, seconds * 20);
        releaseTicks = 0;

        lz.getNavigation().stop();
        holdLazur(s);

        p.setNoGravity(true);          // floats in Lazur's hand
        p.setSprinting(false);
        p.setDeltaMovement(Vec3.ZERO);
        p.resetFallDistance();

        ServerPlayNetworking.send(p, new LazurNet.GrabStart(lz.getId(), keys, seconds * 20));
    }

    private static void holdLazur(Session g) {
        LazurEntity lz = g.lz;
        lz.getNavigation().stop();
        lz.setLazurState(LazurEntity.S_GRAB);
        lz.setYRot(g.yaw);
        lz.setYBodyRot(g.yaw);
        lz.setYHeadRot(g.yaw);
    }

    // =====================================================================================
    // tick (called by LazurManager instead of the chase brain while grabbing)
    // =====================================================================================
    public static void tick(ServerLevel level, ServerPlayer player, LazurEntity lz) {
        Session g = s;
        if (g == null) return;
        if (g.player != player || g.lz != lz || !player.isAlive() || player.isRemoved() || lz.isRemoved()) {
            abort();
            return;
        }
        LazurConfig cfg = LazurConfig.get();
        g.age++;
        holdLazur(g);
        player.setNoGravity(true);
        player.resetFallDistance();

        int used = Math.max(0, g.age - cfg.grabIntroTicks);   // the air starts to run out after the lift
        if (used >= g.totalTicks) {                            // out of air
            kill(level, g);
            return;
        }
        float air = 1f - used / (float) g.totalTicks;
        ServerPlayNetworking.send(player, new LazurNet.GrabState(air, g.done, g.errors));
    }

    // =====================================================================================
    // a key press (client -> server)
    // =====================================================================================
    public static void key(ServerPlayer player, int key) {
        Session g = s;
        if (g == null || g.player != player || key < 0 || key > 3) return;
        LazurConfig cfg = LazurConfig.get();
        if (g.age <= cfg.grabIntroTicks) return;               // still being lifted: presses do not count
        ServerLevel level = (ServerLevel) player.level();
        if (key == g.keys[g.done]) {
            g.done++;
            if (g.done >= g.keys.length) release(level, g);    // the whole line pressed in time
        } else {
            g.errors++;
            level.playSound(null, player.getX(), player.getY(), player.getZ(), com.lazur.registry.ModSounds.LAZUR_MISS,
                    SoundSource.PLAYERS, 1.0F, 1.0F);
            if (g.errors >= cfg.grabMaxErrors) kill(level, g);
        }
    }

    // =====================================================================================
    // endings
    // =====================================================================================
    private static void release(ServerLevel level, Session g) {
        s = null;
        ServerPlayer p = g.player;
        p.setNoGravity(false);
        p.resetFallDistance();
        releaseTicks = 40; // 2 s head start for the player (fixed here: an old config file must not shorten it)
        g.lz.resetAttack();
        g.lz.setAttackCooldown(releaseTicks + 20);
        g.lz.setLazurState(LazurEntity.S_IDLE);
        ServerPlayNetworking.send(p, new LazurNet.GrabEnd(LazurNet.END_RELEASED));
    }

    private static void kill(ServerLevel level, Session g) {
        s = null;
        releaseTicks = 0;
        ServerPlayer p = g.player;
        p.setNoGravity(false);
        p.resetFallDistance();
        ServerPlayNetworking.send(p, new LazurNet.GrabEnd(LazurNet.END_ABORT));
        // (no growl here: add your own sound when Lazur kills)
        // instant, bypasses totems and creative; the death handler then sends the player to the world spawn
        // its own damage type (data/lazur/damage_type/lazur_kill.json: message "was slain by", in the same bypass tags as
        // genericKill), so the death message names Lazur (a glitchy name) instead of "died"
        net.minecraft.world.damagesource.DamageSource src;
        try {
            var types = level.registryAccess().lookupOrThrow(net.minecraft.core.registries.Registries.DAMAGE_TYPE);
            src = new net.minecraft.world.damagesource.DamageSource(types.getOrThrow(net.minecraft.resources.ResourceKey.create(
                    net.minecraft.core.registries.Registries.DAMAGE_TYPE, com.lazur.LazurMod.id("lazur_kill"))), g.lz);
        } catch (RuntimeException e) {
            src = level.damageSources().genericKill();
        }
        p.hurtServer(level, src, Float.MAX_VALUE);
    }

    /** The grab ends without a result (Lazur or the player vanished). */
    private static void abort() {
        Session g = s;
        s = null;
        releaseTicks = 0;
        if (g == null) return;
        g.player.setNoGravity(false);
        g.player.resetFallDistance();
        if (g.player.isAlive() && !g.player.isRemoved()) {
            ServerPlayNetworking.send(g.player, new LazurNet.GrabEnd(LazurNet.END_ABORT));
        }
    }

    /** Player died / chase ended for another reason: drop everything quietly. */
    public static void clear() {
        abort();
    }
}
