package com.lazur.logic;

import com.lazur.LazurConfig;
import com.lazur.entity.LazurEntity;
import com.lazur.net.LazurNet;
import com.lazur.state.LazurData;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

/**
 * The grab. When Lazur's strike lands he picks the player up in one hand, face to face, and a timing mini-game starts:
 *  - a gauge at the bottom keeps filling; hits in timing push it back, mistakes fill it
 *  - prompts (W/A/S/D at a random spot of the screen with a shrinking ring) come one after another
 *  - N hits in timing (7, then 10, 13, ...) break free; Lazur then stands still for 1.5 s
 *  - the 2nd mistake (or a full gauge) kills the player at once; the death handler sends him to the world spawn
 *
 * The server owns the whole state machine and the randomness. The client only draws it, judges the key press
 * against its own ring animation (no lag problems) and reports the result of every prompt.
 * Singleplayer only, like the rest of the mod: one grab at a time.
 */
public final class LazurGrab {
    /** The client may be a bit late with its report, then a prompt without a result counts as a miss. */
    private static final int MISS_GRACE_TICKS = 12;

    private static Session s;
    /** After a release Lazur stands still for this many ticks (counted down by LazurManager). */
    public static int releaseTicks;

    private LazurGrab() {}

    private static final class Session {
        final ServerPlayer player;
        final LazurEntity lz;
        final float yaw;
        final int needed;
        int hits, errors, age;
        float bar;
        int promptId, promptStart, promptDuration, nextPrompt, lastKey = -1;
        boolean promptActive;

        Session(ServerPlayer player, LazurEntity lz, float yaw, int needed) {
            this.player = player;
            this.lz = lz;
            this.yaw = yaw;
            this.needed = needed;
        }
    }

    public static boolean active() { return s != null; }

    // =====================================================================================
    // start
    // =====================================================================================
    public static void begin(LazurData d, ServerPlayer p, LazurEntity lz) {
        if (s != null) return;
        LazurConfig cfg = LazurConfig.get();
        ServerLevel level = (ServerLevel) p.level();

        int needed = cfg.grabBaseHits + cfg.grabHitsStep * d.grabLevel; // 7, 10, 13, ...
        d.grabLevel++;
        d.setDirty();

        float yaw = (float) Math.toDegrees(Math.atan2(-(p.getX() - lz.getX()), p.getZ() - lz.getZ()));
        s = new Session(p, lz, yaw, needed);
        s.bar = (float) cfg.grabBarStart;
        s.nextPrompt = cfg.grabIntroTicks;
        releaseTicks = 0;

        lz.getNavigation().stop();
        holdLazur(s);

        p.setNoGravity(true);          // floats in Lazur's hand
        p.setSprinting(false);
        p.setDeltaMovement(Vec3.ZERO);
        p.resetFallDistance();

        ServerPlayNetworking.send(p, new LazurNet.GrabStart(lz.getId()));
    }

    private static void holdLazur(Session g) {
        LazurEntity lz = g.lz;
        lz.getNavigation().stop();
        lz.setLazurState(LazurEntity.S_GRAB);
        lz.setYRot(g.yaw);
        lz.setYBodyRot(g.yaw);
        lz.setYHeadRot(g.yaw);
    }

    // =====================================================================================
    // tick (called by LazurManager instead of the chase brain while grabbing)
    // =====================================================================================
    public static void tick(ServerLevel level, ServerPlayer player, LazurEntity lz) {
        Session g = s;
        if (g == null) return;
        if (g.player != player || g.lz != lz || !player.isAlive() || player.isRemoved() || lz.isRemoved()) {
            abort();
            return;
        }
        LazurConfig cfg = LazurConfig.get();
        g.age++;
        holdLazur(g);
        player.setNoGravity(true);
        player.resetFallDistance();

        if (g.age > cfg.grabIntroTicks) g.bar += (float) (cfg.grabBarFillPerSecond / 20.0);

        // a prompt that nobody answered
        if (g.promptActive && g.age > g.promptStart + g.promptDuration + MISS_GRACE_TICKS) {
            result(player, g.promptId, LazurNet.R_MISS);
            if (s != g) return;
        }
        if (g.bar >= 1f) {
            kill(level, g);
            return;
        }
        if (!g.promptActive && g.age >= g.nextPrompt) newPrompt(level, g, cfg);

        ServerPlayNetworking.send(player, new LazurNet.GrabState(Math.min(1f, g.bar)));
    }

    private static void newPrompt(ServerLevel level, Session g, LazurConfig cfg) {
        RandomSource r = level.getRandom();
        int key;
        do { key = r.nextInt(4); } while (key == g.lastKey && r.nextInt(3) != 0); // mostly a different key each time
        g.lastKey = key;

        int dur = cfg.grabPromptMinTicks + r.nextInt(Math.max(1, cfg.grabPromptMaxTicks - cfg.grabPromptMinTicks + 1));
        int win = Math.round(dur * (0.66f + r.nextFloat() * 0.08f));   // pressing counts over the last ~third of the ring
        float x = 0.16f + r.nextFloat() * 0.68f;                         // random part of the screen,
        float y = 0.16f + r.nextFloat() * 0.50f;                         // but above the gauge
        int startRadius = 56 + r.nextInt(44);
        int curve = r.nextInt(3);

        g.promptId++;
        g.promptActive = true;
        g.promptStart = g.age;
        g.promptDuration = dur;
        ServerPlayNetworking.send(g.player, new LazurNet.GrabPrompt(g.promptId, key, x, y, dur, win, startRadius, curve));
    }

    // =====================================================================================
    // result of a prompt (client -> server)
    // =====================================================================================
    public static void result(ServerPlayer player, int id, int code) {
        Session g = s;
        if (g == null || g.player != player || !g.promptActive || id != g.promptId) return;
        LazurConfig cfg = LazurConfig.get();
        ServerLevel level = (ServerLevel) player.level();
        RandomSource r = level.getRandom();

        g.promptActive = false;
        g.nextPrompt = g.age + cfg.grabGapMinTicks + r.nextInt(Math.max(1, cfg.grabGapMaxTicks - cfg.grabGapMinTicks + 1));

        if (code == LazurNet.R_HIT) {
            g.hits++;
            g.bar = Math.max(0f, g.bar - (float) cfg.grabBarHitRelief);
            // no sound on a hit
            if (g.hits >= g.needed) release(level, g);
        } else {
            g.errors++;
            g.bar += (float) cfg.grabBarErrorPenalty;
            level.playSound(null, player.getX(), player.getY(), player.getZ(), com.lazur.registry.ModSounds.LAZUR_MISS,
                    SoundSource.PLAYERS, 1.0F, 1.0F);
            if (g.errors >= cfg.grabMaxErrors || g.bar >= 1f) kill(level, g);
        }
    }

    // =====================================================================================
    // endings
    // =====================================================================================
    private static void release(ServerLevel level, Session g) {
        s = null;
        ServerPlayer p = g.player;
        p.setNoGravity(false);
        p.resetFallDistance();
        releaseTicks = 40; // 2 s head start for the player (fixed here: an old config file must not shorten it)
        g.lz.resetAttack();
        g.lz.setAttackCooldown(releaseTicks + 20);
        g.lz.setLazurState(LazurEntity.S_IDLE);
        ServerPlayNetworking.send(p, new LazurNet.GrabEnd(LazurNet.END_RELEASED));
    }

    private static void kill(ServerLevel level, Session g) {
        s = null;
        releaseTicks = 0;
        ServerPlayer p = g.player;
        p.setNoGravity(false);
        p.resetFallDistance();
        ServerPlayNetworking.send(p, new LazurNet.GrabEnd(LazurNet.END_ABORT));
        // (no growl here: add your own sound when Lazur kills)
        // instant, bypasses totems and creative; the death handler then sends the player to the world spawn
        // its own damage type (data/lazur/damage_type/lazur_kill.json: message "was slain by", in the same bypass tags as
        // genericKill), so the death message names Lazur (a glitchy name) instead of "died"
        net.minecraft.world.damagesource.DamageSource src;
        try {
            var types = level.registryAccess().lookupOrThrow(net.minecraft.core.registries.Registries.DAMAGE_TYPE);
            src = new net.minecraft.world.damagesource.DamageSource(types.getOrThrow(net.minecraft.resources.ResourceKey.create(
                    net.minecraft.core.registries.Registries.DAMAGE_TYPE, com.lazur.LazurMod.id("lazur_kill"))), g.lz);
        } catch (RuntimeException e) {
            src = level.damageSources().genericKill();
        }
        p.hurtServer(level, src, Float.MAX_VALUE);
    }

    /** The grab ends without a result (Lazur or the player vanished). */
    private static void abort() {
        Session g = s;
        s = null;
        releaseTicks = 0;
        if (g == null) return;
        g.player.setNoGravity(false);
        g.player.resetFallDistance();
        if (g.player.isAlive() && !g.player.isRemoved()) {
            ServerPlayNetworking.send(g.player, new LazurNet.GrabEnd(LazurNet.END_ABORT));
        }
    }

    /** Player died / chase ended for another reason: drop everything quietly. */
    public static void clear() {
        abort();
    }
}
