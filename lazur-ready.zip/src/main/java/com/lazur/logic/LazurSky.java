package com.lazur.logic;

import com.lazur.LazurMod;
import com.lazur.entity.LazurEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;

/**
 * The world during a chase: time stands still and every mob (except Lazur) freezes (no AI). Both come back after it.
 * Time stands still for the whole chase. When the chase is over the sky flickers
 * day, night, day, night and then goes back to the time the chase started, and time flows again.
 * The time is set with the vanilla /time command (silently), so it does not depend on how this Minecraft version
 * stores the clock, and the clients get the new time at once.
 */
public final class LazurSky {
    private static final int FLICKER_STEP = 5;          // ticks per phase
    private static final int PHASES = 4;                // day, night, day, night
    private static long frozen = -1L;                   // the time the chase started at; -1 = not frozen
    private static int flick = -1;                      // ticks since the chase ended, -1 = not flickering
    private static boolean failed;
    private static final String TAG = "lazur_frozen"; // frozen mobs carry it, so a restart or an unloaded chunk cannot leave them frozen
    private static int sweep;

    public static void update(MinecraftServer server, boolean chasing) {
        if (chasing) {
            if (frozen < 0L) { frozen = LazurTime.now(server); flick = -1; }
            set(server, frozen);                         // holds it still, every tick
            if (server.getTickCount() % 10 == 0) freezeMobs(server); // also catches mobs that appear during the chase
            return;
        }
        if (frozen < 0L) {
            if (++sweep % 200 == 0) thawMobs(server);    // after a restart / for mobs from chunks that were unloaded
            return;
        }
        if (flick < 0) flick = 0;
        int phase = flick / FLICKER_STEP;
        long base = Math.floorDiv(frozen, 24000L) * 24000L; // stay inside the same day (the dawn counter must not move)
        if (phase < PHASES) {
            if (flick % FLICKER_STEP == 0) set(server, base + (phase % 2 == 0 ? 6000L : 18000L));
            flick++;
        } else {
            set(server, frozen);
            frozen = -1L;
            flick = -1;
            thawMobs(server);                            // the mobs come to life as the time starts to flow
        }
    }

    private static void freezeMobs(MinecraftServer server) {
        for (ServerLevel l : server.getAllLevels()) {
            for (Entity e : l.getAllEntities()) {
                if (e instanceof Mob m && !(e instanceof LazurEntity) && !m.isNoAi()) {
                    m.setNoAi(true);
                    m.setTarget(null);
                    m.getNavigation().stop();
                    m.addTag(TAG);
                }
            }
        }
    }

    private static void thawMobs(MinecraftServer server) {
        for (ServerLevel l : server.getAllLevels()) {
            for (Entity e : l.getAllEntities()) {
                if (e instanceof Mob m && m.removeTag(TAG)) { // true only if it carried the tag
                    m.setNoAi(false);
                }
            }
        }
    }

    private static void set(MinecraftServer server, long time) {
        if (failed) return;
        try {
            server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(), "time set " + time);
        } catch (RuntimeException e) {
            failed = true;
            LazurMod.LOGGER.warn("Lazur could not set the time: {}", e.toString());
        }
    }

    private LazurSky() {}
}
