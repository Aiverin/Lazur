package com.lazur.logic;

import net.fabricmc.fabric.api.entity.event.v1.EntitySleepEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.server.level.ServerPlayer;

public final class LazurEvents {
    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(LazurManager::tick);

        UseBlockCallback.EVENT.register((player, level, hand, hit) -> LazurManager.onUseBlock(player, level, hand, hit));

        PlayerBlockBreakEvents.BEFORE.register((level, player, pos, state, blockEntity) -> LazurManager.onBreakBlock(level, player, pos));

        EntitySleepEvents.STOP_SLEEPING.register((entity, pos) -> LazurManager.onStopSleeping(entity, pos));

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof ServerPlayer p) LazurManager.onPlayerDeath(p);
        });

        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> LazurManager.onRespawn(newPlayer));
    }

    private LazurEvents() {}
}
