package com.lazur.logic;

import com.lazur.LazurConfig;
import com.lazur.entity.LazurEntity;
import com.lazur.state.LazurData;
import com.lazur.state.LazurData.Ret;
import com.lazur.state.LazurData.Sub;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/**
 * Server-side brain. Singleplayer only: it works with the first player on the server.
 * Concept doc sections 3-8.
 */
public final class LazurManager {
    public static final int ROLE_NONE = 0, ROLE_SILHOUETTE = 1, ROLE_CHASE = 2, ROLE_REVEAL = 3, ROLE_TEST = 4, ROLE_CAVE = 5;
    public static final int SUB_BLOCK = 1, SUB_BED = 2, SUB_MOB = 3;

    private static long nextTry = 0;

    private LazurManager() {}

    // =====================================================================================
    // helpers
    // =====================================================================================
    private static ServerLevel levelOf(ServerPlayer p) { return (ServerLevel) p.level(); }

    private static int rand(RandomSource r, int min, int max) { return min + r.nextInt(Math.max(1, max - min + 1)); }

    private static LazurEntity findLazur(ServerLevel level, LazurData d) {
        if (d.lazurId == null) return null;
        return level.getEntity(d.lazurId) instanceof LazurEntity l ? l : null;
    }

    public static boolean owns(LazurEntity e) {
        if (!(e.level() instanceof ServerLevel sl)) return true;
        LazurData d = LazurData.get(sl.getServer());
        return e.getUUID().equals(d.lazurId);
    }

    private static LazurEntity spawn(ServerLevel level, Vec3 pos, float yaw, int appearance, int state) {
        return spawn(level, pos, yaw, appearance, state, false);
    }

    /** playerSized = the cave form (hitbox of a player). */
    private static LazurEntity spawn(ServerLevel level, Vec3 pos, float yaw, int appearance, int state, boolean playerSized) {
        LazurEntity lz = new LazurEntity(playerSized ? com.lazur.registry.ModEntities.LAZUR_PLAYER
                : com.lazur.registry.ModEntities.LAZUR, level);
        lz.setPos(pos.x, pos.y, pos.z);
        lz.setYRot(yaw);
        lz.setYBodyRot(yaw);
        lz.setYHeadRot(yaw);
        lz.setAppearance(appearance);
        lz.setLazurState(state);
        level.addFreshEntity(lz);
        return lz;
    }

    private static void placeFree(ServerLevel level, LazurEntity lz, Vec3 base) {
        for (int dy = 0; dy <= 3; dy++) {
            for (int r = 0; r <= 2; r++) {
                for (int dx = -r; dx <= r; dx++) {
                    for (int dz = -r; dz <= r; dz++) {
                        if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
                        lz.setPos(base.x + dx, base.y + dy, base.z + dz);
                        if (level.noCollision(lz)) return;
                    }
                }
            }
        }
        lz.setPos(base.x, base.y, base.z);
    }

    /** The sound of Lazur showing himself (the reveal). */
    private static void revealSound(ServerLevel level, LazurEntity lz) {
        level.playSound(null, lz.getX(), lz.getY(), lz.getZ(), com.lazur.registry.ModSounds.LAZUR_REVEAL,
                SoundSource.HOSTILE, 2.0F, 1.0F);
    }

    private static void roar(ServerLevel level, LazurEntity lz) {
        // the dragon growl was removed on purpose: put your own sound here later

    }

    /** One line, isolated: if setRespawnPosition changed in 26.2, fix it here. null = no custom spawn = world spawn. */
    private static void clearRespawnPoint(ServerPlayer player) {
        player.setRespawnPosition(null, false);
    }

    private static double minHomeDist(LazurData d, ServerPlayer p) {
        double best = Double.MAX_VALUE;
        for (int[] h : d.homes) best = Math.min(best, Math.hypot(p.getX() - h[0], p.getZ() - h[1]));
        return best;
    }

    // =====================================================================================
    // main tick
    // =====================================================================================
    public static void tick(MinecraftServer server) {
        List<ServerPlayer> players = server.getPlayerList().getPlayers();
        if (players.isEmpty()) return;
        ServerPlayer player = players.get(0);
        ServerLevel level = levelOf(player);
        LazurData d = LazurData.get(server);
        LazurConfig cfg = LazurConfig.get();
        RandomSource rnd = level.getRandom();
        boolean chasing = d.role == ROLE_CHASE || d.role == ROLE_REVEAL;
        LazurSky.update(server, chasing); // time stands still in a chase, flickers after it
        tickTrails();
        if (chasing != lastChaseFlag || server.getTickCount() % 20 == 0) { // the client: no pause and no "quit" button in a chase
            lastChaseFlag = chasing;
            net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(player, new com.lazur.net.LazurNet.ChaseFlag(chasing));
        }

        if (!d.initialized) {
            d.initialized = true;
            d.silCd = rand(rnd, cfg.silhouetteCdMin, cfg.silhouetteCdMax);
            d.subCd = rand(rnd, cfg.subCdMin, cfg.subCdMax);
            d.homes.add(new int[]{player.getBlockX(), player.getBlockZ()});
            d.lastDay = LazurTime.dayIndex(server);
            d.stage = 0;                                   // quiet start: nothing happens for 15-25 minutes, then the "connection" error
            d.preTicks = 0;
            d.kickNeed = rand(rnd, 18000, 30000);          // 15-25 minutes
            d.setDirty();
        }
        if (!player.isAlive()) return;

        if (d.stage == 0 && ++d.preTicks >= d.kickNeed) {  // the fake network error
            kickPlayer(d, player, rnd);
            return;
        }

        long gameNow = server.overworld().getGameTime();
        if (d.ambNext == 0) { // not scheduled yet (new world or data from an older version)
            // first ambient 4 days after world creation; in an older world: 3-7 days from now
            d.ambNext = gameNow < 96000L ? 96000L : gameNow + rand(rnd, 72000, 168000);
            d.setDirty();
        }
        if (d.stage >= 2 && gameNow >= d.ambNext) {
            if (d.role == ROLE_CHASE || d.role == ROLE_REVEAL) {
                d.ambNext = gameNow + 1200; // not during a chase, try again in a minute
            } else {
                playAmbient(level, player);
                d.ambNext = gameNow + rand(rnd, 72000, 168000); // next one in 3-7 days
            }
            d.setDirty();
        }

        boolean overworld = level.dimension() == Level.OVERWORLD;

        if (d.silCd > 0) d.silCd--;
        if (d.role == ROLE_NONE && d.sub == null && d.subCd > 0) d.subCd--;

        dawnCheck(server, d);
        if (server.getTickCount() % 10 == 0) returnsTick(server, d, player);

        if (overworld) {
            if (minHomeDist(d, player) > cfg.farRadiusBlocks) d.farTicks++; else d.farTicks = 0;
        }

        tickRole(server, d, player, level, rnd, cfg);
        if (d.sub != null && overworld) tickSub(server, d, player, level, rnd, cfg);
        if (d.bedAttack > 0 && --d.bedAttack == 0) bedAttackNow(server, d, player, level, rnd, cfg);

        if (d.role == ROLE_NONE && d.sub == null && overworld && server.getTickCount() % 20 == 0) {
            trySpawn(server, d, player, level, rnd, cfg, false);
        }
        if (d.stage >= 2 && d.role == ROLE_NONE && d.sub == null && overworld) tickCaveTimer(server, d, player, level, rnd, cfg);
        if (server.getTickCount() % 20 == 0) tickSign(server, d, player, level);
        if (server.getTickCount() % 20 == 0) d.setDirty();
    }

    // =====================================================================================
    // dawn + returning blocks
    // =====================================================================================
    private static void dawnCheck(MinecraftServer server, LazurData d) {
        long day = LazurTime.dayIndex(server);
        if (day > d.lastDay) {
            d.lastDay = day;
            triggerDawn(d);
        } else if (day < d.lastDay) {
            d.lastDay = day; // time was set back
        }
    }

    public static int triggerDawn(LazurData d) {
        int n = 0;
        for (Ret r : d.returns) {
            if (r.status == LazurData.READY) { r.status = LazurData.DUE; n++; }
        }
        d.setDirty();
        return n;
    }

    private static void returnsTick(MinecraftServer server, LazurData d, ServerPlayer player) {
        ServerLevel ow = server.overworld();
        Iterator<Ret> it = d.returns.iterator();
        while (it.hasNext()) {
            Ret r = it.next();
            BlockPos pos = r.pos();
            if (r.status == LazurData.DUE) {
                if (!ow.hasChunkAt(pos)) continue; // comes back when the chunk loads
                BlockState cur = ow.getBlockState(pos);
                if (cur.isAir() || cur.canBeReplaced()) {
                    BlockSnapshot.restore(ow, r);
                } // else: the spot was built over, the original is gone forever
                it.remove();
                d.setDirty();
            } else if (r.particles && levelOf(player) == ow && ow.hasChunkAt(pos)) {
                Vec3 c = Vec3.atCenterOf(pos);
                if (player.position().distanceToSqr(c) < 24 * 24 && Sight.inView(player, c, 0.9)
                        && Sight.pointVisible(ow, player, player.getEyePosition(), c, pos)) {
                    ow.sendParticles(ParticleTypes.SQUID_INK, c.x, c.y, c.z, 3, 0.25, 0.25, 0.25, 0.01);
                    r.seen += 10;
                    if (r.seen >= 40) r.particles = false; // seen it: the particles are gone
                    d.setDirty();
                }
            }
        }
    }

    private static void promoteHeldReturns(LazurData d) {
        for (Ret r : d.returns) if (r.status == LazurData.HOLD) r.status = LazurData.READY;
        d.setDirty();
    }

    // =====================================================================================
    // roles: silhouette / reveal / chase
    // =====================================================================================
    private static void tickRole(MinecraftServer server, LazurData d, ServerPlayer player, ServerLevel level,
                                 RandomSource rnd, LazurConfig cfg) {
        if (d.role == ROLE_NONE || d.role == ROLE_TEST) return;
        LazurEntity lz = findLazur(level, d);
        if (lz == null) {
            if (++d.missing > 200) endRoleAbnormally(server, d, rnd, cfg);
            return;
        }
        d.missing = 0;
        switch (d.role) {
            case ROLE_SILHOUETTE -> tickSilhouette(d, player, level, lz, rnd, cfg);
            case ROLE_CAVE -> tickCave(d, player, level, lz, rnd, cfg);
            case ROLE_REVEAL -> {
                if (d.phaseTicks == 12 && lz.isPlayerSized()) lz.setAppearance(LazurEntity.A_BLACK_PLAYER); // the cave form turns black mid-glitch
                if (--d.phaseTicks <= 0) beginChase(d, level, lz, cfg);
            }
            case ROLE_CHASE -> tickChase(d, player, level, lz, rnd, cfg);
            default -> { }
        }
    }

    private static void tickSilhouette(LazurData d, ServerPlayer player, ServerLevel level, LazurEntity lz,
                                       RandomSource rnd, LazurConfig cfg) {
        switch (d.phase) {
            case 0 -> { // standing at the edge of visibility
                d.age++;
                lz.getLookControl().setLookAt(player, 40.0F, 40.0F); // his gaze follows the player
                Vec3 eye = lz.position().add(0, lz.getBbHeight() * 0.85, 0);
                boolean seen = Sight.inView(player, eye, 0.97) && Sight.visibleSamples(level, player, lz) > 0;
                // too close, seen, out of time, or the player walked far away from him (more than 5 chunks): he goes away
                if (seen || lz.distanceTo(player) < cfg.silhouetteApproachBlocks || lz.distanceTo(player) > 5 * 16
                        || d.age > cfg.silhouetteGiveUpTicks) {
                    d.phase = 1;
                    d.glitchTotal = rand(rnd, cfg.glitchMinTicks, cfg.glitchMaxTicks);
                    d.phaseTicks = d.glitchTotal;
                    lz.setLazurState(LazurEntity.S_GLITCH);
                } else if (--silMove <= 0) {
                    // nobody has noticed him for 20-30 s: he steps to another place (until someone does)
                    Vec3 np = findWatcherSpot(level.getServer(), player, level, rnd, false);
                    if (np == null) {
                        silMove = 20;
                    } else {
                        float yaw = (float) Math.toDegrees(Math.atan2(-(player.getX() - np.x), player.getZ() - np.z));
                        lz.setPos(np.x, np.y, np.z);
                        lz.setYRot(yaw); lz.setYBodyRot(yaw); lz.setYHeadRot(yaw);
                        lz.setDeltaMovement(Vec3.ZERO);
                        silMove = rand(rnd, 400, 600);
                    }
                }
            }
            case 1 -> { // glitch 1-2 s, turns into the black figure halfway
                d.phaseTicks--;
                if (d.phaseTicks == d.glitchTotal / 2) lz.setAppearance(LazurEntity.A_FIGURE);
                if (d.phaseTicks <= 0) {
                    d.phase = 2;
                    d.phaseTicks = 60;
                    lz.setAppearance(LazurEntity.A_FIGURE);
                    lz.setLazurState(LazurEntity.S_FADE);
                }
            }
            default -> { // dissolve, then gone
                if (--d.phaseTicks <= 0) {
                    lz.discard();
                    d.role = ROLE_NONE;
                    d.lazurId = null;
                    d.silCd = rand(rnd, cfg.silhouetteCdMin, cfg.silhouetteCdMax);
                    d.setDirty();
                }
            }
        }
    }

    private static void beginChase(LazurData d, ServerLevel level, LazurEntity lz, LazurConfig cfg) {
        boolean alreadyRevealed = d.role == ROLE_REVEAL;  // an animal reveal already played the sound at its start
        if (!alreadyRevealed) revealSound(level, lz);
        d.role = ROLE_CHASE;
        d.lazurId = lz.getUUID();
        d.chaseTicks = lz.isPlayerSized() ? 1200 + level.getRandom().nextInt(3601) : cfg.chaseTicks; // cave form 1-4 min, tall form 10 min
        d.fading = false;
        countAttack(level.getServer(), d);
        tpTicks = 0;
        tpRefY = Double.NaN;
        lz.setAppearance(lz.isPlayerSized() ? LazurEntity.A_BLACK_PLAYER : LazurEntity.A_FIGURE);
        lz.resetAttack();
        lz.setAttackCooldown(cfg.revealAttackDelayTicks); // 0 by default: he may strike at once
        lz.setLazurState(LazurEntity.S_RUN);
        roar(level, lz);
        d.setDirty();
    }

    private static void tickChase(LazurData d, ServerPlayer player, ServerLevel level, LazurEntity lz,
                                  RandomSource rnd, LazurConfig cfg) {
        if (LazurGrab.active()) {             // holding the player: the grab mini-game replaces the chase brain
            LazurGrab.tick(level, player, lz);
            return;
        }
        if (LazurGrab.releaseTicks > 0) {     // just let go: stands still for 2 s so the player can run
            LazurGrab.releaseTicks--;
            lz.getNavigation().stop();
            lz.setLazurState(LazurEntity.S_IDLE);
            return;
        }
        if (d.fading) {
            if (--d.phaseTicks <= 0) {
                addTrail(level, BlockPos.containing(lz.getX(), lz.getY() - 0.1, lz.getZ()));
                lz.discard();
                finishChase(d, rnd, cfg);
            }
            return;
        }
        if (--d.chaseTicks <= 0 || levelOf(player) != level) {
            d.fading = true;
            d.phaseTicks = 60;
            lz.getNavigation().stop();
            lz.setLazurState(LazurEntity.S_FADE);
            return;
        }
        if (!lz.isPlayerSized()) {                                  // the tall form only, not the cave one
            tickTeleport(player, level, lz);
            if (lz.takeTeleportRequest()) teleportNextTo(level, player, lz, true);  // the low-ceiling step and the player in sight
        }
        lz.chaseTick(player);
    }

    // ---- teleport to a player who cannot be reached (high up, or building a tower) ----
    private static int tpTicks;
    private static double tpRefY = Double.NaN;   // height of the last "real" ground the player stood on
    private static boolean tpSupported = true;

    private static boolean solidAt(ServerLevel level, int x, int y, int z) {
        BlockPos p = new BlockPos(x, y, z);
        return level.hasChunkAt(p) && !level.getBlockState(p).getCollisionShape(level, p).isEmpty();
    }

    /** Share of solid blocks in the column x,z from y down to minY (a wall / a mass reaching the ground). */
    private static double columnSolid(ServerLevel level, int x, int z, int y, int minY) {
        int total = 0, solid = 0;
        for (int yy = y; yy >= Math.max(minY, y - 64); yy--) {
            total++;
            if (solidAt(level, x, yy, z)) solid++;
        }
        return total == 0 ? 1.0 : solid / (double) total;
    }

    /**
     * Does the player stand on a platform of 3x3 or more with dense walls going down to Lazur's level (a hill, a house,
     * a tower he can get around)? A thin pillar, a ledge on one block or a floating tower is NOT such a platform.
     */
    private static boolean onSolidPlatform(ServerLevel level, ServerPlayer player, LazurEntity lz) {
        int fx = player.getBlockX(), fz = player.getBlockZ();
        int floorY = Mth.floor(player.getY() - 0.01) - 1;
        int lowY = Mth.floor(lz.getY()) - 1;
        if (floorY <= lowY) return true;                       // same level as him: nothing to be unreachable
        for (int cx = fx - 1; cx <= fx + 1; cx++) {            // every 3x3 window that contains the player's block
            for (int cz = fz - 1; cz <= fz + 1; cz++) {
                boolean floor = true;
                for (int x = cx - 1; x <= cx + 1 && floor; x++) {
                    for (int z = cz - 1; z <= cz + 1; z++) {
                        if (!solidAt(level, x, floorY, z)) { floor = false; break; }
                    }
                }
                if (!floor) continue;
                double sum = 0;
                for (int x = cx - 1; x <= cx + 1; x++) {       // walls: the 8 edge columns must be dense down to the ground
                    for (int z = cz - 1; z <= cz + 1; z++) {
                        if (x == cx && z == cz) continue;
                        sum += columnSolid(level, x, z, floorY - 1, lowY);
                    }
                }
                if (sum / 8.0 >= 0.75) return true;
            }
        }
        return false;
    }

    private static void tickTeleport(ServerPlayer player, ServerLevel level, LazurEntity lz) {
        if (player.isSpectator() || player.getAbilities().flying || player.isInWater() || player.isFallFlying()) { tpTicks = 0; return; }
        if (level.getServer().getTickCount() % 5 != 0) return;     // checked 4 times a second
        if (!player.onGround()) return;                            // jumps (also pillar-jumps) do not reset the count
        tpSupported = onSolidPlatform(level, player, lz);
        if (tpSupported || Double.isNaN(tpRefY)) tpRefY = player.getY();
        boolean high = !tpSupported && player.getY() - lz.getY() >= 5.0;       // 5+ blocks above him, no platform under
        boolean tower = !tpSupported && player.getY() - tpRefY >= 3.0;         // built 3 blocks up
        if (!(high || tower)) { tpTicks = 0; return; }
        tpTicks += 5;
        if (tpTicks < 20) return;                                  // the condition has held for 1 second
        tpTicks = 0;
        if (teleportNextTo(level, player, lz, true)) tpRefY = player.getY();
    }

    private static boolean teleportNextTo(ServerLevel level, ServerPlayer player, LazurEntity lz, boolean slam) {
        Vec3 from = lz.position();
        double px = player.getX(), py = player.getY(), pz = player.getZ();
        for (int pass = 0; pass < 2; pass++) {                     // pass 0: with a floor under him, pass 1: anywhere free
            for (double r : new double[]{1.6, 2.2}) {
                for (int i = 0; i < 8; i++) {
                    double a = i * Math.PI / 4.0;
                    double x = px + Math.cos(a) * r, z = pz + Math.sin(a) * r;
                    lz.setPos(x, py, z);
                    if (!level.noCollision(lz)) continue;
                    if (pass == 0 && !solidAt(level, Mth.floor(x), Mth.floor(py) - 1, Mth.floor(z))) continue;
                    lz.getNavigation().stop();
                    lz.setDeltaMovement(Vec3.ZERO);
                    lz.resetFallDistance();
                    level.playSound(null, from.x, from.y, from.z, com.lazur.registry.ModSounds.LAZUR_TELEPORT, SoundSource.HOSTILE, 2.0F, 1.0F);
                    level.playSound(null, x, py, z, com.lazur.registry.ModSounds.LAZUR_TELEPORT, SoundSource.HOSTILE, 2.0F, 1.0F);
                    if (slam) LazurGrab.begin(LazurData.get(level.getServer()), player, lz); // he grabs the player at once (the mini-game starts)
                    return true;
                }
            }
        }
        lz.setPos(from.x, from.y, from.z);                         // nowhere to stand: stays where he was
        return false;
    }

    private static void finishChase(LazurData d, RandomSource rnd, LazurConfig cfg) {
        d.role = ROLE_NONE;
        d.lazurId = null;
        d.fading = false;
        promoteHeldReturns(d);                                  // originals wait for dawn now
        resetCaveTimer();
        d.subCd = rand(rnd, cfg.subCdMin, cfg.subCdMax);         // cooldown starts after the chase
        d.setDirty();
    }

    private static void endRoleAbnormally(MinecraftServer server, LazurData d, RandomSource rnd, LazurConfig cfg) {
        LazurGrab.clear();
        boolean wasChase = d.role == ROLE_CHASE || d.role == ROLE_REVEAL;
        d.role = ROLE_NONE;
        d.lazurId = null;
        d.fading = false;
        d.missing = 0;
        if (wasChase) finishChase(d, rnd, cfg);
        else d.silCd = rand(rnd, cfg.silhouetteCdMin, cfg.silhouetteCdMax);
        resetCaveTimer();
        d.setDirty();
    }

    // =====================================================================================
    // spawning decisions
    // =====================================================================================
    public static boolean trySpawn(MinecraftServer server, LazurData d, ServerPlayer player, ServerLevel level,
                                   RandomSource rnd, LazurConfig cfg, boolean debug) {
        if (!debug && server.getTickCount() < nextTry) return false;
        if (d.stage == 0) return false;                    // quiet start: nothing at all yet
        double home = minHomeDist(d, player);
        boolean near = home <= cfg.nearRadiusBlocks;
        boolean ok = false;
        // the silhouette only waits for its cooldown: no distance-from-home condition
        if (d.silCd <= 0) ok = spawnSilhouette(server, d, player, level, rnd, cfg, false);
        else if (d.stage >= 2 && near && d.subCd <= 0) ok = trySubstitute(server, d, player, level, rnd, cfg, false);
        if (!ok) nextTry = server.getTickCount() + 100;
        return ok;
    }

    /** Free standing room for Lazur (2.9 tall): solid floor, no fluid, three blocks without collision above it. */
    private static boolean standable(ServerLevel level, int x, int y, int z) { return standable(level, x, y, z, 3); }

    /** Like standable(), but the floor is a leaf block (the top of a tree canopy). */
    private static boolean standableOnLeaves(ServerLevel level, int x, int y, int z, int height) {
        BlockPos feet = new BlockPos(x, y, z);
        BlockPos below = feet.below();
        if (!level.hasChunkAt(feet) || !level.getBlockState(below).is(net.minecraft.tags.BlockTags.LEAVES)) return false;
        for (int h = 0; h < height; h++) {
            BlockPos p = feet.above(h);
            if (!level.getBlockState(p).getCollisionShape(level, p).isEmpty() || !level.getFluidState(p).isEmpty()) return false;
        }
        return true;
    }

    private static boolean standable(ServerLevel level, int x, int y, int z, int height) {
        BlockPos feet = new BlockPos(x, y, z);
        BlockPos below = feet.below();
        if (!level.hasChunkAt(feet)) return false;
        if (!level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)) return false;
        if (!level.getFluidState(feet).isEmpty() || !level.getFluidState(below).isEmpty()) return false;
        for (int h = 0; h < height; h++) {
            BlockPos p = feet.above(h);
            if (!level.getBlockState(p).getCollisionShape(level, p).isEmpty()) return false;
            if (!level.getFluidState(p).isEmpty()) return false;
        }
        return true;
    }

    /** Cave: nearest standable floor to the player's height in this column, or MIN_VALUE. */
    private static int caveFloor(ServerLevel level, int x, int z, int py, int height) {
        for (int dy = 0; dy <= 16; dy++) {
            if (standable(level, x, py + dy, z, height)) return py + dy;
            if (dy > 0 && standable(level, x, py - dy, z, height)) return py - dy;
        }
        return Integer.MIN_VALUE;
    }

    /**
     * Where the silhouette stands: 2-4 chunks from the player (32-64 blocks), on the surface when the player is on the
     * surface and in a cave when the player is underground. First choice: a little behind cover, peeking out at the
     * player. If nothing like that exists he just stands wherever there is room (then a bit closer) until noticed.
     * debug = skip the "partially behind cover" requirement.
     */
    public static boolean spawnSilhouette(MinecraftServer server, LazurData d, ServerPlayer player, ServerLevel level,
                                          RandomSource rnd, LazurConfig cfg, boolean debug) {
        return spawnWatcher(server, d, player, level, rnd, cfg, debug, false);
    }

    /** Free room for the cave form: standing space here plus at least 5 of 8 neighbours open (not a crack in a wall). */
    private static boolean roomy(ServerLevel level, int x, int y, int z) {
        if (!standable(level, x, y, z, 2)) return false;
        int open = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                BlockPos f = new BlockPos(x + dx, y, z + dz);
                BlockPos h = f.above();
                if (level.getBlockState(f).getCollisionShape(level, f).isEmpty()
                        && level.getBlockState(h).getCollisionShape(level, h).isEmpty()) open++;
            }
        }
        return open >= 5;
    }

    /**
     * The cave form shows up in the space around the player: every spot within 10 blocks is checked in all three
     * directions (x, z and height). A spot counts when it is 7-10 blocks away in a straight line, has free room and a
     * solid block under it, and its floor is at most 8 blocks above/below the player. Floors within 5 blocks of the
     * player's height are preferred; the 6-8 ones are used only when there is nothing closer in height.
     * Same rule for the timer and for /lazur cave.
     */
    private static boolean spawnMimicNear(LazurData d, ServerPlayer player, ServerLevel level, RandomSource rnd) {
        final double minD = 7.0, maxD = 10.0;
        final int near = 5, far = 8;
        int px = player.getBlockX(), py = player.getBlockY(), pz = player.getBlockZ();
        java.util.List<int[]> close = new java.util.ArrayList<>(), distant = new java.util.ArrayList<>();
        for (int x = px - 10; x <= px + 10; x++) {
            for (int z = pz - 10; z <= pz + 10; z++) {
                for (int y = py - far; y <= py + far; y++) {
                    double ex = x + 0.5 - player.getX(), ey = y - player.getY(), ez = z + 0.5 - player.getZ();
                    double dist3 = Math.sqrt(ex * ex + ey * ey + ez * ez);
                    if (dist3 < minD || dist3 > maxD) continue;
                    if (!standable(level, x, y, z, 2) || !roomy(level, x, y, z)) continue; // solid floor + free room
                    (Math.abs(y - py) <= near ? close : distant).add(new int[]{x, y, z});
                }
            }
        }
        java.util.List<int[]> pick = close.isEmpty() ? distant : close;
        boolean found = !pick.isEmpty();
        int bx = 0, by = 0, bz = 0;
        if (found) {
            int[] c = pick.get(rnd.nextInt(pick.size()));
            bx = c[0]; by = c[1]; bz = c[2];
        }
        if (!found) return false;

        double dx = player.getX() - (bx + 0.5), dz = player.getZ() - (bz + 0.5);
        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        LazurEntity lz = spawn(level, new Vec3(bx + 0.5, by, bz + 0.5), yaw, LazurEntity.A_SKIN, LazurEntity.S_IDLE, true);
        d.role = ROLE_CAVE;
        d.lazurId = lz.getUUID();
        d.phase = 0;
        d.phaseTicks = 0;
        d.age = 0;
        d.farTicks = 0;
        d.missing = 0;
        d.silCd = Math.max(d.silCd, rand(rnd, 24000, 168000)); // while he waits the silhouette timer is at least 1-7 days
        d.setDirty();
        return true;
    }

    /** Free sky (or only leaves) above his head: he is not inside a cave or under a roof. */
    private static boolean openAbove(ServerLevel level, int x, int topY, int z) {
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int y = topY; y <= topY + 80; y++) {
            m.set(x, y, z);
            BlockState bs = level.getBlockState(m);
            if (bs.is(net.minecraft.tags.BlockTags.LEAVES)) continue;
            if (!bs.getCollisionShape(level, m).isEmpty()) return false;
        }
        return true;
    }

    /**
     * Where the silhouette can stand (doc): 2-4 chunks (32-64 blocks) from the player, at the player's height or at most
     * 6 blocks higher / 1 block lower; solid floor or a tree top (leaves), room for 3 blocks, and above him only free air
     * or leaves (so never inside a cave) - unless the player himself is underground (8+ blocks of rock above him): then
     * the sky rule and the viewing cone are dropped. In both cases the player must be able to see him (a clear line to
     * at least one point of his body). On the surface he is put into the front half of the player's view.
     * debug = no visibility / cone requirement.
     */
    private static Vec3 findWatcherSpot(MinecraftServer server, ServerPlayer player, ServerLevel level, RandomSource rnd, boolean debug) {
        final int height = 3;
        int vd = server.getPlayerList().getViewDistance();
        int maxC = Math.min(4, vd - 1);   // silhouette: 2-4 chunks from the player
        int minC = Math.min(2, maxC);
        if (maxC < 2) return null;
        Vec3 look = player.getLookAngle();
        double lookAng = Math.atan2(look.z, look.x);
        Vec3 eye = player.getEyePosition();
        int py = player.getBlockY();
        boolean cave = isUnderground(level, player);

        double[][] bands = {{minC * 16.0, maxC * 16.0}, {24.0, Math.max(25.0, minC * 16.0)}, {16.0, 24.0}};
        for (double[] band : bands) {
            for (int i = 0; i < 50; i++) {
                double ang = (!cave && !debug) ? lookAng + (rnd.nextDouble() - 0.5) * Math.toRadians(140)
                        : rnd.nextDouble() * Math.PI * 2;
                double dist = band[0] + rnd.nextDouble() * (band[1] - band[0]);
                int x = Mth.floor(player.getX() + Math.cos(ang) * dist);
                int z = Mth.floor(player.getZ() + Math.sin(ang) * dist);
                if (!level.hasChunkAt(new BlockPos(x, 64, z))) continue;
                int pickY = Integer.MIN_VALUE, n = 0;
                for (int y = py + 6; y >= py - 1; y--) {           // 6 blocks higher at most, 1 lower at most
                    if (!(standable(level, x, y, z, height) || standableOnLeaves(level, x, y, z, height))) continue;
                    if (!cave && !openAbove(level, x, y + height, z)) continue;
                    n++;
                    if (rnd.nextInt(n) == 0) pickY = y;             // a random one of the valid heights
                }
                if (pickY == Integer.MIN_VALUE) continue;
                if (!debug) {
                    boolean vis = false;
                    for (double hy : new double[]{0.3, 1.5, 2.7}) {
                        if (Sight.pointVisible(level, player, eye, new Vec3(x + 0.5, pickY + hy, z + 0.5), null)) { vis = true; break; }
                    }
                    if (!vis) continue;
                }
                return new Vec3(x + 0.5, pickY, z + 0.5);
            }
        }
        return null;
    }

    /** Ticks until the unnoticed silhouette moves to another place (20-30 s). */
    private static int silMove;

    /** mimic = the cave form: player-sized, role ROLE_CAVE, can attack. The silhouette uses findWatcherSpot(). */
    private static boolean spawnWatcher(MinecraftServer server, LazurData d, ServerPlayer player, ServerLevel level,
                                        RandomSource rnd, LazurConfig cfg, boolean debug, boolean mimic) {
        if (mimic) return spawnMimicNear(d, player, level, rnd); // 7-10 blocks away, in free room
        Vec3 pos = findWatcherSpot(server, player, level, rnd, debug);
        if (pos == null) return false;
        double dx = player.getX() - pos.x, dz = player.getZ() - pos.z;
        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        LazurEntity lz = spawn(level, pos, yaw, LazurEntity.A_SKIN, LazurEntity.S_IDLE, false);
        d.role = ROLE_SILHOUETTE;
        if (!debug && d.stage == 1) d.stage = 2; // the first silhouette has happened: everything works as usual from now on
        d.lazurId = lz.getUUID();
        d.phase = 0;
        d.phaseTicks = 0;
        d.age = 0;
        d.farTicks = 0;
        d.missing = 0;
        silMove = rand(rnd, 400, 600);
        d.setDirty();
        return true;
    }

    // =====================================================================================
    // cave: Lazur in the shape of a player
    // =====================================================================================
    private static int caveTicks, caveNeed;

    private static void resetCaveTimer() { caveTicks = 0; caveNeed = 0; }

    private static boolean isUnderground(ServerLevel level, ServerPlayer p) {
        return level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, p.getBlockX(), p.getBlockZ()) - p.getBlockY() >= 8;
    }

    /** Time spent underground is counted; after a random 10-40 min he shows up in the cave looking like the player. */
    private static void tickCaveTimer(MinecraftServer server, LazurData d, ServerPlayer player, ServerLevel level,
                                      RandomSource rnd, LazurConfig cfg) {
        if (!isUnderground(level, player)) return; // the count is kept, it only runs underground
        if (caveNeed <= 0) caveNeed = rand(rnd, cfg.caveMinTicks, cfg.caveMaxTicks);
        if (++caveTicks < caveNeed) return;
        if (server.getTickCount() % 40 != 0) return; // spawning is tried every 2 s until a place is found
        if (spawnWatcher(server, d, player, level, rnd, cfg, false, true)) resetCaveTimer();
    }

    /** Staring at his head for this long (1.5 s) starts the head turn and the camera lock. */
    private static final int CAVE_LOOK_TICKS = 30;
    private static final double CAVE_TOUCH_BLOCKS = 1.0; // this close = instant transformation, no head turn
    private static final int CAVE_SPIN_TICKS = 90;   // the committed head turn (4.5 s; the clip is 4.3 s)
    private static int lastGazeSent = -1;
    private static long spinSoundUntil;

    private static void sendGaze(ServerPlayer player, LazurEntity lz, float strength) {
        int enc = Math.round(strength * 100f);
        if (enc == lastGazeSent && enc == 0) return;   // no spam while nothing happens
        lastGazeSent = enc;
        net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(player, new com.lazur.net.LazurNet.CaveGaze(lz.getId(), strength));
    }

    /**
     * Phase of the cave form while he stands there as a player: stare at him too long (or walk right up to him)
     * and the camera shakes and gets pulled to him until he turns black and runs at the player.
     */
    private static void tickCave(LazurData d, ServerPlayer player, ServerLevel level, LazurEntity lz,
                                 RandomSource rnd, LazurConfig cfg) {
        d.age++;
        double dist = lz.distanceTo(player);

        // the player is right next to him (1 block or less): no head turn, he turns black and attacks at once
        if (dist <= CAVE_TOUCH_BLOCKS) {
            sendGaze(player, lz, 0f);
            lastGazeSent = -1;
            spinSoundUntil = 0;
            lz.getNavigation().stop();
            lz.setLazurState(LazurEntity.S_GLITCH);
            revealSound(level, lz);
            d.role = ROLE_REVEAL;
            d.phase = 0;
            d.phaseTicks = 24;
            d.setDirty();
            return;
        }

        // committed: the head makes ONE full turn first (camera pulled to him), only then glitch -> black -> chase
        if (d.phase == 1) {
            sendGaze(player, lz, 1f - Math.max(0, d.phaseTicks) / (float) CAVE_SPIN_TICKS); // 0 -> 1: the camera creeps closer
            lz.getNavigation().stop();
            lz.setLazurState(LazurEntity.S_SPIN_FULL);
            if (--d.phaseTicks <= 0) {
                sendGaze(player, lz, 0f);
                lastGazeSent = -1;
                spinSoundUntil = 0;
                lz.setLazurState(LazurEntity.S_GLITCH);
                revealSound(level, lz);
                d.role = ROLE_REVEAL;
                d.phase = 0;
                d.phaseTicks = 24;
                d.setDirty();
            }
            return;
        }

        Vec3 eye = lz.position().add(0, lz.getBbHeight() * 0.9, 0);
        boolean looking = dist <= 96 && Sight.inView(player, eye, 0.95) && Sight.visibleSamples(level, player, lz) > 0;

        int gaze = d.phaseTicks;                       // ticks of staring
        gaze = looking ? gaze + 1 : Math.max(0, gaze - 3);
        d.phaseTicks = gaze;

        // nothing happens while he is only being looked at: after 3 s the head starts to turn and the camera locks on
        if (gaze >= CAVE_LOOK_TICKS) {
            // start the full head turn (4.5 s: the clip is 4.3 s); the black form and the chase come after it
            lz.getNavigation().stop();
            lz.setLazurState(LazurEntity.S_SPIN_FULL);
            level.playSound(null, lz.getX(), lz.getY() + 1.6, lz.getZ(), com.lazur.registry.ModSounds.LAZUR_HEAD_SPIN,
                    SoundSource.HOSTILE, 1.6F, 1.0F);
            spinSoundUntil = 0;
            d.phase = 1;
            d.phaseTicks = CAVE_SPIN_TICKS;
            d.setDirty();
            return;
        }
        if (d.age > cfg.caveGiveUpTicks) { // nobody paid attention for 2 min: he looks for another place until the chase happens
            sendGaze(player, lz, 0f);
            lastGazeSent = -1;
            lz.discard();
            d.role = ROLE_NONE;
            d.lazurId = null;
            if (!spawnMimicNear(d, player, level, rnd)) { caveNeed = 1; caveTicks = 1; } // no place now: the timer retries every 2 s
            d.setDirty();
        }
    }

    // ---- substitution choice ----
    /**
     * Lazur imitates whatever is CLOSEST to the player of these three:
     * a functional block (furnace, crafting table, ...), an animal, or the bed the player has slept in (the spawn bed).
     * An animal that bored him for 10 minutes is skipped once, so he really moves on to something else.
     */
    public static boolean trySubstitute(MinecraftServer server, LazurData d, ServerPlayer player, ServerLevel level,
                                        RandomSource rnd, LazurConfig cfg, boolean debug) {
        Mob mob = nearestCreature(player, level, cfg, debug);
        BlockPos block = nearestFunctional(player, level, cfg, debug);
        BlockPos bed = nearestBed(d, player, level, cfg, debug);
        double dm = mob == null ? Double.MAX_VALUE : player.distanceToSqr(mob);
        double db = block == null ? Double.MAX_VALUE : player.distanceToSqr(Vec3.atCenterOf(block));
        double dd = bed == null ? Double.MAX_VALUE : player.distanceToSqr(Vec3.atCenterOf(bed));
        if (mob == null && block == null && bed == null) return false;
        if (dm <= db && dm <= dd) return makeCreatureSub(d, mob, rnd, cfg);
        if (dd <= db) return makeBlockSub(d, level, bed, true, rnd, cfg);
        return makeBlockSub(d, level, block, false, rnd, cfg);
    }

    /** Animal host that was left after 10 minutes: not picked again right away. */
    private static String avoidMob = "";

    private static boolean hidden(ServerLevel level, ServerPlayer p, Vec3 center, BlockPos ignore, boolean debug) {
        if (debug) return true;
        // not in the view cone (about 60 degrees) or no clear line from the eyes
        return !Sight.inView(p, center, 0.5) || !Sight.pointVisible(level, p, p.getEyePosition(), center, ignore);
    }

    private static BlockPos nearestFunctional(ServerPlayer player, ServerLevel level, LazurConfig cfg, boolean debug) {
        BlockPos c = player.blockPosition();
        int R = cfg.searchRadius, V = cfg.searchVertical;
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int x = -R; x <= R; x++) {
            for (int z = -R; z <= R; z++) {
                for (int y = -V; y <= V; y++) {
                    m.set(c.getX() + x, c.getY() + y, c.getZ() + z);
                    double dd = player.distanceToSqr(Vec3.atCenterOf(m));
                    if (dd >= bestD || !level.hasChunkAt(m)) continue;
                    if (!Targets.isFunctional(level.getBlockState(m))) continue;
                    if (!hidden(level, player, Vec3.atCenterOf(m), m, debug)) continue;
                    best = m.immutable();
                    bestD = dd;
                }
            }
        }
        return best;
    }

    /** A bed the player has slept in (= his spawn bed), the nearest one within reach. */
    private static BlockPos nearestBed(LazurData d, ServerPlayer player, ServerLevel level, LazurConfig cfg, boolean debug) {
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (int[] b : d.beds) {
            BlockPos p = new BlockPos(b[0], b[1], b[2]);
            if (!level.hasChunkAt(p)) continue;
            BlockState st = level.getBlockState(p);
            if (!(st.getBlock() instanceof BedBlock) || st.getValue(BedBlock.PART) != BedPart.HEAD) continue;
            double dd = player.distanceToSqr(Vec3.atCenterOf(p));
            double r = cfg.searchRadius;
            if (dd > r * r || dd >= bestD) continue;
            if (!hidden(level, player, Vec3.atCenterOf(p), p, debug)) continue;
            best = p;
            bestD = dd;
        }
        return best;
    }

    /** An animal can be imitated when it is within this many blocks of the player. */
    private static final double CREATURE_PICK_RADIUS = 12.0;
    /** The imitated animal is dropped if nothing happened for this long (5 minutes); the nearest one is then picked again. */
    private static final int CREATURE_ABANDON_TICKS = 6000;

    /** The nearest animal (any kind, babies too) within 12 blocks. Tamed animals and named pets are never taken. */
    private static Mob nearestCreature(ServerPlayer player, ServerLevel level, LazurConfig cfg, boolean debug) {
        List<Mob> cands = level.getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(CREATURE_PICK_RADIUS), m ->
                m.isAlive() && m.getType().getCategory() == MobCategory.CREATURE
                        && !(m instanceof TamableAnimal) && !m.hasCustomName()
                        && player.distanceToSqr(m) <= CREATURE_PICK_RADIUS * CREATURE_PICK_RADIUS
                        && !m.getUUID().toString().equals(avoidMob));
        cands.sort(java.util.Comparator.comparingDouble(player::distanceToSqr));
        for (Mob m : cands) {
            if (hidden(level, player, m.getEyePosition(), null, debug)) return m;
        }
        return null;
    }

    private static boolean makeBlockSub(LazurData d, ServerLevel level, BlockPos pick, boolean bed, RandomSource rnd, LazurConfig cfg) {
        Sub s = new Sub();
        s.type = bed ? SUB_BED : SUB_BLOCK;
        s.x = pick.getX(); s.y = pick.getY(); s.z = pick.getZ();
        s.blockId = BuiltInRegistries.BLOCK.getKey(level.getBlockState(pick).getBlock()).toString();
        s.abandon = bed ? -1 : rand(rnd, cfg.abandonMin, cfg.abandonMax);
        s.reveal = -1;
        d.sub = s;
        avoidMob = "";
        d.setDirty();
        return true;
    }

    private static boolean makeCreatureSub(LazurData d, Mob pick, RandomSource rnd, LazurConfig cfg) {
        Sub s = new Sub();
        s.type = SUB_MOB;
        s.x = pick.getBlockX(); s.y = pick.getBlockY(); s.z = pick.getBlockZ();
        s.mob = pick.getUUID().toString();
        s.nearNeed = rand(rnd, cfg.creatureNearMinTicks, cfg.creatureNearMaxTicks);
        s.abandon = CREATURE_ABANDON_TICKS;     // 5 minutes without anything happening: moves to the nearest other animal
        s.variant = rnd.nextInt(2);             // 1: it makes the sound of ANOTHER animal
        pick.setSilent(s.variant == 1);
        s.reveal = -1;
        d.sub = s;
        avoidMob = "";
        d.setDirty();
        return true;
    }

    /** Debug: force the nearest animal. */
    private static boolean substituteCreature(LazurData d, ServerPlayer player, ServerLevel level, RandomSource rnd,
                                              LazurConfig cfg, boolean debug) {
        Mob mob = nearestCreature(player, level, cfg, debug);
        return mob != null && makeCreatureSub(d, mob, rnd, cfg);
    }

    // =====================================================================================
    // active substitution
    // =====================================================================================
    private static void tickSub(MinecraftServer server, LazurData d, ServerPlayer player, ServerLevel level,
                                RandomSource rnd, LazurConfig cfg) {
        Sub s = d.sub;
        if (s.type == SUB_MOB) { tickMob(d, player, level, rnd, cfg, s); return; }

        BlockPos pos = s.pos();
        if (!level.hasChunkAt(pos)) return; // chunk unloaded: wait
        BlockState st = level.getBlockState(pos);
        if (!BuiltInRegistries.BLOCK.getKey(st.getBlock()).toString().equals(s.blockId)) {
            // removed by something else: Lazur loses its host
            d.sub = null;
            d.subCd = rand(rnd, cfg.subCdMin, cfg.subCdMax);
            d.setDirty();
            return;
        }
        if (s.type == SUB_BED) {
            if (s.force) { s.force = false; bedAttackNow(server, d, player, level, rnd, cfg); }
            if (s.scream) tickBedScream(server, d, player, level, rnd, cfg, s); // only the bed a block with a low ceiling switched to
            return; // otherwise the bed works normally until the player sleeps in it
        }

        Vec3 center = Vec3.atCenterOf(pos);
        if (s.reveal < 0) {
            if (s.abandon > 0 && --s.abandon == 0) abandonBlock(d, level, rnd, cfg, s);
            else if (s.force) attackFromBlock(d, player, level, cfg, s);
        } else {
            if (s.reveal > 0) s.reveal--;
            boolean close = player.position().distanceToSqr(center) <= cfg.attackRadius * cfg.attackRadius;
            boolean due = s.reveal == 0 && close;
            // not enough room above the block for him to stand up (fewer than 3 free blocks): he switches to the player's bed
            if (due && !s.force && headroom(level, pos) < 3 && convertToScreamBed(d, level, player, s)) return;
            if (s.force || due) attackFromBlock(d, player, level, cfg, s);
        }
    }

    private static int headroom(ServerLevel level, BlockPos pos) {
        int n = 0;
        for (int h = 1; h <= 3; h++) {
            BlockPos p = pos.above(h);
            if (level.getBlockState(p).getCollisionShape(level, p).isEmpty()) n++; else break;
        }
        return n;
    }

    /** The block he hides in is too low for him: the block goes away (back at dawn) and the substitution becomes the bed. */
    private static boolean convertToScreamBed(LazurData d, ServerLevel level, ServerPlayer player, Sub block) {
        BlockPos bed = null;
        double best = Double.MAX_VALUE;
        for (int[] b : d.beds) {
            BlockPos p = new BlockPos(b[0], b[1], b[2]);
            if (!level.hasChunkAt(p)) continue;
            BlockState st = level.getBlockState(p);
            if (!(st.getBlock() instanceof BedBlock) || st.getValue(BedBlock.PART) != BedPart.HEAD) continue;
            double dd = player.distanceToSqr(Vec3.atCenterOf(p));
            if (dd < best) { best = dd; bed = p; }
        }
        if (bed == null) return false; // no bed he knows: he attacks from the block as usual
        Ret r = BlockSnapshot.capture(level, block.pos());
        r.status = LazurData.READY;       // the original comes back at dawn
        r.particles = true;
        d.returns.add(r);
        level.removeBlock(block.pos(), false);
        Sub b = new Sub();
        b.type = SUB_BED;
        b.x = bed.getX(); b.y = bed.getY(); b.z = bed.getZ();
        b.blockId = BuiltInRegistries.BLOCK.getKey(level.getBlockState(bed).getBlock()).toString();
        b.abandon = -1; b.reveal = -1;
        b.scream = true;
        d.sub = b;
        d.setDirty();
        return true;
    }

    private static void abandonBlock(LazurData d, ServerLevel level, RandomSource rnd, LazurConfig cfg, Sub s) {
        Ret r = BlockSnapshot.capture(level, s.pos());
        r.status = LazurData.READY;       // back at the next dawn
        r.particles = true;
        d.returns.add(r);
        level.removeBlock(s.pos(), false); // silent, just empty air
        d.sub = null;
        d.subCd = rand(rnd, cfg.subCdMin, cfg.subCdMax); // Lazur goes elsewhere
        d.setDirty();
    }

    private static void attackFromBlock(LazurData d, ServerPlayer player, ServerLevel level, LazurConfig cfg, Sub s) {
        BlockPos pos = s.pos();
        Ret r = BlockSnapshot.capture(level, pos);
        r.status = LazurData.HOLD;         // waits for the chase to end, then for dawn
        d.returns.add(r);
        level.destroyBlock(pos, false);    // particles + break sound
        d.sub = null;

        Vec3 base = new Vec3(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
        float yaw = (float) Math.toDegrees(Math.atan2(-(player.getX() - base.x), player.getZ() - base.z));
        LazurEntity lz = spawn(level, base, yaw, LazurEntity.A_FIGURE, LazurEntity.S_RUN);
        placeFree(level, lz, base);
        beginChase(d, level, lz, cfg);
    }

    private static void tickMob(LazurData d, ServerPlayer player, ServerLevel level, RandomSource rnd,
                                LazurConfig cfg, Sub s) {
        Mob mob = null;
        try {
            if (level.getEntity(UUID.fromString(s.mob)) instanceof Mob m && m.isAlive()) mob = m;
        } catch (IllegalArgumentException ignored) { }
        if (mob == null) {
            // creature gone (killed / unloaded for good): Lazur loses its host
            if (++d.missing > 200) {   // the animal is gone: after 10 s the substitution is reset
                d.missing = 0;
                d.sub = null;
                d.subCd = rand(rnd, cfg.subCdMin, cfg.subCdMax);
                d.setDirty();
            }
            return;
        }
        d.missing = 0;
        s.x = mob.getBlockX(); s.y = mob.getBlockY(); s.z = mob.getBlockZ();

        if (s.abandon > 0 && --s.abandon == 0) { // 5 minutes and nothing happened: he moves on to the nearest other animal
            mob.setSilent(false);
            avoidMob = s.mob;
            d.sub = null;
            d.subCd = 20 * 10;                    // picks a new host (the closest one again) in a few seconds
            d.setDirty();
            return;
        }

        double dist = player.distanceTo(mob);
        mob.getLookControl().setLookAt(player, 30.0F, 30.0F); // never looks away
        if (s.variant == 1 && level.getServer().getTickCount() % 20 == 0 && rnd.nextInt(10) == 0) { // a wrong sound: another animal's
            String[] snd = {"entity.cow.ambient", "entity.pig.ambient", "entity.sheep.ambient", "entity.chicken.ambient", "entity.horse.ambient"};
            runCommand(level.getServer(), "playsound minecraft:" + snd[rnd.nextInt(snd.length)] + " neutral @a "
                    + mob.getX() + " " + mob.getY() + " " + mob.getZ() + " 1 1");
        }

        Vec3 eyeMob = mob.getEyePosition();
        // 1) 10 s of looking at the animal (looking away resets the count)
        boolean looking = dist <= cfg.creatureGazeRange
                && Sight.inView(player, eyeMob, cfg.creatureGazeCone)
                && Sight.pointVisible(level, player, player.getEyePosition(), eyeMob, null);
        s.gaze = looking ? s.gaze + 1 : 0;
        // 2) or standing within 12 blocks of it for a random 5 s - 60 s (leaving the radius resets the count)
        if (s.nearNeed <= 0) s.nearNeed = rand(rnd, cfg.creatureNearMinTicks, cfg.creatureNearMaxTicks);
        s.near = dist <= cfg.creatureNearRadius ? s.near + 1 : 0;
        if (s.force) s.gaze = cfg.creatureGazeTicks;

        if (s.gaze >= cfg.creatureGazeTicks || s.near >= s.nearNeed) {
            Vec3 p = mob.position();
            float yaw = mob.getYRot();
            mob.setSilent(false);
            mob.discard(); // the original is gone forever
            LazurEntity lz = spawn(level, p, yaw, LazurEntity.A_FIGURE, LazurEntity.S_GLITCH);
            placeFree(level, lz, p);
            revealSound(level, lz);
            d.sub = null;
            d.role = ROLE_REVEAL;
            d.lazurId = lz.getUUID();
            d.phaseTicks = 24;
            d.missing = 0;
            d.setDirty();
        }
    }

    // =====================================================================================
    // beds
    // =====================================================================================
    private static void bedAttackNow(MinecraftServer server, LazurData d, ServerPlayer player, ServerLevel level,
                                     RandomSource rnd, LazurConfig cfg) {
        Sub s = d.sub;
        if (s == null || s.type != SUB_BED) return;
        BlockPos head = s.pos();
        BlockState hs = level.getBlockState(head);
        if (hs.getBlock() instanceof BedBlock) {
            BlockPos foot = head.relative(hs.getValue(BedBlock.FACING).getOpposite());
            level.destroyBlock(head, false);
            if (level.getBlockState(foot).getBlock() instanceof BedBlock) level.destroyBlock(foot, false);
        }
        d.sub = null; // a bed never comes back
        clearRespawnPoint(player);

        Vec3 base = new Vec3(head.getX() + 0.5, head.getY(), head.getZ() + 0.5);
        float yaw = (float) Math.toDegrees(Math.atan2(-(player.getX() - base.x), player.getZ() - base.z));
        LazurEntity lz = spawn(level, base, yaw, LazurEntity.A_FIGURE, LazurEntity.S_RUN);
        placeFree(level, lz, base);
        beginChase(d, level, lz, cfg);
    }

    // ---- the jumpscare in a Lazur bed ----
    /** Length of the scream, ticks. It must start early enough that the player dies before the 100 ticks of sleep
     *  that would skip the night: the start is 10..50 ticks into the sleep, so death is at tick 90 at the latest. */
    private static final int SCREAM_TICKS = 40, SCREAM_START_MIN = 10, SCREAM_START_MAX = 50;
    private static int sleepTicks = 0, screamAt = -1, screamLeft = -1;

    private static void tickBedScream(MinecraftServer server, LazurData d, ServerPlayer player, ServerLevel level,
                                      RandomSource rnd, LazurConfig cfg, Sub s) {
        if (screamLeft >= 0) { // the scream is running: it always ends in death
            if (--screamLeft <= 0) screamKill(d, player, level, rnd, cfg, s);
            return;
        }
        boolean inBed = player.isSleeping() && player.getSleepingPos()
                .map(p -> p.distManhattan(s.pos()) <= 1).orElse(false);
        if (!inBed) { sleepTicks = 0; screamAt = -1; return; }
        if (screamAt < 0) screamAt = SCREAM_START_MIN + rnd.nextInt(SCREAM_START_MAX - SCREAM_START_MIN + 1);
        if (++sleepTicks >= screamAt) {
            screamLeft = SCREAM_TICKS;
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    com.lazur.registry.ModSounds.LAZUR_SCREAM, SoundSource.MASTER, 1.0F, 1.0F);
            net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(player, new com.lazur.net.LazurNet.Scream(SCREAM_TICKS));
        }
    }

    private static void screamKill(LazurData d, ServerPlayer player, ServerLevel level, RandomSource rnd,
                                   LazurConfig cfg, Sub s) {
        screamLeft = -1; sleepTicks = 0; screamAt = -1;
        BlockPos head = s.pos();
        BlockState hs = level.getBlockState(head);
        d.sub = null; // set first: breaking the bed wakes the player, which must not start a chase
        d.subCd = rand(rnd, cfg.subCdMin, cfg.subCdMax);
        if (hs.getBlock() instanceof BedBlock) {
            BlockPos foot = head.relative(hs.getValue(BedBlock.FACING).getOpposite());
            level.destroyBlock(head, false);
            if (level.getBlockState(foot).getBlock() instanceof BedBlock) level.destroyBlock(foot, false);
        }
        clearRespawnPoint(player); // back at the world spawn
        d.setDirty();
        net.minecraft.world.damagesource.DamageSource src;
        try {
            var types = level.registryAccess().lookupOrThrow(net.minecraft.core.registries.Registries.DAMAGE_TYPE);
            src = new net.minecraft.world.damagesource.DamageSource(types.getOrThrow(net.minecraft.resources.ResourceKey.create(
                    net.minecraft.core.registries.Registries.DAMAGE_TYPE, com.lazur.LazurMod.id("lazur_scream"))));
        } catch (RuntimeException e) {
            src = level.damageSources().genericKill();
        }
        player.hurtServer(level, src, Float.MAX_VALUE);
    }

    // =====================================================================================
    // Fabric events
    // =====================================================================================
    public static InteractionResult onUseBlock(Player player, Level level, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide() || !(level instanceof ServerLevel sl) || !(player instanceof ServerPlayer)) {
            return InteractionResult.PASS;
        }
        if (player.getItemInHand(hand).getItem() instanceof net.minecraft.world.item.BlockItem) { // placing a block is a noise he hears
            onNoise(sl, Vec3.atCenterOf(hit.getBlockPos().relative(hit.getDirection())), LazurConfig.get().hearBlock);
        }
        LazurData d = LazurData.get(sl.getServer());
        Sub s = d.sub;
        if (s == null || s.type != SUB_BLOCK || !hit.getBlockPos().equals(s.pos())) return InteractionResult.PASS;

        LazurConfig cfg = LazurConfig.get();
        if (s.reveal < 0) { // first click starts the hidden timer, later clicks change nothing
            s.reveal = rand(sl.getRandom(), cfg.revealMin, cfg.revealMax);
            s.abandon = -1;
            d.setDirty();
        }
        if (level.getBlockState(hit.getBlockPos()).getBlock() instanceof ChestBlock) {
            return InteractionResult.FAIL; // the chest does not open (the items are with the original)
        }
        return InteractionResult.PASS;
    }

    /** Return false to cancel the break. Trying to destroy Lazur wakes it up. */
    public static boolean onBreakBlock(Level level, Player player, BlockPos pos) {
        if (level.isClientSide() || !(level instanceof ServerLevel sl)) return true;
        onNoise(sl, Vec3.atCenterOf(pos), LazurConfig.get().hearBlock); // breaking a block is a noise he hears
        LazurData d = LazurData.get(sl.getServer());
        Sub s = d.sub;
        if (s == null || (s.type != SUB_BLOCK && s.type != SUB_BED)) return true;
        boolean hit = pos.equals(s.pos());
        if (!hit && s.type == SUB_BED) {
            BlockState bs = sl.getBlockState(s.pos());
            if (bs.getBlock() instanceof BedBlock) hit = pos.equals(s.pos().relative(bs.getValue(BedBlock.FACING).getOpposite()));
        }
        if (!hit) return true;
        s.force = true; // handled in the next tick
        d.setDirty();
        return false;
    }

    public static void onStopSleeping(LivingEntity entity, BlockPos sleepingPos) {
        if (!(entity instanceof ServerPlayer sp)) return;
        MinecraftServer server = levelOf(sp).getServer();
        LazurData d = LazurData.get(server);
        // a bed the player slept in counts as "home" (used by the substitution rule)
        d.homes.add(new int[]{sleepingPos.getX(), sleepingPos.getZ()});
        while (d.homes.size() > 8) d.homes.remove(1);
        rememberBed(d, levelOf(sp), sleepingPos);
        Sub s = d.sub;
        if (s != null && s.type == SUB_BED && screamLeft < 0 && sleepingPos.distManhattan(s.pos()) <= 1) {
            d.bedAttack = 3; // the bed breaks right after waking up
        }
        d.setDirty();
    }

    /** The bed the player slept in (head part) becomes a possible host. */
    private static void rememberBed(LazurData d, ServerLevel level, BlockPos pos) {
        BlockState st = level.getBlockState(pos);
        if (!(st.getBlock() instanceof BedBlock)) return;
        BlockPos head = st.getValue(BedBlock.PART) == BedPart.HEAD ? pos : pos.relative(st.getValue(BedBlock.FACING));
        d.beds.removeIf(b -> b[0] == head.getX() && b[1] == head.getY() && b[2] == head.getZ());
        d.beds.add(new int[]{head.getX(), head.getY(), head.getZ()});
        while (d.beds.size() > 8) d.beds.remove(0);
    }

    public static void onPlayerDeath(ServerPlayer player) {
        MinecraftServer server = levelOf(player).getServer();
        LazurData d = LazurData.get(server);
        LazurGrab.clear();
        screamLeft = -1; sleepTicks = 0; screamAt = -1;
        d.grabLevel = 0;                             // the next grab starts at 7 hits again
        d.setDirty();
        if (d.role == ROLE_CHASE || d.role == ROLE_REVEAL) {
            LazurEntity lz = findLazur(levelOf(player), d);
            if (lz != null) lz.beginDissolve();      // Lazur dissolves for 3 s and leaves a trail
            d.role = ROLE_NONE;
            d.lazurId = null;
            d.fading = false;
            promoteHeldReturns(d);                   // originals come back at the nearest dawn
            d.cdOnRespawn = true;                    // sub cooldown starts at the respawn
            clearRespawnPoint(player);               // respawn at the initial world spawn
            d.setDirty();
        }
    }

    public static void onRespawn(ServerPlayer player) {
        MinecraftServer server = levelOf(player).getServer();
        LazurData d = LazurData.get(server);
        if (d.cdOnRespawn) {
            d.cdOnRespawn = false;
            LazurConfig cfg = LazurConfig.get();
            d.subCd = rand(levelOf(player).getRandom(), cfg.subCdMin, cfg.subCdMax);
            d.setDirty();
        }
    }

    // =====================================================================================
    // the trail Lazur leaves where he dissolved: black and grey pixels along the top edges of the block for 5 s
    // =====================================================================================
    private static boolean lastChaseFlag;
    private static final class Trail {
        final ServerLevel level; final BlockPos pos; int left = 100;
        Trail(ServerLevel level, BlockPos pos) { this.level = level; this.pos = pos; }
    }
    private static final List<Trail> trails = new ArrayList<>();

    public static void addTrail(ServerLevel level, BlockPos blockUnderFeet) {
        trails.add(new Trail(level, blockUnderFeet));
    }

    private static void tickTrails() {
        Iterator<Trail> it = trails.iterator();
        while (it.hasNext()) {
            Trail t = it.next();
            if (--t.left <= 0) { it.remove(); continue; }
            if (t.left % 2 != 0) continue;
            RandomSource r = t.level.getRandom();
            for (int i = 0; i < 2; i++) {
                double a = r.nextDouble();
                double x = t.pos.getX(), z = t.pos.getZ(), y = t.pos.getY() + 1.02;
                switch (r.nextInt(4)) {
                    case 0 -> x += a;
                    case 1 -> { x += a; z += 1; }
                    case 2 -> z += a;
                    default -> { z += a; x += 1; }
                }
                t.level.sendParticles(r.nextBoolean() ? ParticleTypes.SQUID_INK : ParticleTypes.ASH, x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
            }
        }
    }

    // =====================================================================================
    // the sign "you can't outrun it": once, the day after the second attack (surface or cave)
    // =====================================================================================
    private static void countAttack(MinecraftServer server, LazurData d) {
        d.attacks++;
        if (d.signState == 0 && d.attacks >= 2) { d.signState = 1; d.signDay = LazurTime.dayIndex(server); }
        d.setDirty();
    }

    private static void tickSign(MinecraftServer server, LazurData d, ServerPlayer player, ServerLevel level) {
        long day = LazurTime.dayIndex(server);
        switch (d.signState) {
            case 1 -> {
                if (day > d.signDay && level.dimension() == Level.OVERWORLD && d.role == ROLE_NONE
                        && server.getTickCount() % 100 == 0 && placeSign(server, d, player, level)) {
                    d.signState = 2;
                    d.signDay = day;
                    d.setDirty();
                }
            }
            case 2 -> { // the player broke it (or it is gone): the silhouette comes the next day
                ServerLevel ow = server.overworld();
                BlockPos p = new BlockPos(d.signX, d.signY, d.signZ);
                if (ow.hasChunkAt(p) && !(ow.getBlockState(p).getBlock() instanceof net.minecraft.world.level.block.SignBlock)) {
                    d.signState = 3;
                    d.signDay = day;
                    d.setDirty();
                }
            }
            case 3 -> {
                if (day > d.signDay) {
                    d.signState = 4;
                    d.silCd = 0;     // the silhouette is due now; it is placed like any other one and stays until noticed
                    d.setDirty();
                }
            }
            default -> { }
        }
    }

    /** One styled letter at a time: red, every letter with its own mix of bold / italic / underline / strike and font. */
    private static String signLine(String text, RandomSource r) {
        if (text.isEmpty()) return "{text:\"\"}";
        StringBuilder sb = new StringBuilder("{text:\"\",extra:[");
        for (int i = 0; i < text.length(); i++) {
            if (i > 0) sb.append(',');
            sb.append("{text:\"").append(text.charAt(i)).append("\",color:\"").append(r.nextInt(3) == 0 ? "dark_red" : "red").append('"')
                    .append(",bold:").append(r.nextBoolean())
                    .append(",italic:").append(r.nextBoolean())
                    .append(",underlined:").append(r.nextInt(4) == 0)
                    .append(",strikethrough:").append(r.nextInt(8) == 0)
                    .append(",font:\"").append(r.nextInt(3) == 0 ? "minecraft:uniform" : "minecraft:default").append("\"}");
        }
        return sb.append("]}").toString();
    }

    /** A standing sign on a free block near the bed the player sleeps in (or where he spends his time). */
    private static boolean placeSign(MinecraftServer server, LazurData d, ServerPlayer player, ServerLevel level) {
        RandomSource rnd = level.getRandom();
        BlockPos base = null;
        if (!d.beds.isEmpty()) { int[] b = d.beds.get(d.beds.size() - 1); base = new BlockPos(b[0], b[1], b[2]); }
        else if (!d.homes.isEmpty()) { int[] h = d.homes.get(d.homes.size() - 1); base = new BlockPos(h[0], player.getBlockY(), h[1]); }
        if (base == null || !level.hasChunkAt(base)) base = player.blockPosition();
        for (int i = 0; i < 60; i++) {
            int r = 2 + rnd.nextInt(6);
            double a = rnd.nextDouble() * Math.PI * 2;
            int x = base.getX() + (int) Math.round(Math.cos(a) * r), z = base.getZ() + (int) Math.round(Math.sin(a) * r);
            for (int dy = 2; dy >= -2; dy--) {
                BlockPos feet = new BlockPos(x, base.getY() + dy, z);
                if (!level.hasChunkAt(feet)) break;
                BlockPos below = feet.below();
                if (!level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)) continue;
                if (!level.getBlockState(feet).isAir() || !level.getBlockState(feet.above()).isAir()) continue;
                if (!level.getFluidState(below).isEmpty()) continue;
                String msgs = signLine("", rnd) + "," + signLine("you can't", rnd) + "," + signLine("outrun it", rnd) + "," + signLine("", rnd);
                runCommand(server, "setblock " + x + " " + feet.getY() + " " + z + " minecraft:oak_sign[rotation=" + rnd.nextInt(16)
                        + "]{is_waxed:true,front_text:{messages:[" + msgs + "]}} replace");
                if (level.getBlockState(feet).getBlock() instanceof net.minecraft.world.level.block.SignBlock) {
                    d.signX = x; d.signY = feet.getY(); d.signZ = z;
                    return true;
                }
            }
        }
        return false;
    }

    // =====================================================================================
    // ambient
    // =====================================================================================
    private static void playAmbient(ServerLevel level, ServerPlayer player) {
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                com.lazur.registry.ModSounds.LAZUR_AMBIENT, SoundSource.AMBIENT, 1.0F, 1.0F);
    }

    /** Runs a command as the server without any chat output. Returns false if it failed. */
    static boolean runCommand(MinecraftServer server, String cmd) {
        try {
            server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(), cmd);
            return true;
        } catch (RuntimeException e) {
            com.lazur.LazurMod.LOGGER.warn("command failed: {}", cmd, e);
            return false;
        }
    }

    public static void debugScream(ServerPlayer p) {
        ServerLevel level = levelOf(p);
        level.playSound(null, p.getX(), p.getY(), p.getZ(), com.lazur.registry.ModSounds.LAZUR_SCREAM, SoundSource.MASTER, 1.0F, 1.0F);
        net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(p, new com.lazur.net.LazurNet.Scream(SCREAM_TICKS));
    }

    public static void debugAmbient(ServerPlayer p) {
        playAmbient(levelOf(p), p);
    }

    // =====================================================================================
    // noises Lazur can hear while searching
    // =====================================================================================
    public static void onNoise(ServerLevel level, Vec3 pos, double radius) {
        LazurData d = LazurData.get(level.getServer());
        if (d.role != ROLE_CHASE) return;
        LazurEntity lz = findLazur(level, d);
        if (lz != null) lz.hearSound(pos, radius);
    }

    /** Called from the Simple Voice Chat plugin (voice thread!), so the work is moved to the server thread. */
    public static void onVoice(ServerPlayer player, boolean whisper) {
        MinecraftServer server = levelOf(player).getServer();
        LazurConfig cfg = LazurConfig.get();
        double radius = whisper ? cfg.hearWhisper : cfg.hearVoice;
        server.execute(() -> {
            if (player.isAlive()) onNoise(levelOf(player), player.position(), radius);
        });
    }

    // =====================================================================================
    // debug (used by /lazur ...)
    // =====================================================================================
    public static String status(MinecraftServer server) {
        LazurData d = LazurData.get(server);
        StringBuilder sb = new StringBuilder();
        sb.append("role=").append(d.role).append(" silCd=").append(d.silCd / 20).append("s subCd=").append(d.subCd / 20)
                .append("s stage=").append(d.stage).append(d.stage == 0 ? " (kick in " + Math.max(0, d.kickNeed - d.preTicks) / 20 + "s)" : "").append(" farTicks=").append(d.farTicks).append(" chaseLeft=").append(d.chaseTicks / 20).append("s");
        if (d.sub != null) {
            Sub s = d.sub;
            sb.append(" | sub type=").append(s.type).append(" at ").append(s.x).append(' ').append(s.y).append(' ').append(s.z)
                    .append(" abandon=").append(s.abandon / 20).append("s reveal=").append(s.reveal < 0 ? "-" : (s.reveal / 20) + "s")
                    .append(" gaze=").append(s.gaze).append(" near=").append(s.near).append("/").append(s.nearNeed);
        }
        sb.append(" | cave timer ").append(d.stage >= 2 ? (caveTicks / 20) + "s of " + (caveNeed <= 0 ? "?" : (caveNeed / 20) + "s") + " underground" : "off until the first silhouette");
        long left = d.ambNext - LazurTime.gameTimeOf(server);
        sb.append(" | ambient in ").append(left <= 0 ? 0 : left / 24000).append(" days");
        sb.append(" | returns=").append(d.returns.size()).append(" | clock=").append(LazurTime.describe());
        return sb.toString();
    }

    /** The fake connection error (looks like a network problem, not like a kick). After it: the first silhouette in 1-2 days. */
    private static void kickPlayer(LazurData d, ServerPlayer player, RandomSource rnd) {
        d.stage = 1;
        d.silCd = rand(rnd, 24000, 48000);                 // 1-2 days until the first silhouette
        d.setDirty();                                      // saved before the player is thrown out
        player.connection.disconnect(net.minecraft.network.chat.Component.literal(
                "Internal Exception: java.io.IOException: An existing connection was forcibly closed by the remote host"));
    }

    /** Debug: do it right now. */
    public static boolean debugKick(ServerPlayer p) {
        MinecraftServer server = levelOf(p).getServer();
        kickPlayer(LazurData.get(server), p, levelOf(p).getRandom());
        return true;
    }

    public static boolean debugSilhouette(ServerPlayer p) {
        MinecraftServer server = levelOf(p).getServer();
        LazurData d = LazurData.get(server);
        if (d.role != ROLE_NONE) return false;
        return spawnSilhouette(server, d, p, levelOf(p), levelOf(p).getRandom(), LazurConfig.get(), true);
    }

    public static boolean debugSubstitute(ServerPlayer p) {
        MinecraftServer server = levelOf(p).getServer();
        LazurData d = LazurData.get(server);
        if (d.role != ROLE_NONE || d.sub != null) return false;
        return trySubstitute(server, d, p, levelOf(p), levelOf(p).getRandom(), LazurConfig.get(), true);
    }

    /** Lazur takes the nearest suitable animal right now (ignores cooldowns and the "not in view" rule). */
    public static boolean debugMob(ServerPlayer p) {
        MinecraftServer server = levelOf(p).getServer();
        LazurData d = LazurData.get(server);
        if (d.role != ROLE_NONE || d.sub != null) return false;
        return substituteCreature(d, p, levelOf(p), levelOf(p).getRandom(), LazurConfig.get(), true);
    }

    /** Cave form right now (also works on the surface, only the placement differs). */
    public static boolean debugCave(MinecraftServer server, ServerPlayer p) {
        LazurData d = LazurData.get(server);
        if (d.role != ROLE_NONE || d.sub != null) return false;
        return spawnWatcher(server, d, p, levelOf(p), levelOf(p).getRandom(), LazurConfig.get(), true, true);
    }

    public static boolean debugReveal(ServerPlayer p) {
        LazurData d = LazurData.get(levelOf(p).getServer());
        if (d.sub == null) return false;
        d.sub.force = true;
        d.setDirty();
        return true;
    }

    public static boolean debugChase(ServerPlayer p) {
        ServerLevel level = levelOf(p);
        LazurData d = LazurData.get(level.getServer());
        if (d.role != ROLE_NONE) return false;
        Vec3 look = p.getLookAngle();
        Vec3 base = new Vec3(p.getX() + look.x * 14, p.getY(), p.getZ() + look.z * 14);
        float yaw = (float) Math.toDegrees(Math.atan2(look.x, -look.z));
        LazurEntity lz = spawn(level, base, yaw, LazurEntity.A_FIGURE, LazurEntity.S_RUN);
        placeFree(level, lz, base);
        beginChase(d, level, lz, LazurConfig.get());
        return true;
    }

    /** Lazur appears 2.5 blocks in front of the player and grabs him at once (for testing the mini-game). */
    public static boolean debugGrab(ServerPlayer p) {
        ServerLevel level = levelOf(p);
        LazurData d = LazurData.get(level.getServer());
        if (d.role != ROLE_NONE) return false;
        Vec3 look = p.getLookAngle();
        double len = Math.max(1.0E-3, Math.hypot(look.x, look.z));
        Vec3 base = new Vec3(p.getX() + look.x / len * 2.5, p.getY(), p.getZ() + look.z / len * 2.5);
        float yaw = (float) Math.toDegrees(Math.atan2(-(p.getX() - base.x), p.getZ() - base.z));
        LazurEntity lz = spawn(level, base, yaw, LazurEntity.A_FIGURE, LazurEntity.S_RUN);
        placeFree(level, lz, base);
        beginChase(d, level, lz, LazurConfig.get());
        LazurGrab.begin(d, p, lz);
        return true;
    }

    public static boolean debugAnim(ServerPlayer p, String name) {
        ServerLevel level = levelOf(p);
        LazurData d = LazurData.get(level.getServer());
        if (d.role != ROLE_NONE) return false;
        int state = switch (name) {
            case "walk" -> LazurEntity.S_WALK;
            case "creep" -> LazurEntity.S_CREEP;
            case "run" -> LazurEntity.S_RUN;
            case "attack" -> LazurEntity.S_ATTACK;
            case "glitch" -> LazurEntity.S_GLITCH;
            case "fade" -> LazurEntity.S_FADE;
            case "grab" -> LazurEntity.S_GRAB;
            default -> LazurEntity.S_IDLE;
        };
        int look = name.equals("skin") ? LazurEntity.A_SKIN : LazurEntity.A_FIGURE;
        Vec3 dir = p.getLookAngle();
        Vec3 base = new Vec3(p.getX() + dir.x * 6, p.getY(), p.getZ() + dir.z * 6);
        float yaw = (float) Math.toDegrees(Math.atan2(dir.x, -dir.z));
        LazurEntity lz = spawn(level, base, yaw, look, state);
        d.role = ROLE_TEST;
        d.lazurId = lz.getUUID();
        d.setDirty();
        return true;
    }

    public static void debugClear(MinecraftServer server) {
        LazurGrab.clear();
        LazurData d = LazurData.get(server);
        for (ServerLevel lv : server.getAllLevels()) {
            for (var e : lv.getAllEntities()) {
                if (e instanceof LazurEntity) e.discard();
            }
        }
        d.role = ROLE_NONE;
        d.lazurId = null;
        d.fading = false;
        d.phase = 0;
        d.phaseTicks = 0;
        lastGazeSent = -1;
        spinSoundUntil = 0;
        d.setDirty();
    }
}
