package com.lazur.logic;

import com.lazur.LazurConfig;
import com.lazur.entity.LazurEntity;
import com.lazur.state.LazurData;
import com.lazur.state.LazurData.Ret;
import com.lazur.state.LazurData.Sub;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/**
 * Server-side brain. Singleplayer only: it works with the first player on the server.
 * Concept doc sections 3-8.
 */
public final class LazurManager {
    public static final int ROLE_NONE = 0, ROLE_SILHOUETTE = 1, ROLE_CHASE = 2, ROLE_REVEAL = 3, ROLE_TEST = 4;
    public static final int SUB_BLOCK = 1, SUB_BED = 2, SUB_MOB = 3;

    private static long nextTry = 0;

    private LazurManager() {}

    // =====================================================================================
    // helpers
    // =====================================================================================
    private static ServerLevel levelOf(ServerPlayer p) { return (ServerLevel) p.level(); }

    private static int rand(RandomSource r, int min, int max) { return min + r.nextInt(Math.max(1, max - min + 1)); }

    private static LazurEntity findLazur(ServerLevel level, LazurData d) {
        if (d.lazurId == null) return null;
        return level.getEntity(d.lazurId) instanceof LazurEntity l ? l : null;
    }

    public static boolean owns(LazurEntity e) {
        if (!(e.level() instanceof ServerLevel sl)) return true;
        LazurData d = LazurData.get(sl.getServer());
        return e.getUUID().equals(d.lazurId);
    }

    private static LazurEntity spawn(ServerLevel level, Vec3 pos, float yaw, int appearance, int state) {
        LazurEntity lz = new LazurEntity(com.lazur.registry.ModEntities.LAZUR, level);
        lz.setPos(pos.x, pos.y, pos.z);
        lz.setYRot(yaw);
        lz.setYBodyRot(yaw);
        lz.setYHeadRot(yaw);
        lz.setAppearance(appearance);
        lz.setLazurState(state);
        level.addFreshEntity(lz);
        return lz;
    }

    private static void placeFree(ServerLevel level, LazurEntity lz, Vec3 base) {
        for (int dy = 0; dy <= 3; dy++) {
            for (int r = 0; r <= 2; r++) {
                for (int dx = -r; dx <= r; dx++) {
                    for (int dz = -r; dz <= r; dz++) {
                        if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
                        lz.setPos(base.x + dx, base.y + dy, base.z + dz);
                        if (level.noCollision(lz)) return;
                    }
                }
            }
        }
        lz.setPos(base.x, base.y, base.z);
    }

    private static void roar(ServerLevel level, LazurEntity lz) {
        level.playSound(null, lz.getX(), lz.getY(), lz.getZ(), SoundEvents.ENDER_DRAGON_GROWL, SoundSource.HOSTILE, 5.0F, 0.7F);
    }

    /** One line, isolated: if setRespawnPosition changed in 26.2, fix it here. null = no custom spawn = world spawn. */
    private static void clearRespawnPoint(ServerPlayer player) {
        player.setRespawnPosition(null, false);
    }

    private static double minHomeDist(LazurData d, ServerPlayer p) {
        double best = Double.MAX_VALUE;
        for (int[] h : d.homes) best = Math.min(best, Math.hypot(p.getX() - h[0], p.getZ() - h[1]));
        return best;
    }

    // =====================================================================================
    // main tick
    // =====================================================================================
    public static void tick(MinecraftServer server) {
        List<ServerPlayer> players = server.getPlayerList().getPlayers();
        if (players.isEmpty()) return;
        ServerPlayer player = players.get(0);
        ServerLevel level = levelOf(player);
        LazurData d = LazurData.get(server);
        LazurConfig cfg = LazurConfig.get();
        RandomSource rnd = level.getRandom();

        if (!d.initialized) {
            d.initialized = true;
            d.silCd = rand(rnd, cfg.silhouetteCdMin, cfg.silhouetteCdMax);
            d.subCd = rand(rnd, cfg.subCdMin, cfg.subCdMax);
            d.homes.add(new int[]{player.getBlockX(), player.getBlockZ()});
            d.lastDay = LazurTime.dayIndex(server);
            d.setDirty();
        }
        if (!player.isAlive()) return;

        long gameNow = server.overworld().getGameTime();
        if (d.ambNext == 0) { // not scheduled yet (new world or data from an older version)
            // first ambient 5 days after world creation; in an older world: 5-10 days from now
            d.ambNext = gameNow < 120000L ? 120000L : gameNow + rand(rnd, 120000, 240000);
            d.setDirty();
        }
        if (gameNow >= d.ambNext) {
            if (d.role == ROLE_CHASE || d.role == ROLE_REVEAL) {
                d.ambNext = gameNow + 1200; // not during a chase, try again in a minute
            } else {
                playAmbient(level, player);
                d.ambNext = gameNow + rand(rnd, 120000, 240000); // next one in 5-10 days
            }
            d.setDirty();
        }

        boolean overworld = level.dimension() == Level.OVERWORLD;

        if (d.silCd > 0) d.silCd--;
        if (d.role == ROLE_NONE && d.sub == null && d.subCd > 0) d.subCd--;

        dawnCheck(server, d);
        if (server.getTickCount() % 10 == 0) returnsTick(server, d, player);

        if (overworld) {
            if (minHomeDist(d, player) > cfg.farRadiusBlocks) d.farTicks++; else d.farTicks = 0;
        }

        tickRole(server, d, player, level, rnd, cfg);
        if (d.sub != null && overworld) tickSub(server, d, player, level, rnd, cfg);
        if (d.bedAttack > 0 && --d.bedAttack == 0) bedAttackNow(server, d, player, level, rnd, cfg);

        if (d.role == ROLE_NONE && d.sub == null && overworld && server.getTickCount() % 20 == 0) {
            trySpawn(server, d, player, level, rnd, cfg, false);
        }
        if (server.getTickCount() % 20 == 0) d.setDirty();
    }

    // =====================================================================================
    // dawn + returning blocks
    // =====================================================================================
    private static void dawnCheck(MinecraftServer server, LazurData d) {
        long day = LazurTime.dayIndex(server);
        if (day > d.lastDay) {
            d.lastDay = day;
            triggerDawn(d);
        } else if (day < d.lastDay) {
            d.lastDay = day; // time was set back
        }
    }

    public static int triggerDawn(LazurData d) {
        int n = 0;
        for (Ret r : d.returns) {
            if (r.status == LazurData.READY) { r.status = LazurData.DUE; n++; }
        }
        d.setDirty();
        return n;
    }

    private static void returnsTick(MinecraftServer server, LazurData d, ServerPlayer player) {
        ServerLevel ow = server.overworld();
        Iterator<Ret> it = d.returns.iterator();
        while (it.hasNext()) {
            Ret r = it.next();
            BlockPos pos = r.pos();
            if (r.status == LazurData.DUE) {
                if (!ow.hasChunkAt(pos)) continue; // comes back when the chunk loads
                BlockState cur = ow.getBlockState(pos);
                if (cur.isAir() || cur.canBeReplaced()) {
                    BlockSnapshot.restore(ow, r);
                } // else: the spot was built over, the original is gone forever
                it.remove();
                d.setDirty();
            } else if (r.particles && levelOf(player) == ow && ow.hasChunkAt(pos)) {
                Vec3 c = Vec3.atCenterOf(pos);
                if (player.position().distanceToSqr(c) < 24 * 24 && Sight.inView(player, c, 0.9)
                        && Sight.pointVisible(ow, player, player.getEyePosition(), c, pos)) {
                    ow.sendParticles(ParticleTypes.SQUID_INK, c.x, c.y, c.z, 3, 0.25, 0.25, 0.25, 0.01);
                    r.seen += 10;
                    if (r.seen >= 40) r.particles = false; // seen it: the particles are gone
                    d.setDirty();
                }
            }
        }
    }

    private static void promoteHeldReturns(LazurData d) {
        for (Ret r : d.returns) if (r.status == LazurData.HOLD) r.status = LazurData.READY;
        d.setDirty();
    }

    // =====================================================================================
    // roles: silhouette / reveal / chase
    // =====================================================================================
    private static void tickRole(MinecraftServer server, LazurData d, ServerPlayer player, ServerLevel level,
                                 RandomSource rnd, LazurConfig cfg) {
        if (d.role == ROLE_NONE || d.role == ROLE_TEST) return;
        LazurEntity lz = findLazur(level, d);
        if (lz == null) {
            if (++d.missing > 200) endRoleAbnormally(server, d, rnd, cfg);
            return;
        }
        d.missing = 0;
        switch (d.role) {
            case ROLE_SILHOUETTE -> tickSilhouette(d, player, level, lz, rnd, cfg);
            case ROLE_REVEAL -> {
                if (--d.phaseTicks <= 0) beginChase(d, level, lz, cfg);
            }
            case ROLE_CHASE -> tickChase(d, player, level, lz, rnd, cfg);
            default -> { }
        }
    }

    private static void tickSilhouette(LazurData d, ServerPlayer player, ServerLevel level, LazurEntity lz,
                                       RandomSource rnd, LazurConfig cfg) {
        switch (d.phase) {
            case 0 -> { // standing at the edge of visibility
                d.age++;
                Vec3 eye = lz.position().add(0, lz.getBbHeight() * 0.85, 0);
                boolean seen = Sight.inView(player, eye, 0.97) && Sight.visibleSamples(level, player, lz) > 0;
                if (seen || lz.distanceTo(player) < 48 || d.age > cfg.silhouetteGiveUpTicks) {
                    d.phase = 1;
                    d.glitchTotal = rand(rnd, cfg.glitchMinTicks, cfg.glitchMaxTicks);
                    d.phaseTicks = d.glitchTotal;
                    lz.setLazurState(LazurEntity.S_GLITCH);
                }
            }
            case 1 -> { // glitch 1-2 s, turns into the black figure halfway
                d.phaseTicks--;
                if (d.phaseTicks == d.glitchTotal / 2) lz.setAppearance(LazurEntity.A_FIGURE);
                if (d.phaseTicks <= 0) {
                    d.phase = 2;
                    d.phaseTicks = 60;
                    lz.setAppearance(LazurEntity.A_FIGURE);
                    lz.setLazurState(LazurEntity.S_FADE);
                }
            }
            default -> { // dissolve, then gone
                if (--d.phaseTicks <= 0) {
                    lz.discard();
                    d.role = ROLE_NONE;
                    d.lazurId = null;
                    d.silCd = rand(rnd, cfg.silhouetteCdMin, cfg.silhouetteCdMax);
                    d.setDirty();
                }
            }
        }
    }

    private static void beginChase(LazurData d, ServerLevel level, LazurEntity lz, LazurConfig cfg) {
        d.role = ROLE_CHASE;
        d.lazurId = lz.getUUID();
        d.chaseTicks = cfg.chaseTicks;
        d.fading = false;
        lz.setAppearance(LazurEntity.A_FIGURE);
        lz.resetAttack();
        lz.setLazurState(LazurEntity.S_RUN);
        roar(level, lz);
        d.setDirty();
    }

    private static void tickChase(LazurData d, ServerPlayer player, ServerLevel level, LazurEntity lz,
                                  RandomSource rnd, LazurConfig cfg) {
        if (d.fading) {
            if (--d.phaseTicks <= 0) {
                lz.discard();
                finishChase(d, rnd, cfg);
            }
            return;
        }
        if (--d.chaseTicks <= 0 || levelOf(player) != level) {
            d.fading = true;
            d.phaseTicks = 60;
            lz.getNavigation().stop();
            lz.setLazurState(LazurEntity.S_FADE);
            return;
        }
        lz.chaseTick(player);
    }

    private static void finishChase(LazurData d, RandomSource rnd, LazurConfig cfg) {
        d.role = ROLE_NONE;
        d.lazurId = null;
        d.fading = false;
        promoteHeldReturns(d);                                  // originals wait for dawn now
        d.subCd = rand(rnd, cfg.subCdMin, cfg.subCdMax);         // cooldown starts after the chase
        d.setDirty();
    }

    private static void endRoleAbnormally(MinecraftServer server, LazurData d, RandomSource rnd, LazurConfig cfg) {
        boolean wasChase = d.role == ROLE_CHASE || d.role == ROLE_REVEAL;
        d.role = ROLE_NONE;
        d.lazurId = null;
        d.fading = false;
        d.missing = 0;
        if (wasChase) finishChase(d, rnd, cfg);
        else d.silCd = rand(rnd, cfg.silhouetteCdMin, cfg.silhouetteCdMax);
        d.setDirty();
    }

    // =====================================================================================
    // spawning decisions
    // =====================================================================================
    public static boolean trySpawn(MinecraftServer server, LazurData d, ServerPlayer player, ServerLevel level,
                                   RandomSource rnd, LazurConfig cfg, boolean debug) {
        if (!debug && server.getTickCount() < nextTry) return false;
        double home = minHomeDist(d, player);
        boolean far = d.farTicks >= cfg.farTicksRequired;
        boolean near = home <= cfg.nearRadiusBlocks;
        boolean ok = false;
        if (far && d.silCd <= 0) ok = spawnSilhouette(server, d, player, level, rnd, cfg, false);
        else if (near && d.subCd <= 0) ok = trySubstitute(server, d, player, level, rnd, cfg, false);
        if (!ok) nextTry = server.getTickCount() + 100;
        return ok;
    }

    /** debug = skip the "partially behind cover" requirement. */
    public static boolean spawnSilhouette(MinecraftServer server, LazurData d, ServerPlayer player, ServerLevel level,
                                          RandomSource rnd, LazurConfig cfg, boolean debug) {
        int vd = server.getPlayerList().getViewDistance();
        int maxC = Math.min(cfg.silhouetteMaxChunks, vd - 1);
        int minC = Math.min(cfg.silhouetteMinChunks, maxC);
        if (maxC < 3) return false;
        Vec3 look = player.getLookAngle();
        double base = Math.atan2(look.z, look.x);
        Vec3 eye = player.getEyePosition();

        for (int i = 0; i < 48; i++) {
            double ang = base + (rnd.nextDouble() - 0.5) * Math.toRadians(140);
            double dist = (minC + rnd.nextDouble() * (maxC - minC)) * 16.0;
            int x = Mth.floor(player.getX() + Math.cos(ang) * dist);
            int z = Mth.floor(player.getZ() + Math.sin(ang) * dist);
            if (!level.hasChunkAt(new BlockPos(x, 64, z))) continue;
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos feet = new BlockPos(x, y, z);
            BlockPos below = feet.below();
            if (!level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)) continue;
            if (!level.getFluidState(feet).isEmpty() || !level.getFluidState(below).isEmpty()) continue;

            double dx = player.getX() - (x + 0.5), dz = player.getZ() - (z + 0.5);
            double len = Math.max(1.0E-3, Math.hypot(dx, dz));
            dx /= len; dz /= len;

            if (!debug) {
                // partly hidden behind a wall / hill / tree on the player's side
                int blocked = 0;
                for (int step = 1; step <= 2; step++) {
                    for (int h = 0; h < 3; h++) {
                        BlockPos p = new BlockPos(Mth.floor(x + 0.5 + dx * step), y + h, Mth.floor(z + 0.5 + dz * step));
                        BlockState bs = level.getBlockState(p);
                        if (!bs.isAir() && bs.getFluidState().isEmpty() && !bs.canBeReplaced()) blocked++;
                    }
                }
                if (blocked < 2) continue;
                int vis = 0;
                for (double hy : new double[]{0.3, 1.5, 2.7}) {
                    if (Sight.pointVisible(level, player, eye, new Vec3(x + 0.5, y + hy, z + 0.5), null)) vis++;
                }
                if (vis < 1 || vis > 2) continue;
            }

            float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
            LazurEntity lz = spawn(level, new Vec3(x + 0.5, y, z + 0.5), yaw, LazurEntity.A_SKIN, LazurEntity.S_IDLE);
            d.role = ROLE_SILHOUETTE;
            d.lazurId = lz.getUUID();
            d.phase = 0;
            d.age = 0;
            d.farTicks = 0;
            d.missing = 0;
            d.setDirty();
            return true;
        }
        return false;
    }

    // ---- substitution choice ----
    public static boolean trySubstitute(MinecraftServer server, LazurData d, ServerPlayer player, ServerLevel level,
                                        RandomSource rnd, LazurConfig cfg, boolean debug) {
        if (rnd.nextDouble() < cfg.creatureChance && substituteCreature(d, player, level, rnd, cfg, debug)) return true;
        return substituteBlock(d, player, level, rnd, cfg, debug);
    }

    private static boolean hidden(ServerLevel level, ServerPlayer p, Vec3 center, BlockPos ignore, boolean debug) {
        if (debug) return true;
        // not in the view cone (about 60 degrees) or no clear line from the eyes
        return !Sight.inView(p, center, 0.5) || !Sight.pointVisible(level, p, p.getEyePosition(), center, ignore);
    }

    private static boolean substituteBlock(LazurData d, ServerPlayer player, ServerLevel level, RandomSource rnd,
                                           LazurConfig cfg, boolean debug) {
        BlockPos c = player.blockPosition();
        int R = cfg.searchRadius, V = cfg.searchVertical;
        List<BlockPos> normal = new ArrayList<>();
        List<BlockPos> beds = new ArrayList<>();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int x = -R; x <= R; x++) {
            for (int z = -R; z <= R; z++) {
                for (int y = -V; y <= V; y++) {
                    m.set(c.getX() + x, c.getY() + y, c.getZ() + z);
                    if (!level.hasChunkAt(m)) continue;
                    BlockState s = level.getBlockState(m);
                    if (s.getBlock() instanceof BedBlock) {
                        if (s.getValue(BedBlock.PART) == BedPart.HEAD) beds.add(m.immutable());
                    } else if (Targets.isFunctional(s)) {
                        normal.add(m.immutable());
                    }
                }
            }
        }
        boolean wantBed = !beds.isEmpty() && rnd.nextDouble() < cfg.bedChance;
        List<BlockPos> pool = wantBed ? beds : normal;
        pool.removeIf(p -> !hidden(level, player, Vec3.atCenterOf(p), p, debug));
        if (pool.isEmpty()) return false;

        BlockPos pick = pool.get(rnd.nextInt(pool.size()));
        Sub s = new Sub();
        s.type = wantBed ? SUB_BED : SUB_BLOCK;
        s.x = pick.getX(); s.y = pick.getY(); s.z = pick.getZ();
        s.blockId = BuiltInRegistries.BLOCK.getKey(level.getBlockState(pick).getBlock()).toString();
        s.abandon = wantBed ? -1 : rand(rnd, cfg.abandonMin, cfg.abandonMax);
        s.reveal = -1;
        d.sub = s;
        d.setDirty();
        return true;
    }

    private static boolean substituteCreature(LazurData d, ServerPlayer player, ServerLevel level, RandomSource rnd,
                                              LazurConfig cfg, boolean debug) {
        List<Mob> cands = level.getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(cfg.searchRadius), m ->
                m.isAlive() && m.getType().getCategory() == MobCategory.CREATURE
                        && !(m instanceof TamableAnimal) && !m.isBaby() && !m.hasCustomName()
                        // "in a pen": at least one more of the same species close by
                        && !level.getEntitiesOfClass(Mob.class, m.getBoundingBox().inflate(6.0),
                        o -> o != m && o.getType() == m.getType()).isEmpty());
        cands.removeIf(m -> !hidden(level, player, m.getEyePosition(), null, debug));
        if (cands.isEmpty()) return false;

        Mob pick = cands.get(rnd.nextInt(cands.size()));
        Sub s = new Sub();
        s.type = SUB_MOB;
        s.x = pick.getBlockX(); s.y = pick.getBlockY(); s.z = pick.getBlockZ();
        s.mob = pick.getUUID().toString();
        d.sub = s;
        d.setDirty();
        return true;
    }

    // =====================================================================================
    // active substitution
    // =====================================================================================
    private static void tickSub(MinecraftServer server, LazurData d, ServerPlayer player, ServerLevel level,
                                RandomSource rnd, LazurConfig cfg) {
        Sub s = d.sub;
        if (s.type == SUB_MOB) { tickMob(d, player, level, rnd, cfg, s); return; }

        BlockPos pos = s.pos();
        if (!level.hasChunkAt(pos)) return; // chunk unloaded: wait
        BlockState st = level.getBlockState(pos);
        if (!BuiltInRegistries.BLOCK.getKey(st.getBlock()).toString().equals(s.blockId)) {
            // removed by something else: Lazur loses its host
            d.sub = null;
            d.subCd = rand(rnd, cfg.subCdMin, cfg.subCdMax);
            d.setDirty();
            return;
        }
        if (s.type == SUB_BED) {
            if (s.force) { s.force = false; bedAttackNow(server, d, player, level, rnd, cfg); }
            return; // otherwise the bed works normally until the player sleeps in it
        }

        Vec3 center = Vec3.atCenterOf(pos);
        if (s.reveal < 0) {
            if (s.abandon > 0 && --s.abandon == 0) abandonBlock(d, level, rnd, cfg, s);
            else if (s.force) attackFromBlock(d, player, level, cfg, s);
        } else {
            if (s.reveal > 0) s.reveal--;
            boolean close = player.position().distanceToSqr(center) <= cfg.attackRadius * cfg.attackRadius;
            if (s.force || (s.reveal == 0 && close)) attackFromBlock(d, player, level, cfg, s);
        }
    }

    private static void abandonBlock(LazurData d, ServerLevel level, RandomSource rnd, LazurConfig cfg, Sub s) {
        Ret r = BlockSnapshot.capture(level, s.pos());
        r.status = LazurData.READY;       // back at the next dawn
        r.particles = true;
        d.returns.add(r);
        level.removeBlock(s.pos(), false); // silent, just empty air
        d.sub = null;
        d.subCd = rand(rnd, cfg.subCdMin, cfg.subCdMax); // Lazur goes elsewhere
        d.setDirty();
    }

    private static void attackFromBlock(LazurData d, ServerPlayer player, ServerLevel level, LazurConfig cfg, Sub s) {
        BlockPos pos = s.pos();
        Ret r = BlockSnapshot.capture(level, pos);
        r.status = LazurData.HOLD;         // waits for the chase to end, then for dawn
        d.returns.add(r);
        level.destroyBlock(pos, false);    // particles + break sound
        d.sub = null;

        Vec3 base = new Vec3(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
        float yaw = (float) Math.toDegrees(Math.atan2(-(player.getX() - base.x), player.getZ() - base.z));
        LazurEntity lz = spawn(level, base, yaw, LazurEntity.A_FIGURE, LazurEntity.S_RUN);
        placeFree(level, lz, base);
        beginChase(d, level, lz, cfg);
    }

    private static void tickMob(LazurData d, ServerPlayer player, ServerLevel level, RandomSource rnd,
                                LazurConfig cfg, Sub s) {
        Mob mob = null;
        try {
            if (level.getEntity(UUID.fromString(s.mob)) instanceof Mob m && m.isAlive()) mob = m;
        } catch (IllegalArgumentException ignored) { }
        if (mob == null) {
            // creature gone (killed / unloaded for good): Lazur loses its host
            if (++d.missing > 600) {
                d.missing = 0;
                d.sub = null;
                d.subCd = rand(rnd, cfg.subCdMin, cfg.subCdMax);
                d.setDirty();
            }
            return;
        }
        d.missing = 0;
        s.x = mob.getBlockX(); s.y = mob.getBlockY(); s.z = mob.getBlockZ();

        double dist = player.distanceTo(mob);
        if (dist < 24) mob.getLookControl().setLookAt(player, 30.0F, 30.0F); // never looks away

        Vec3 eyeMob = mob.getEyePosition();
        boolean looking = dist <= cfg.creatureRevealRadius + mob.getBbWidth() * 0.5
                && Sight.inView(player, eyeMob, 0.99)
                && Sight.pointVisible(level, player, player.getEyePosition(), eyeMob, null);
        s.gaze = looking ? s.gaze + 1 : 0; // looking away or leaving resets the count
        if (s.force) s.gaze = cfg.creatureGazeTicks;

        if (s.gaze >= cfg.creatureGazeTicks) {
            Vec3 p = mob.position();
            float yaw = mob.getYRot();
            mob.discard(); // the original is gone forever
            LazurEntity lz = spawn(level, p, yaw, LazurEntity.A_FIGURE, LazurEntity.S_GLITCH);
            placeFree(level, lz, p);
            d.sub = null;
            d.role = ROLE_REVEAL;
            d.lazurId = lz.getUUID();
            d.phaseTicks = 24;
            d.missing = 0;
            d.setDirty();
        }
    }

    // =====================================================================================
    // beds
    // =====================================================================================
    private static void bedAttackNow(MinecraftServer server, LazurData d, ServerPlayer player, ServerLevel level,
                                     RandomSource rnd, LazurConfig cfg) {
        Sub s = d.sub;
        if (s == null || s.type != SUB_BED) return;
        BlockPos head = s.pos();
        BlockState hs = level.getBlockState(head);
        if (hs.getBlock() instanceof BedBlock) {
            BlockPos foot = head.relative(hs.getValue(BedBlock.FACING).getOpposite());
            level.destroyBlock(head, false);
            if (level.getBlockState(foot).getBlock() instanceof BedBlock) level.destroyBlock(foot, false);
        }
        d.sub = null; // a bed never comes back
        clearRespawnPoint(player);

        Vec3 base = new Vec3(head.getX() + 0.5, head.getY(), head.getZ() + 0.5);
        float yaw = (float) Math.toDegrees(Math.atan2(-(player.getX() - base.x), player.getZ() - base.z));
        LazurEntity lz = spawn(level, base, yaw, LazurEntity.A_FIGURE, LazurEntity.S_RUN);
        placeFree(level, lz, base);
        beginChase(d, level, lz, cfg);
    }

    // =====================================================================================
    // Fabric events
    // =====================================================================================
    public static InteractionResult onUseBlock(Player player, Level level, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide() || !(level instanceof ServerLevel sl) || !(player instanceof ServerPlayer)) {
            return InteractionResult.PASS;
        }
        LazurData d = LazurData.get(sl.getServer());
        Sub s = d.sub;
        if (s == null || s.type != SUB_BLOCK || !hit.getBlockPos().equals(s.pos())) return InteractionResult.PASS;

        LazurConfig cfg = LazurConfig.get();
        if (s.reveal < 0) { // first click starts the hidden timer, later clicks change nothing
            s.reveal = rand(sl.getRandom(), cfg.revealMin, cfg.revealMax);
            s.abandon = -1;
            d.setDirty();
        }
        if (level.getBlockState(hit.getBlockPos()).getBlock() instanceof ChestBlock) {
            return InteractionResult.FAIL; // the chest does not open (the items are with the original)
        }
        return InteractionResult.PASS;
    }

    /** Return false to cancel the break. Trying to destroy Lazur wakes it up. */
    public static boolean onBreakBlock(Level level, Player player, BlockPos pos) {
        if (level.isClientSide() || !(level instanceof ServerLevel sl)) return true;
        LazurData d = LazurData.get(sl.getServer());
        Sub s = d.sub;
        if (s == null || (s.type != SUB_BLOCK && s.type != SUB_BED)) return true;
        boolean hit = pos.equals(s.pos());
        if (!hit && s.type == SUB_BED) {
            BlockState bs = sl.getBlockState(s.pos());
            if (bs.getBlock() instanceof BedBlock) hit = pos.equals(s.pos().relative(bs.getValue(BedBlock.FACING).getOpposite()));
        }
        if (!hit) return true;
        s.force = true; // handled in the next tick
        d.setDirty();
        return false;
    }

    public static void onStopSleeping(LivingEntity entity, BlockPos sleepingPos) {
        if (!(entity instanceof ServerPlayer sp)) return;
        MinecraftServer server = levelOf(sp).getServer();
        LazurData d = LazurData.get(server);
        // a bed the player slept in counts as "home" for the far-silhouette rule
        d.homes.add(new int[]{sleepingPos.getX(), sleepingPos.getZ()});
        while (d.homes.size() > 8) d.homes.remove(1);
        Sub s = d.sub;
        if (s != null && s.type == SUB_BED && sleepingPos.distManhattan(s.pos()) <= 1) {
            d.bedAttack = 3; // the bed breaks right after waking up
        }
        d.setDirty();
    }

    public static void onPlayerDeath(ServerPlayer player) {
        MinecraftServer server = levelOf(player).getServer();
        LazurData d = LazurData.get(server);
        if (d.role == ROLE_CHASE || d.role == ROLE_REVEAL) {
            LazurEntity lz = findLazur(levelOf(player), d);
            if (lz != null) lz.discard();            // Lazur vanishes at once
            d.role = ROLE_NONE;
            d.lazurId = null;
            d.fading = false;
            promoteHeldReturns(d);                   // originals come back at the nearest dawn
            d.cdOnRespawn = true;                    // sub cooldown starts at the respawn
            clearRespawnPoint(player);               // respawn at the initial world spawn
            d.setDirty();
        }
    }

    public static void onRespawn(ServerPlayer player) {
        MinecraftServer server = levelOf(player).getServer();
        LazurData d = LazurData.get(server);
        if (d.cdOnRespawn) {
            d.cdOnRespawn = false;
            LazurConfig cfg = LazurConfig.get();
            d.subCd = rand(levelOf(player).getRandom(), cfg.subCdMin, cfg.subCdMax);
            d.setDirty();
        }
    }

    // =====================================================================================
    // ambient
    // =====================================================================================
    private static void playAmbient(ServerLevel level, ServerPlayer player) {
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                com.lazur.registry.ModSounds.LAZUR_AMBIENT, SoundSource.AMBIENT, 1.0F, 1.0F);
    }

    public static void debugAmbient(ServerPlayer p) {
        playAmbient(levelOf(p), p);
    }

    // =====================================================================================
    // noises Lazur can hear while searching
    // =====================================================================================
    public static void onNoise(ServerLevel level, Vec3 pos, double radius) {
        LazurData d = LazurData.get(level.getServer());
        if (d.role != ROLE_CHASE) return;
        LazurEntity lz = findLazur(level, d);
        if (lz != null) lz.hearSound(pos, radius);
    }

    /** Called from the Simple Voice Chat plugin (voice thread!), so the work is moved to the server thread. */
    public static void onVoice(ServerPlayer player, boolean whisper) {
        MinecraftServer server = levelOf(player).getServer();
        LazurConfig cfg = LazurConfig.get();
        double radius = whisper ? cfg.hearWhisper : cfg.hearVoice;
        server.execute(() -> {
            if (player.isAlive()) onNoise(levelOf(player), player.position(), radius);
        });
    }

    // =====================================================================================
    // debug (used by /lazur ...)
    // =====================================================================================
    public static String status(MinecraftServer server) {
        LazurData d = LazurData.get(server);
        StringBuilder sb = new StringBuilder();
        sb.append("role=").append(d.role).append(" silCd=").append(d.silCd / 20).append("s subCd=").append(d.subCd / 20)
                .append("s farTicks=").append(d.farTicks).append(" chaseLeft=").append(d.chaseTicks / 20).append("s");
        if (d.sub != null) {
            Sub s = d.sub;
            sb.append(" | sub type=").append(s.type).append(" at ").append(s.x).append(' ').append(s.y).append(' ').append(s.z)
                    .append(" abandon=").append(s.abandon / 20).append("s reveal=").append(s.reveal < 0 ? "-" : (s.reveal / 20) + "s")
                    .append(" gaze=").append(s.gaze);
        }
        long left = d.ambNext - LazurTime.gameTimeOf(server);
        sb.append(" | ambient in ").append(left <= 0 ? 0 : left / 24000).append(" days");
        sb.append(" | returns=").append(d.returns.size()).append(" | clock=").append(LazurTime.describe());
        return sb.toString();
    }

    public static boolean debugSilhouette(ServerPlayer p) {
        MinecraftServer server = levelOf(p).getServer();
        LazurData d = LazurData.get(server);
        if (d.role != ROLE_NONE) return false;
        return spawnSilhouette(server, d, p, levelOf(p), levelOf(p).getRandom(), LazurConfig.get(), true);
    }

    public static boolean debugSubstitute(ServerPlayer p) {
        MinecraftServer server = levelOf(p).getServer();
        LazurData d = LazurData.get(server);
        if (d.role != ROLE_NONE || d.sub != null) return false;
        return trySubstitute(server, d, p, levelOf(p), levelOf(p).getRandom(), LazurConfig.get(), true);
    }

    public static boolean debugReveal(ServerPlayer p) {
        LazurData d = LazurData.get(levelOf(p).getServer());
        if (d.sub == null) return false;
        d.sub.force = true;
        d.setDirty();
        return true;
    }

    public static boolean debugChase(ServerPlayer p) {
        ServerLevel level = levelOf(p);
        LazurData d = LazurData.get(level.getServer());
        if (d.role != ROLE_NONE) return false;
        Vec3 look = p.getLookAngle();
        Vec3 base = new Vec3(p.getX() + look.x * 14, p.getY(), p.getZ() + look.z * 14);
        float yaw = (float) Math.toDegrees(Math.atan2(look.x, -look.z));
        LazurEntity lz = spawn(level, base, yaw, LazurEntity.A_FIGURE, LazurEntity.S_RUN);
        placeFree(level, lz, base);
        beginChase(d, level, lz, LazurConfig.get());
        return true;
    }

    public static boolean debugAnim(ServerPlayer p, String name) {
        ServerLevel level = levelOf(p);
        LazurData d = LazurData.get(level.getServer());
        if (d.role != ROLE_NONE) return false;
        int state = switch (name) {
            case "walk" -> LazurEntity.S_WALK;
            case "creep" -> LazurEntity.S_CREEP;
            case "run" -> LazurEntity.S_RUN;
            case "attack" -> LazurEntity.S_ATTACK;
            case "glitch" -> LazurEntity.S_GLITCH;
            case "fade" -> LazurEntity.S_FADE;
            default -> LazurEntity.S_IDLE;
        };
        int look = name.equals("skin") ? LazurEntity.A_SKIN : LazurEntity.A_FIGURE;
        Vec3 dir = p.getLookAngle();
        Vec3 base = new Vec3(p.getX() + dir.x * 6, p.getY(), p.getZ() + dir.z * 6);
        float yaw = (float) Math.toDegrees(Math.atan2(dir.x, -dir.z));
        LazurEntity lz = spawn(level, base, yaw, look, state);
        d.role = ROLE_TEST;
        d.lazurId = lz.getUUID();
        d.setDirty();
        return true;
    }

    public static void debugClear(MinecraftServer server) {
        LazurData d = LazurData.get(server);
        for (ServerLevel lv : server.getAllLevels()) {
            for (var e : lv.getAllEntities()) {
                if (e instanceof LazurEntity) e.discard();
            }
        }
        d.role = ROLE_NONE;
        d.lazurId = null;
        d.fading = false;
        d.setDirty();
    }
}
