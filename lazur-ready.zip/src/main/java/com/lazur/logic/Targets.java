package com.lazur.logic;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.Set;

public final class Targets {
    /** Functional blocks Lazur may pretend to be. Buttons, doors and levers are intentionally absent. Beds are handled separately. */
    private static final Set<Block> FUNCTIONAL = Set.of(
            Blocks.CRAFTING_TABLE, Blocks.FURNACE, Blocks.BLAST_FURNACE, Blocks.SMOKER,
            Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.BARREL,
            Blocks.SMITHING_TABLE, Blocks.ANVIL, Blocks.CHIPPED_ANVIL, Blocks.DAMAGED_ANVIL,
            Blocks.GRINDSTONE, Blocks.LOOM, Blocks.STONECUTTER, Blocks.CARTOGRAPHY_TABLE,
            Blocks.FLETCHING_TABLE, Blocks.ENCHANTING_TABLE, Blocks.BREWING_STAND,
            Blocks.LECTERN, Blocks.JUKEBOX, Blocks.ENDER_CHEST);

    public static boolean isFunctional(BlockState state) {
        return FUNCTIONAL.contains(state.getBlock());
    }

    /** What Lazur breaks while chasing: leaves, glass, panes, doors, gates, trapdoors. */
    public static boolean lazurCanBreak(BlockState s) {
        if (s.isAir()) return false;
        if (s.is(BlockTags.LEAVES) || s.is(BlockTags.DOORS) || s.is(BlockTags.FENCE_GATES)
                || s.is(BlockTags.TRAPDOORS) || s.is(BlockTags.IMPERMEABLE)) {
            return true;
        }
        String path = BuiltInRegistries.BLOCK.getKey(s.getBlock()).getPath();
        return path.endsWith("glass") || path.endsWith("glass_pane");
    }

    private Targets() {}
}
