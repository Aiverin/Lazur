package com.lazur.logic;

import com.lazur.state.LazurData;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Clearable;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * The ONLY place that touches block-entity (de)serialisation. If the API moved in 26.2,
 * fix just these two methods.
 */
public final class BlockSnapshot {

    /** Remembers block + contents and empties the container so nothing drops when the block is removed. */
    public static LazurData.Ret capture(ServerLevel level, BlockPos pos) {
        LazurData.Ret r = new LazurData.Ret();
        r.x = pos.getX(); r.y = pos.getY(); r.z = pos.getZ();
        BlockState state = level.getBlockState(pos);
        r.state = NbtUtils.writeBlockState(state);
        BlockEntity be = level.getBlockEntity(pos);
        if (be != null) {
            r.be = be.saveWithFullMetadata(level.registryAccess());
            if (be instanceof Clearable c) c.clearContent();
        }
        return r;
    }

    public static boolean restore(ServerLevel level, LazurData.Ret r) {
        BlockPos pos = r.pos();
        BlockState state = NbtUtils.readBlockState(BuiltInRegistries.BLOCK, r.state);
        if (!level.setBlock(pos, state, 3)) return false;
        if (r.be != null) {
            BlockEntity loaded = BlockEntity.loadStatic(pos, state, r.be, level.registryAccess());
            if (loaded != null) level.setBlockEntity(loaded);
        }
        return true;
    }

    private BlockSnapshot() {}
}
