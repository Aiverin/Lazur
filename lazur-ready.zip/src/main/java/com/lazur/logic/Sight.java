package com.lazur.logic;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** "Is the player looking at it" checks: view angle + ray from the eyes. */
public final class Sight {

    /** cos = cosine of the half-angle of the view cone (0.97 is about 14 degrees, 0.5 is 60 degrees). */
    public static boolean inView(ServerPlayer p, Vec3 target, double cos) {
        Vec3 to = target.subtract(p.getEyePosition());
        double len = to.length();
        if (len < 1.0E-4) return true;
        return p.getLookAngle().dot(to.scale(1.0 / len)) >= cos;
    }

    /** True if nothing solid is between the two points (a block at {@code ignore} does not count). */
    public static boolean pointVisible(ServerLevel level, Entity viewer, Vec3 from, Vec3 to, BlockPos ignore) {
        BlockHitResult hit = level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, viewer));
        if (hit.getType() == HitResult.Type.MISS) return true;
        return ignore != null && hit.getBlockPos().equals(ignore);
    }

    /** How many of 3 body points (feet, middle, head) of the entity the player can see. */
    public static int visibleSamples(ServerLevel level, ServerPlayer p, Entity e) {
        Vec3 eye = p.getEyePosition();
        double h = e.getBbHeight();
        int n = 0;
        for (double f : new double[]{0.1, 0.5, 0.95}) {
            if (pointVisible(level, p, eye, e.position().add(0, h * f, 0), null)) n++;
        }
        return n;
    }

    private Sight() {}
}
