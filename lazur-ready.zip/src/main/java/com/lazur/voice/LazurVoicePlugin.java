package com.lazur.voice;

import com.lazur.logic.LazurManager;
import de.maxhenkel.voicechat.api.VoicechatConnection;
import de.maxhenkel.voicechat.api.VoicechatPlugin;
import de.maxhenkel.voicechat.api.events.EventRegistration;
import de.maxhenkel.voicechat.api.events.MicrophonePacketEvent;
import de.maxhenkel.voicechat.api.packets.MicrophonePacket;

/**
 * Loaded ONLY by Simple Voice Chat (entrypoint "voicechat"). Without voice chat installed this class is never touched.
 * Every microphone packet that carries sound makes Lazur "hear" the player, like a Warden hears vibrations.
 */
public class LazurVoicePlugin implements VoicechatPlugin {
    @Override
    public String getPluginId() {
        return "lazur";
    }

    @Override
    public void registerEvents(EventRegistration registration) {
        registration.registerEvent(MicrophonePacketEvent.class, this::onMicrophone);
    }

    private void onMicrophone(MicrophonePacketEvent event) {
        VoicechatConnection connection = event.getSenderConnection();
        if (connection == null || connection.getPlayer() == null) return;
        MicrophonePacket packet = event.getPacket();
        byte[] data = packet.getOpusEncodedData();
        if (data == null || data.length == 0) return; // silence
        Object player = connection.getPlayer().getPlayer();
        if (player instanceof net.minecraft.server.level.ServerPlayer sp) {
            LazurManager.onVoice(sp, packet.isWhispering());
        }
    }
}
