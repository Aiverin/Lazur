package com.lazur;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** All values from section 9 of the concept doc. File: config/lazur.json (created on first start). */
public final class LazurConfig {
    // ---- silhouette (farRadiusBlocks / farTicksRequired are no longer used by it) ----
    public int farRadiusBlocks = 200;          // "far" = further than this from spawn/bed
    public int farTicksRequired = 18000;       // 15 min
    public int nearRadiusBlocks = 100;         // "near the base"
    // (the silhouette appears 2-4 chunks from the player, 32-64 blocks: fixed in LazurManager, not in this file)
    public int silhouetteApproachBlocks = 28;  // the silhouette glitches away when the player gets this close
    public int silhouetteCdMin = 24000;        // 1 day
    public int silhouetteCdMax = 144000;       // 6 days (the stage table of the doc: every 1-6 days)
    public int silhouetteGiveUpTicks = 6000;   // silhouette vanishes if never noticed
    public int glitchMinTicks = 20;            // 1 s
    public int glitchMaxTicks = 40;            // 2 s

    // ---- cave: Lazur in the shape of a player ----
    public int caveMinTicks = 12000;           // underground for this long (10 min) at the earliest...
    public int caveMaxTicks = 72000;           // ...and 60 min at the latest (rolled each time) before he shows up
    public int caveGiveUpTicks = 2400;         // nobody noticed him for 2 min: he looks for another place
    // (looking at his head for 3 s starts the head turn + camera lock; that time is fixed in LazurManager.CAVE_LOOK_TICKS)
    public double playerFormSpeedBps = 7.5;    // black player (sprint of the player 5.6)

    // ---- substitution ----
    public int subCdMin = 48000;               // 2 days
    public int subCdMax = 144000;              // 6 days
    public int revealMin = 12000;              // 0.5 day
    public int revealMax = 72000;              // 3 days
    public double attackRadius = 5.0;          // block: attack only if player is this close
    public int abandonMin = 24000;             // 1 day
    public int abandonMax = 48000;             // 2 days
    // (an imitated animal is any animal within 12 blocks; left after 10 minutes: LazurManager.CREATURE_ABANDON_TICKS)
    public int creatureGazeTicks = 100;        // 5 s of looking at the imitated animal reveals Lazur
    public double creatureGazeRange = 40.0;    // how far away the look still counts
    public double creatureGazeCone = 0.96;     // cosine of the half-angle of "looking at it" (about 16 degrees)
    public double creatureNearRadius = 12.0;   // standing this close to it also reveals Lazur...
    public int creatureNearMinTicks = 100;     // ...after a random time between 5 s
    public int creatureNearMaxTicks = 600;     // ...and 30 s (rolled once per imitated animal)
    public double bedChance = 0.01;            // 1 %
    public double creatureChance = 0.35;       // chance to pick a creature instead of a block
    public int searchRadius = 32;
    public int searchVertical = 12;

    // ---- chase ----
    public int chaseTicks = 12000;             // 10 min (tall form); the cave form: 1-4 min, rolled in LazurManager
    public double lazurSpeed = 0.30;           // start value of the speed attribute, it is auto-tuned in a chase
    public double chaseSpeedBps = 5.6;         // wanted real speed in blocks/s (the player sprints at 5.6)
    public float damage = 7.0f;                // 3.5 hearts
    public double attackReach = 3.0;
    public int revealAttackDelayTicks = 0;     // 0 = he strikes at once after being revealed; raise it to give a pause

    // ---- grab: a line of W/A/S/D keys to press in order, against an "air" gauge ----
    public int grabBaseKeys = 5;               // keys in the first grab: 5, 8, 11, 14, 17
    public int grabKeysStep = 3;
    public int grabMaxKeys = 17;
    public int grabTimeStartSec = 15;          // time for the first grab: 15, 13, 11, 9 s, never less than 7
    public int grabTimeStepSec = 2;
    public int grabTimeMinSec = 7;
    public int grabMaxErrors = 2;              // the 2nd wrong key kills
    public int grabIntroTicks = 24;            // 1.2 s: Lazur lifts the player, no keys yet
    public double grabHoldDistance = 1.35;     // how far in front of Lazur the player is held (blocks)

    // ---- losing the player / listening (Warden-like, without sculk) ----
    public int loseSightTicks = 40;            // 2 s without seeing the player, then he starts sneaking and listening
    public double sightRange = 32.0;           // further than this he does not see the player either
    public double creepSpeedBps = 2.3;         // sneaking speed in blocks/s
    public double hearWalk = 12.0;             // hearing radius, blocks (sound goes through walls)
    public double hearSprint = 24.0;
    public double hearJump = 16.0;             // jump / landing
    public double hearBlock = 20.0;            // breaking a block
    public double hearVoice = 24.0;            // voice chat (Simple Voice Chat)
    public double hearWhisper = 8.0;           // whispering in voice chat

    private static LazurConfig instance = new LazurConfig();

    public static LazurConfig get() {
        return instance;
    }

    /**
     * The values above are the truth: an old lazur.json must never override them (that caused stale numbers before).
     * The file is only (re)written so you can read the current values.
     */
    public static void load() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        Path path = FabricLoader.getInstance().getConfigDir().resolve("lazur.json");
        try {
            Files.writeString(path, gson.toJson(instance));
        } catch (IOException | RuntimeException e) {
            LazurMod.LOGGER.warn("Could not write lazur.json", e);
        }
    }
}
