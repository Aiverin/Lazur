package com.lazur;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** All values from section 9 of the concept doc. File: config/lazur.json (created on first start). */
public final class LazurConfig {
    // ---- far silhouette ----
    public int farRadiusBlocks = 200;          // "far" = further than this from spawn/bed
    public int farTicksRequired = 18000;       // 15 min
    public int nearRadiusBlocks = 100;         // "near the base"
    public int silhouetteMinChunks = 5;        // appears 5-6 chunks from the player (80-96 blocks)
    public int silhouetteMaxChunks = 6;
    public int silhouetteApproachBlocks = 28;  // the silhouette glitches away when the player gets this close
    public int silhouetteCdMin = 24000;        // 1 day
    public int silhouetteCdMax = 216000;       // 9 days
    public int silhouetteGiveUpTicks = 6000;   // silhouette vanishes if never noticed
    public int glitchMinTicks = 20;            // 1 s
    public int glitchMaxTicks = 40;            // 2 s

    // ---- cave: Lazur in the shape of a player ----
    public int caveMinTicks = 12000;           // underground for this long (10 min) at the earliest...
    public int caveMaxTicks = 48000;           // ...and 40 min at the latest (rolled each time) before he shows up
    public int caveGiveUpTicks = 6000;         // vanishes if nobody noticed him for 5 min
    public int caveGazeTicks = 160;            // 8 s of looking and he turns black and attacks
    public int caveShakeStartTicks = 30;       // the camera starts to shake / get pulled after this much looking
    public double caveAggroBlocks = 4.0;       // or if the player walks this close to him (he now appears 4-10 blocks away)
    public double playerFormSpeedBps = 9.5;    // black player: much faster than the player (sprint 5.6, sprint-jump ~7)

    // ---- substitution ----
    public int subCdMin = 96000;               // 4 days
    public int subCdMax = 288000;              // 12 days
    public int revealMin = 12000;              // 0.5 day
    public int revealMax = 72000;              // 3 days
    public double attackRadius = 5.0;          // block: attack only if player is this close
    public int abandonMin = 24000;             // 1 day
    public int abandonMax = 48000;             // 2 days
    public int creatureAbandonTicks = 48000;   // 40 min: an imitated animal that nobody noticed is left for something else
    public int creatureGazeTicks = 200;        // 10 s of looking at the imitated animal reveals Lazur
    public double creatureGazeRange = 40.0;    // how far away the look still counts
    public double creatureGazeCone = 0.96;     // cosine of the half-angle of "looking at it" (about 16 degrees)
    public double creatureNearRadius = 12.0;   // standing this close to it also reveals Lazur...
    public int creatureNearMinTicks = 100;     // ...after a random time between 5 s
    public int creatureNearMaxTicks = 1200;    // ...and 60 s (rolled once per imitated animal)
    public double bedChance = 0.01;            // 1 %
    public double creatureChance = 0.35;       // chance to pick a creature instead of a block
    public int searchRadius = 32;
    public int searchVertical = 12;

    // ---- chase ----
    public int chaseTicks = 18000;             // 15 min
    public double lazurSpeed = 0.30;           // start value of the speed attribute, it is auto-tuned in a chase
    public double chaseSpeedBps = 6.0;         // wanted real speed in blocks/s (player sprint 5.6, sprint-jump ~7)
    public float damage = 7.0f;                // 3.5 hearts
    public double attackReach = 3.0;
    public int revealAttackDelayTicks = 0;     // 0 = he strikes at once after being revealed; raise it to give a pause

    // ---- grab (replaces the damage hit) ----
    public int grabBaseHits = 7;               // hits in timing needed to break free the first time
    public int grabHitsStep = 3;               // every next grab needs this many more (7, 10, 13, ...) until the player dies
    public int grabMaxErrors = 2;              // the 2nd mistake kills
    public int grabIntroTicks = 24;            // Lazur lifts the player, no prompts yet
    public int grabPromptMinTicks = 14;        // length of the shrinking ring (random between min and max)
    public int grabPromptMaxTicks = 28;
    public int grabGapMinTicks = 7;            // pause between prompts (random)
    public int grabGapMaxTicks = 15;
    public double grabBarStart = 0.30;         // the bottom gauge: start value (0..1)
    public double grabBarFillPerSecond = 0.07; // it keeps filling by itself
    public double grabBarHitRelief = 0.16;     // a hit in timing pushes it back
    public double grabBarErrorPenalty = 0.30;  // a mistake fills it
    public int grabReleaseHeadStartTicks = 30; // 1.5 s: Lazur stands still after letting go
    public double grabHoldDistance = 1.35;     // how far in front of Lazur the player is held (blocks)

    // ---- losing the player / listening (Warden-like, without sculk) ----
    public int loseSightTicks = 80;            // 4 s behind full blocks, then he starts sneaking and listening
    public double sightRange = 64.0;
    public double creepSpeedBps = 1.4;         // sneaking speed in blocks/s
    public double hearWalk = 12.0;             // hearing radius, blocks (sound goes through walls)
    public double hearSprint = 24.0;
    public double hearJump = 16.0;             // jump / landing
    public double hearBlock = 20.0;            // breaking a block
    public double hearVoice = 24.0;            // voice chat (Simple Voice Chat)
    public double hearWhisper = 8.0;           // whispering in voice chat

    private static LazurConfig instance = new LazurConfig();

    public static LazurConfig get() {
        return instance;
    }

    public static void load() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        Path path = FabricLoader.getInstance().getConfigDir().resolve("lazur.json");
        try {
            if (Files.exists(path)) {
                LazurConfig loaded = gson.fromJson(Files.readString(path), LazurConfig.class);
                if (loaded != null) instance = loaded;
            }
            Files.writeString(path, gson.toJson(instance)); // rewrite so new fields appear
        } catch (IOException | RuntimeException e) {
            LazurMod.LOGGER.warn("Could not read/write lazur.json, using defaults", e);
        }
    }
}
