package com.lazur;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** All values from section 9 of the concept doc. File: config/lazur.json (created on first start). */
public final class LazurConfig {
    // ---- far silhouette ----
    public int farRadiusBlocks = 200;          // "far" = further than this from spawn/bed
    public int farTicksRequired = 18000;       // 15 min
    public int nearRadiusBlocks = 100;         // "near the base"
    public int silhouetteMinChunks = 8;
    public int silhouetteMaxChunks = 10;
    public int silhouetteCdMin = 24000;        // 1 day
    public int silhouetteCdMax = 216000;       // 9 days
    public int silhouetteGiveUpTicks = 6000;   // silhouette vanishes if never noticed
    public int glitchMinTicks = 20;            // 1 s
    public int glitchMaxTicks = 40;            // 2 s

    // ---- substitution ----
    public int subCdMin = 96000;               // 4 days
    public int subCdMax = 288000;              // 12 days
    public int revealMin = 12000;              // 0.5 day
    public int revealMax = 72000;              // 3 days
    public double attackRadius = 5.0;          // block: attack only if player is this close
    public int abandonMin = 24000;             // 1 day
    public int abandonMax = 48000;             // 2 days
    public double creatureRevealRadius = 3.0;
    public int creatureGazeTicks = 200;        // ~10 s
    public double bedChance = 0.01;            // 1 %
    public double creatureChance = 0.35;       // chance to pick a creature instead of a block
    public int searchRadius = 32;
    public int searchVertical = 12;

    // ---- chase ----
    public int chaseTicks = 18000;             // 15 min
    public double lazurSpeed = 0.14;           // player sprint is ~0.13, sprint-jump is faster than this
    public float damage = 7.0f;                // 3.5 hearts
    public double attackReach = 3.0;

    private static LazurConfig instance = new LazurConfig();

    public static LazurConfig get() {
        return instance;
    }

    public static void load() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        Path path = FabricLoader.getInstance().getConfigDir().resolve("lazur.json");
        try {
            if (Files.exists(path)) {
                LazurConfig loaded = gson.fromJson(Files.readString(path), LazurConfig.class);
                if (loaded != null) instance = loaded;
            }
            Files.writeString(path, gson.toJson(instance)); // rewrite so new fields appear
        } catch (IOException | RuntimeException e) {
            LazurMod.LOGGER.warn("Could not read/write lazur.json, using defaults", e);
        }
    }
}
