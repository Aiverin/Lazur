package com.lazur.entity;

import com.lazur.LazurConfig;
import com.lazur.logic.LazurManager;
import com.lazur.logic.Targets;
import net.minecraft.core.BlockPos;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Lazur. The server-side manager (LazurManager) drives the logic; this class only knows
 * how to look (synced STATE / APPEARANCE) and how to chase + hit when told to.
 */
public class LazurEntity extends PathfinderMob {
    // animation / behaviour state (synced, matches the HTML prototype)
    public static final int S_IDLE = 0, S_WALK = 1, S_CREEP = 2, S_RUN = 3, S_ATTACK = 4, S_GLITCH = 5, S_FADE = 6;
    // look
    public static final int A_SKIN = 0, A_FIGURE = 1;

    public static final int ATTACK_TOTAL = 24; // 1.2 s
    public static final int ATTACK_HIT = 16;   // strike peak (c = 0.66 of the cycle)

    private static final EntityDataAccessor<Integer> DATA_STATE =
            SynchedEntityData.defineId(LazurEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_APPEARANCE =
            SynchedEntityData.defineId(LazurEntity.class, EntityDataSerializers.INT);

    private int attackTick = -1;
    private int attackCooldown = 20;

    public LazurEntity(EntityType<? extends LazurEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createLazurAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 100)
                .add(Attributes.MOVEMENT_SPEED, LazurConfig.get().lazurSpeed)
                .add(Attributes.FOLLOW_RANGE, 96)
                .add(Attributes.STEP_HEIGHT, 1.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_STATE, S_IDLE);
        builder.define(DATA_APPEARANCE, A_SKIN);
    }

    public int getLazurState() { return this.entityData.get(DATA_STATE); }
    public void setLazurState(int state) { this.entityData.set(DATA_STATE, state); }
    public int getAppearance() { return this.entityData.get(DATA_APPEARANCE); }
    public void setAppearance(int appearance) { this.entityData.set(DATA_APPEARANCE, appearance); }

    // ---- misc behaviour ----
    @Override public boolean isInvulnerable() { return true; }      // /kill still works (bypasses invulnerability)
    @Override public boolean isPushable() { return false; }
    @Override public boolean removeWhenFarAway(double distanceSq) { return false; }

    /** Needed so the far silhouette (8-10 chunks) is actually rendered. */
    @Override
    public boolean shouldRenderAtSqrDistance(double distanceSq) { return true; }

    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
        if (source.is(DamageTypes.GENERIC_KILL)) return super.hurtServer(level, source, amount);
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide() && this.tickCount > 40 && this.tickCount % 20 == 0) {
            if (!LazurManager.owns(this)) this.discard(); // orphan (world reloaded etc.)
        }
    }

    // ---- chase (server only) ----
    public void resetAttack() {
        attackTick = -1;
        attackCooldown = 20;
    }

    /** Called by the manager every tick while chasing. */
    public void chaseTick(ServerPlayer target) {
        ServerLevel sl = (ServerLevel) this.level();
        LazurConfig cfg = LazurConfig.get();

        if (attackTick >= 0) {
            this.getNavigation().stop();
            this.getLookControl().setLookAt(target, 30.0F, 30.0F);
            setLazurState(S_ATTACK);
            attackTick++;
            if (attackTick == ATTACK_HIT) {
                if (this.distanceTo(target) <= cfg.attackReach + 1.0) {
                    target.hurtServer(sl, this.damageSources().mobAttack(this), cfg.damage);
                }
            }
            if (attackTick >= ATTACK_TOTAL) {
                attackTick = -1;
                attackCooldown = 12;
            }
            return;
        }
        if (attackCooldown > 0) attackCooldown--;

        double distSq = this.distanceToSqr(target);
        if (distSq <= cfg.attackReach * cfg.attackReach && attackCooldown == 0 && this.hasLineOfSight(target)) {
            attackTick = 0;
            setLazurState(S_ATTACK);
            sl.playSound(null, getX(), getY(), getZ(), SoundEvents.RAVAGER_ROAR, SoundSource.HOSTILE, 3.0F, 0.6F);
            return;
        }

        setLazurState(S_RUN);
        this.getLookControl().setLookAt(target, 30.0F, 30.0F);
        if (this.tickCount % 10 == 0 || this.getNavigation().isDone()) {
            this.getNavigation().moveTo(target, 1.0);
        }
        if (this.getNavigation().isDone()) {
            // no path (glass, leaves, closed doors...): walk straight at the player and break what is in the way
            this.getMoveControl().setWantedPosition(target.getX(), target.getY(), target.getZ(), 1.0);
        }
        if (this.horizontalCollision) {
            this.getJumpControl().jump();
            breakAhead(sl, target);
        }
    }

    /** Lazur breaks leaves, glass, panes, doors, gates, trapdoors. Earth, stone, wood stay solid. */
    private void breakAhead(ServerLevel sl, ServerPlayer target) {
        Vec3 dir = new Vec3(target.getX() - getX(), 0, target.getZ() - getZ());
        if (dir.lengthSqr() < 1.0E-4) return;
        dir = dir.normalize();
        for (int dy = 0; dy < 3; dy++) {
            BlockPos p = BlockPos.containing(getX() + dir.x * 0.9, getY() + dy, getZ() + dir.z * 0.9);
            BlockState bs = sl.getBlockState(p);
            if (Targets.lazurCanBreak(bs)) {
                sl.destroyBlock(p, false);
            }
        }
    }
}
