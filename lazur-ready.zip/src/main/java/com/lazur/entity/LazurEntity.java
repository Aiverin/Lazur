package com.lazur.entity;

import com.lazur.LazurConfig;
import com.lazur.logic.LazurGrab;
import com.lazur.logic.LazurManager;
import com.lazur.state.LazurData;
import com.lazur.logic.Targets;
import com.lazur.registry.ModEntities;
import com.lazur.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Lazur. The server-side manager (LazurManager) drives the lifecycle; the chase brain lives here.
 *
 * Chase brain:
 *  - RUN: always runs at the player (about 6 blocks/s, a bit faster than a sprinting player).
 *  - If the player stays hidden behind full blocks (not leaves / glass / etc.) for 4 s, Lazur switches to
 *    SEARCH: sneaks (CREEP) toward the last sound it heard and stands listening (LISTEN) when there is nothing to follow.
 *    It hears footsteps, jumps/landings, broken blocks and (with Simple Voice Chat) the microphone, through walls.
 *    Sneaking (shift) is silent. Seeing the player again puts it back to RUN.
 *  - The strike does not stop him: he keeps running while the arm swings. If it lands, he grabs the player (LazurGrab).
 */
public class LazurEntity extends PathfinderMob {
    public static final int S_IDLE = 0, S_WALK = 1, S_CREEP = 2, S_RUN = 3, S_ATTACK = 4, S_GLITCH = 5, S_FADE = 6, S_LISTEN = 7,
            S_GRAB = 8;
    public static final int A_SKIN = 0, A_FIGURE = 1, A_BLACK_PLAYER = 2;

    public static final int ATTACK_TOTAL = 24; // 1.2 s
    public static final int ATTACK_HIT = 16;   // strike peak

    private static final EntityDataAccessor<Integer> DATA_STATE =
            SynchedEntityData.defineId(LazurEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_APPEARANCE =
            SynchedEntityData.defineId(LazurEntity.class, EntityDataSerializers.INT);

    // attack
    private int attackTick = -1;
    private int attackCooldown = 20;

    // brain
    private boolean sees = true;
    private boolean searching;
    private int lostTicks;
    private Vec3 heard;
    private double pLastX, pLastZ;
    private boolean pLastGround = true, pInit;

    // speed tuning (mob speed attributes do not map to blocks/s like the player's)
    private double runAttr = LazurConfig.get().lazurSpeed;
    private double creepAttr = LazurConfig.get().lazurSpeed * 0.25;
    private boolean creepMode, speedInit;
    private double calX, calZ;
    private int calTicks;

    public LazurEntity(EntityType<? extends LazurEntity> type, Level level) {
        super(type, level);
        if (type == ModEntities.LAZUR_PLAYER) runAttr *= 1.6; // the player-sized form starts out faster
    }

    /** The cave form: player hitbox, player model, strikes instead of grabbing. */
    public boolean isPlayerSized() { return this.getType() == ModEntities.LAZUR_PLAYER; }

    private int attackHitTick() { return isPlayerSized() ? 6 : ATTACK_HIT; }
    private int attackTotalTicks() { return isPlayerSized() ? 10 : ATTACK_TOTAL; }

    public static AttributeSupplier.Builder createLazurAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 100)
                .add(Attributes.MOVEMENT_SPEED, LazurConfig.get().lazurSpeed)
                .add(Attributes.FOLLOW_RANGE, 96)
                .add(Attributes.STEP_HEIGHT, 1.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_STATE, S_IDLE);
        builder.define(DATA_APPEARANCE, A_SKIN);
    }

    public int getLazurState() { return this.entityData.get(DATA_STATE); }
    public void setLazurState(int state) { this.entityData.set(DATA_STATE, state); }
    public int getAppearance() { return this.entityData.get(DATA_APPEARANCE); }
    public void setAppearance(int appearance) { this.entityData.set(DATA_APPEARANCE, appearance); }

    // ---- misc behaviour ----
    @Override public boolean isInvulnerable() { return true; }      // /kill still works (bypasses invulnerability)
    @Override public boolean isPushable() { return false; }
    @Override public boolean removeWhenFarAway(double distanceSq) { return false; }

    /** Needed so the far silhouette (8-10 chunks) is actually rendered. */
    @Override
    public boolean shouldRenderAtSqrDistance(double distanceSq) { return true; }

    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
        if (source.is(DamageTypes.GENERIC_KILL)) return super.hurtServer(level, source, amount);
        return false;
    }

    /**
     * Footsteps: one clip per stride (the engine already triggers a step per ~1.7 blocks walked, which matches the
     * animation, so steps come faster the faster he moves). On top of that running is louder and higher/faster,
     * sneaking is quiet and low/slow.
     */
    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        int st = getLazurState();
        float vol, pitch;
        if (st == S_RUN) { vol = 1.5F; pitch = 1.3F; }
        else if (st == S_CREEP) { vol = 0.5F; pitch = 0.8F; }
        else { vol = 0.9F; pitch = 1.0F; }
        pitch += (this.random.nextFloat() - 0.5F) * 0.1F;
        this.playSound(ModSounds.LAZUR_STEP, vol, pitch);
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide() && this.tickCount > 40 && this.tickCount % 20 == 0) {
            if (!LazurManager.owns(this)) this.discard(); // orphan (world reloaded etc.)
        }
    }

    // =====================================================================================
    // hearing
    // =====================================================================================
    /** A sound at {@code pos} that can be heard within {@code radius} blocks (walls do not block it). */
    public void hearSound(Vec3 pos, double radius) {
        if (this.position().distanceToSqr(pos) <= radius * radius) {
            this.heard = pos;
        }
    }

    /** Derives footstep noise from how the player moves. Shift (sneaking) is silent. */
    private void listen(ServerPlayer p, LazurConfig cfg) {
        if (!pInit) {
            pLastX = p.getX(); pLastZ = p.getZ(); pLastGround = p.onGround(); pInit = true;
            return;
        }
        double mv = Math.hypot(p.getX() - pLastX, p.getZ() - pLastZ); // blocks per tick
        boolean ground = p.onGround();
        double radius = 0;
        if (!p.isShiftKeyDown()) {
            if (ground && mv > 0.2) radius = cfg.hearSprint;
            else if (ground && mv > 0.05) radius = cfg.hearWalk;
            if (!pLastGround && ground) radius = Math.max(radius, cfg.hearJump); // landing
        }
        pLastX = p.getX(); pLastZ = p.getZ(); pLastGround = ground;
        if (radius > 0) hearSound(p.position(), radius);
    }

    // =====================================================================================
    // sight: full blocks block it, leaves / glass / fences / doors etc. do not
    // =====================================================================================
    private boolean canSee(ServerLevel sl, ServerPlayer p, LazurConfig cfg) {
        if (this.distanceToSqr(p) > cfg.sightRange * cfg.sightRange) return false;
        Vec3 from = this.getEyePosition();
        return rayClear(sl, from, p.getEyePosition()) || rayClear(sl, from, p.position().add(0, 0.4, 0));
    }

    private static boolean rayClear(ServerLevel sl, Vec3 a, Vec3 b) {
        Vec3 d = b.subtract(a);
        int n = Math.max(1, (int) (d.length() / 0.4));
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int i = 1; i < n; i++) {
            double f = i / (double) n;
            m.set(Mth.floor(a.x + d.x * f), Mth.floor(a.y + d.y * f), Mth.floor(a.z + d.z * f));
            if (sl.getBlockState(m).canOcclude()) return false;
        }
        return true;
    }

    // =====================================================================================
    // chase brain (server only, called every tick by the manager)
    // =====================================================================================
    public void resetAttack() {
        attackTick = -1;
        attackCooldown = 20;
        sees = true;
        searching = false;
        lostTicks = 0;
        heard = null;
    }

    public void setAttackCooldown(int ticks) { attackCooldown = ticks; }

    public void chaseTick(ServerPlayer target) {
        ServerLevel sl = (ServerLevel) this.level();
        LazurConfig cfg = LazurConfig.get();

        listen(target, cfg);

        // ---- strike in progress: the animation plays while he KEEPS RUNNING at the player ----
        if (attackTick >= 0) {
            attackTick++;
            if (attackTick == attackHitTick() && this.distanceTo(target) <= cfg.attackReach + 1.0) {
                if (isPlayerSized()) {
                    // the black player simply hits
                    target.hurtServer(sl, this.damageSources().mobAttack(this), cfg.damage);
                } else {
                    LazurGrab.begin(LazurData.get(sl.getServer()), target, this); // it landed: pick the player up
                    return;
                }
            }
            if (attackTick >= attackTotalTicks()) {
                attackTick = -1;
                attackCooldown = isPlayerSized() ? 14 : 12;
            } else {
                setLazurState(S_ATTACK);
                runAtPlayer(sl, target, cfg);
                return;
            }
        }
        if (attackCooldown > 0) attackCooldown--;

        // ---- sight ----
        if (this.tickCount % 4 == 0) sees = canSee(sl, target, cfg);
        if (sees) {
            lostTicks = 0;
            if (searching) {            // found the player again
                searching = false;
                heard = null;
                sl.playSound(null, getX(), getY(), getZ(), SoundEvents.RAVAGER_ROAR, SoundSource.HOSTILE, 3.0F, 0.6F);
            }
        } else {
            lostTicks++;
            if (!searching && lostTicks >= cfg.loseSightTicks) {
                searching = true;       // 4 s without sight: sneak and listen
                this.getNavigation().stop();
            }
        }

        // ---- close and visible: hit ----
        double distSq = this.distanceToSqr(target);
        if (distSq <= cfg.attackReach * cfg.attackReach && attackCooldown == 0 && this.hasLineOfSight(target)) {
            attackTick = 0;
            setLazurState(S_ATTACK);
            sl.playSound(null, getX(), getY(), getZ(), SoundEvents.RAVAGER_ROAR, SoundSource.HOSTILE, 3.0F, 0.6F);
            runAtPlayer(sl, target, cfg); // no stop: the swing starts on the run
            return;
        }

        if (!searching) runAtPlayer(sl, target, cfg);
        else searchAndListen(sl, cfg);
    }

    private void runAtPlayer(ServerLevel sl, ServerPlayer target, LazurConfig cfg) {
        setSpeedMode(false);
        if (attackTick < 0) setLazurState(S_RUN); // while striking the state stays S_ATTACK
        calibrateSpeed(cfg);
        this.getLookControl().setLookAt(target, 30.0F, 30.0F);
        if (this.tickCount % 10 == 0 || this.getNavigation().isDone()) {
            this.getNavigation().moveTo(target, 1.0);
        }
        if (this.getNavigation().isDone()) {
            // no path (glass, leaves, closed doors...): walk straight at the player and break what is in the way
            this.getMoveControl().setWantedPosition(target.getX(), target.getY(), target.getZ(), 1.0);
        }
        if (this.horizontalCollision) {
            this.getJumpControl().jump();
            breakAhead(sl, target.position());
        }
    }

    private void searchAndListen(ServerLevel sl, LazurConfig cfg) {
        setSpeedMode(true);
        if (heard != null && this.position().distanceToSqr(heard) > 2.25) {
            setLazurState(S_CREEP);
            calibrateSpeed(cfg);
            this.getLookControl().setLookAt(heard.x, heard.y + 1.0, heard.z);
            if (this.tickCount % 10 == 0 || this.getNavigation().isDone()) {
                this.getNavigation().moveTo(heard.x, heard.y, heard.z, 1.0);
            }
            if (this.getNavigation().isDone()) {
                this.getMoveControl().setWantedPosition(heard.x, heard.y, heard.z, 1.0);
            }
            if (this.horizontalCollision) {
                this.getJumpControl().jump();
                breakAhead(sl, heard);
            }
        } else {
            // nothing to follow: stand still and listen
            this.getNavigation().stop();
            calTicks = 0;
            setLazurState(S_LISTEN);
        }
    }

    // =====================================================================================
    // speed tuning
    // =====================================================================================
    private void setSpeedMode(boolean creep) {
        if (speedInit && creep == creepMode) return;
        speedInit = true;
        creepMode = creep;
        calTicks = 0;
        AttributeInstance attr = this.getAttribute(Attributes.MOVEMENT_SPEED);
        if (attr != null) attr.setBaseValue(creep ? creepAttr : runAttr);
    }

    /**
     * Once a second the real speed is measured while walking along a path and the attribute is nudged
     * toward the wanted blocks/s (cfg.chaseSpeedBps for running, cfg.creepSpeedBps for sneaking).
     */
    private void calibrateSpeed(LazurConfig cfg) {
        if (calTicks == 0) { calX = getX(); calZ = getZ(); }
        if (++calTicks < 20) return;
        calTicks = 0;
        double moved = Math.hypot(getX() - calX, getZ() - calZ); // blocks in 20 ticks = blocks/s
        AttributeInstance attr = this.getAttribute(Attributes.MOVEMENT_SPEED);
        if (attr == null || this.getNavigation().isDone() || moved < 0.05) return; // blocked or standing: do not tune
        double want = creepMode ? cfg.creepSpeedBps : (isPlayerSized() ? cfg.playerFormSpeedBps : cfg.chaseSpeedBps);
        double factor = Mth.clamp(want / moved, 0.8, 1.25);
        double value = Mth.clamp(attr.getBaseValue() * factor, 0.02, 0.8);
        attr.setBaseValue(value);
        if (creepMode) creepAttr = value; else runAttr = value;
    }

    /** Lazur breaks leaves, glass, panes, doors, gates, trapdoors. Earth, stone, wood stay solid. */
    private void breakAhead(ServerLevel sl, Vec3 goal) {
        Vec3 dir = new Vec3(goal.x - getX(), 0, goal.z - getZ());
        if (dir.lengthSqr() < 1.0E-4) return;
        dir = dir.normalize();
        for (int dy = 0; dy < 3; dy++) {
            BlockPos p = BlockPos.containing(getX() + dir.x * 0.9, getY() + dy, getZ() + dir.z * 0.9);
            BlockState bs = sl.getBlockState(p);
            if (Targets.lazurCanBreak(bs)) {
                sl.destroyBlock(p, false);
            }
        }
    }
}
