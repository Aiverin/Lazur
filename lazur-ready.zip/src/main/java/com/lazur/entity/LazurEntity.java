package com.lazur.entity;

import com.lazur.LazurConfig;
import com.lazur.logic.LazurGrab;
import com.lazur.logic.LazurManager;
import com.lazur.state.LazurData;
import com.lazur.logic.Targets;
import com.lazur.registry.ModEntities;
import com.lazur.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Lazur. The server-side manager (LazurManager) drives the lifecycle; the chase brain lives here.
 *
 * Chase brain:
 *  - RUN: always runs at the player (5.6 blocks/s, like a sprinting player; the black player form 7.5).
 *  - If he does not see the player for 2 s (full blocks in the way, or further than 32 blocks), Lazur switches to
 *    SEARCH (like a Warden, but without sculk): he roams around the player sneaking (CREEP) and stops now and then
 *    to listen (LISTEN). He hears footsteps, jumps/landings, placed and broken blocks, eating, swinging the arm and
 *    (with Simple Voice Chat) the microphone, through walls and wool. One sound: he sneaks to where the sound
 *    was. More than one sound: he RUNS there at once. Sneaking (shift) makes no footstep noise.
 *    Seeing the player again puts it back to RUN.
 *  - The strike does not stop him: he keeps running while the arm swings. If it lands, he grabs the player (LazurGrab).
 */
public class LazurEntity extends PathfinderMob {
    public static final int S_IDLE = 0, S_WALK = 1, S_CREEP = 2, S_RUN = 3, S_ATTACK = 4, S_GLITCH = 5, S_FADE = 6, S_LISTEN = 7,
            S_GRAB = 8, S_SPIN = 9, S_SPIN_FULL = 10;   // S_SPIN: the cave form in a player's shape spins its head while being stared at; S_SPIN_FULL: the one full committed turn before he turns black
    public static final int A_SKIN = 0, A_FIGURE = 1, A_BLACK_PLAYER = 2;

    public static final int ATTACK_TOTAL = 24; // 1.2 s
    public static final int ATTACK_HIT = 16;   // strike peak

    private static final EntityDataAccessor<Integer> DATA_STATE =
            SynchedEntityData.defineId(LazurEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_APPEARANCE =
            SynchedEntityData.defineId(LazurEntity.class, EntityDataSerializers.INT);

    // attack
    private int attackTick = -1;
    private int attackCooldown = 20;

    // brain
    private boolean sees = true;
    private boolean searching;
    private int lostTicks;
    private Vec3 heard;
    private double pLastX, pLastZ;
    private boolean pLastGround = true, pInit, pLastSwing;
    // hearing / searching
    private int stepCd, eatCd;            // footsteps and eating make a noise every few ticks, not every tick
    private int noiseCount, noiseWindow;  // noises heard while searching; the count is forgotten after 15 s of quiet
    private Vec3 runTo;                   // more than 1 noise: he runs to the last one
    private int runTicks, pauseTicks;
    private Vec3 wanderGoal;
    private int wanderTicks;

    // wanted real speeds (blocks/s). The animator uses the same numbers to time the steps: sneaking 2.3, walking = the player's
    // walk 4.3, running = the player's sprint 5.6. The real speed is capped to exactly this in move().
    public static final double CREEP_BPS = 2.3, WALK_BPS = 4.3, RUN_BPS = 5.6;

    // speed: the attribute is only high enough, move() cuts the real horizontal speed to the wanted blocks/s
    private static final double CREEP_ATTR = 0.2, RUN_ATTR = 0.4;
    private boolean creepMode, speedInit;
    private int blockedTicks, tpCooldown;     // a wall he cannot pass with the player in sight: after 1 s he teleports
    private boolean teleportRequest;
    private int dissolveTicks;                 // > 0: he is dissolving (3 s), then he leaves a trail and is gone

    public LazurEntity(EntityType<? extends LazurEntity> type, Level level) {
        super(type, level);
    }

    /** The cave form: player hitbox, player model, strikes instead of grabbing. */
    public boolean isPlayerSized() { return this.getType() == ModEntities.LAZUR_PLAYER; }

    private int attackHitTick() { return isPlayerSized() ? 6 : ATTACK_HIT; }
    private int attackTotalTicks() { return isPlayerSized() ? 10 : ATTACK_TOTAL; }

    public static AttributeSupplier.Builder createLazurAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 100)
                .add(Attributes.MOVEMENT_SPEED, LazurConfig.get().lazurSpeed)
                .add(Attributes.FOLLOW_RANGE, 96)
                .add(Attributes.STEP_HEIGHT, 1.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_STATE, S_IDLE);
        builder.define(DATA_APPEARANCE, A_SKIN);
    }

    public int getLazurState() { return this.entityData.get(DATA_STATE); }
    public void setLazurState(int state) { this.entityData.set(DATA_STATE, state); }
    public int getAppearance() { return this.entityData.get(DATA_APPEARANCE); }
    public void setAppearance(int appearance) { this.entityData.set(DATA_APPEARANCE, appearance); }

    /** Wanted real speed (blocks/s) in the current mode. */
    private double wantBps() {
        if (creepMode) return CREEP_BPS;
        if (runTo != null && !isPlayerSized()) return 6.0; // running at a sound while searching (the doc: 6 blocks/s)
        return isPlayerSized() ? LazurConfig.get().playerFormSpeedBps : RUN_BPS;
    }

    @Override
    public void move(MoverType type, Vec3 delta) {
        if (type == MoverType.SELF && !this.level().isClientSide()) {
            double cap = wantBps() / 20.0;                 // blocks per tick
            double h = Math.hypot(delta.x, delta.z);
            if (h > cap && h > 1.0E-6) {
                double k = cap / h;
                delta = new Vec3(delta.x * k, delta.y, delta.z * k);
            }
        }
        super.move(type, delta);
    }

    /** The tall form wants to jump next to the player (a wall is in the way and he can see him). One request at a time. */
    public boolean takeTeleportRequest() {
        boolean r = teleportRequest;
        teleportRequest = false;
        return r;
    }

    /** 3 s of dissolving: he stands still, fades, then leaves a trail on the block and disappears. */
    public void beginDissolve() {
        if (dissolveTicks > 0) return;
        dissolveTicks = 60;
        this.setNoAi(true);
        this.getNavigation().stop();
        setLazurState(S_FADE);
    }

    // ---- misc behaviour ----
    @Override public boolean isInvulnerable() { return true; }      // /kill still works (bypasses invulnerability)
    @Override public boolean isPushable() { return false; }
    @Override public boolean removeWhenFarAway(double distanceSq) { return false; }

    /** Needed so the far silhouette (8-10 chunks) is actually rendered. */
    @Override
    public boolean shouldRenderAtSqrDistance(double distanceSq) { return true; }

    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
        if (source.is(DamageTypes.GENERIC_KILL)) return super.hurtServer(level, source, amount);
        return false;
    }

    /**
     * Footsteps: one clip per stride (the engine already triggers a step per ~1.7 blocks walked, which matches the
     * animation, so steps come faster the faster he moves). On top of that running is louder and higher/faster,
     * sneaking is quiet and low/slow.
     */
    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        int st = getLazurState();
        float vol, pitch;
        if (st == S_RUN) { vol = 1.5F; pitch = 1.3F; }
        else if (st == S_CREEP) { vol = 0.5F; pitch = 0.8F; }
        else { vol = 0.9F; pitch = 1.0F; }
        pitch += (this.random.nextFloat() - 0.5F) * 0.1F;
        this.playSound(ModSounds.LAZUR_STEP, vol, pitch);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) return;
        if (dissolveTicks > 0) {
            if (--dissolveTicks == 0) {
                LazurManager.addTrail((ServerLevel) this.level(), BlockPos.containing(getX(), getY() - 0.1, getZ()));
                this.discard();
            }
            return;
        }
        if (this.tickCount > 40 && this.tickCount % 20 == 0) {
            if (!LazurManager.owns(this)) this.discard(); // orphan (world reloaded etc.)
        }
    }

    // =====================================================================================
    // hearing
    // =====================================================================================
    /** A sound at {@code pos} that can be heard within {@code radius} blocks (walls do not block it). */
    public void hearSound(Vec3 pos, double radius) {
        if (this.position().distanceToSqr(pos) > radius * radius) return;
        this.heard = pos;
        if (!searching) return;
        noiseCount++;
        noiseWindow = 300;                    // the count is forgotten after 15 s of quiet
        if (noiseCount > 1 || runTo != null) { // a second noise: he stops sneaking and runs at the sound
            runTo = pos;
            runTicks = 120;
        }
    }

    /**
     * Derives noise from what the player does: steps (not when sneaking), jumps, landings, eating/drinking and
     * swinging the arm. Steps come once per stride, not every tick. Blocks and voice are reported from outside.
     */
    private void listen(ServerPlayer p, LazurConfig cfg) {
        if (!pInit) {
            pLastX = p.getX(); pLastZ = p.getZ(); pLastGround = p.onGround(); pLastSwing = p.swinging; pInit = true;
            return;
        }
        if (stepCd > 0) stepCd--;
        if (eatCd > 0) eatCd--;
        double mv = Math.hypot(p.getX() - pLastX, p.getZ() - pLastZ); // blocks per tick
        boolean ground = p.onGround();
        double radius = 0;
        if (!p.isShiftKeyDown() && ground && stepCd == 0) {
            if (mv > 0.2) { radius = cfg.hearSprint; stepCd = 7; }
            else if (mv > 0.05) { radius = cfg.hearWalk; stepCd = 12; }
        }
        if (!pLastGround && ground) radius = Math.max(radius, cfg.hearJump);                       // landing
        if (pLastGround && !ground && p.getDeltaMovement().y > 0.1) radius = Math.max(radius, cfg.hearJump); // jump
        // eating and drinking take about 1.6 s (a bow or a shield is held much longer)
        if (eatCd == 0 && p.isUsingItem() && p.getTicksUsingItem() + p.getUseItemRemainingTicks() <= 40) {
            radius = Math.max(radius, 14.0);
            eatCd = 10;
        }
        if (p.swinging && !pLastSwing) radius = Math.max(radius, 10.0);                             // attack, mining
        pLastX = p.getX(); pLastZ = p.getZ(); pLastGround = ground; pLastSwing = p.swinging;
        if (radius > 0) hearSound(p.position(), radius);
    }

    // =====================================================================================
    // sight: full blocks block it, leaves / glass / fences / doors etc. do not
    // =====================================================================================
    private boolean canSee(ServerLevel sl, ServerPlayer p, LazurConfig cfg) {
        if (this.distanceToSqr(p) > cfg.sightRange * cfg.sightRange) return false;
        Vec3 from = this.getEyePosition();
        return rayClear(sl, from, p.getEyePosition()) || rayClear(sl, from, p.position().add(0, 0.4, 0));
    }

    private static boolean rayClear(ServerLevel sl, Vec3 a, Vec3 b) {
        Vec3 d = b.subtract(a);
        int n = Math.max(1, (int) (d.length() / 0.4));
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int i = 1; i < n; i++) {
            double f = i / (double) n;
            m.set(Mth.floor(a.x + d.x * f), Mth.floor(a.y + d.y * f), Mth.floor(a.z + d.z * f));
            if (sl.getBlockState(m).canOcclude()) return false;
        }
        return true;
    }

    // =====================================================================================
    // chase brain (server only, called every tick by the manager)
    // =====================================================================================
    public void resetAttack() {
        attackTick = -1;
        attackCooldown = 20;
        sees = true;
        searching = false;
        lostTicks = 0;
        heard = null;
        runTo = null; wanderGoal = null; noiseCount = 0; noiseWindow = 0; pauseTicks = 0;
    }

    public void setAttackCooldown(int ticks) { attackCooldown = ticks; }

    /** Marker (a style "insertion") that lets the client find this name in chat and make it glitch. */
    public static final String GLITCH_MARK = "lazur:glitch";

    /** Death messages ("X was slain by ...") show this name: scrambled text instead of "Lazur". */
    @Override
    public net.minecraft.network.chat.Component getDisplayName() {
        return net.minecraft.network.chat.Component.literal("Lazur").withStyle(
                net.minecraft.network.chat.Style.EMPTY.withObfuscated(true).withInsertion(GLITCH_MARK));
    }

    private int slamAnim;

    /** After a teleport to an unreachable player: an instant strike that knocks the player away and down. */
    public void slam(ServerPlayer target) {
        slamAnim = 12;
        getNavigation().stop();
        setLazurState(S_ATTACK);
        double dx = target.getX() - this.getX(), dz = target.getZ() - this.getZ();
        double len = Math.max(1.0E-3, Math.hypot(dx, dz));
        target.setDeltaMovement(dx / len * 1.2, -0.9, dz / len * 1.2); // away from him and down, off the tower
        target.hurtMarked = true;                                       // send the new velocity to the client
        target.resetFallDistance(); // no fall damage from the push itself
    }

    public void chaseTick(ServerPlayer target) {
        ServerLevel sl = (ServerLevel) this.level();
        LazurConfig cfg = LazurConfig.get();

        if (slamAnim > 0) {                   // the strike animation plays for ~0.6 s
            slamAnim--;
            setLazurState(S_ATTACK);
            getNavigation().stop();
            return;
        }

        listen(target, cfg);

        // ---- strike in progress: the animation plays while he KEEPS RUNNING at the player ----
        if (attackTick >= 0) {
            attackTick++;
            if (attackTick == attackHitTick() && this.distanceTo(target) <= cfg.attackReach + 1.0) {
                if (isPlayerSized()) {
                    // the black player simply hits
                    target.hurtServer(sl, this.damageSources().mobAttack(this), cfg.damage);
                    net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(target, new com.lazur.net.LazurNet.GlitchHit()); // the screen glitch grows
                } else {
                    LazurGrab.begin(LazurData.get(sl.getServer()), target, this); // it landed: pick the player up
                    return;
                }
            }
            if (attackTick >= attackTotalTicks()) {
                attackTick = -1;
                attackCooldown = isPlayerSized() ? 14 : 12;
            } else {
                setLazurState(S_ATTACK);
                runAtPlayer(sl, target, cfg);
                return;
            }
        }
        if (attackCooldown > 0) attackCooldown--;

        // ---- sight ----
        if (this.tickCount % 4 == 0) sees = canSee(sl, target, cfg);
        if (sees) {
            lostTicks = 0;
            if (searching) {            // found the player again
                searching = false;
                heard = null; runTo = null; wanderGoal = null; noiseCount = 0; pauseTicks = 0;
            }
        } else {
            lostTicks++;
            if (!searching && lostTicks >= cfg.loseSightTicks) {
                searching = true;       // 2 s without sight: sneak around and listen
                noiseCount = 0; wanderGoal = null; pauseTicks = 0; heard = null; runTo = null;
                this.getNavigation().stop();
            }
        }

        // ---- close and visible: hit ----
        double distSq = this.distanceToSqr(target);
        if (distSq <= cfg.attackReach * cfg.attackReach && attackCooldown == 0 && this.hasLineOfSight(target)) {
            attackTick = 0;
            setLazurState(S_ATTACK);
            runAtPlayer(sl, target, cfg); // no stop: the swing starts on the run
            return;
        }

        if (!searching) runAtPlayer(sl, target, cfg);
        else searchAndListen(sl, cfg, target);
    }

    private void runAtPlayer(ServerLevel sl, ServerPlayer target, LazurConfig cfg) {
        setSpeedMode(false);
        if (attackTick < 0) setLazurState(S_RUN); // while striking the state stays S_ATTACK
        this.getLookControl().setLookAt(target, 30.0F, 30.0F);
        if (this.tickCount % 10 == 0 || this.getNavigation().isDone()) {
            this.getNavigation().moveTo(target, 1.0);
        }
        int wall = wallHeight(sl, target.position());
        if (this.getNavigation().isDone() && wall < 2) {
            // no path (glass, leaves, closed doors...): walk straight at the player and break what is in the way
            this.getMoveControl().setWantedPosition(target.getX(), target.getY(), target.getZ(), 1.0);
        }
        // a wall of 2+ blocks and no way round, but he can see the player: after 1 s he teleports next to him (tall form only)
        if (tpCooldown > 0) tpCooldown--;
        if (!isPlayerSized() && wall >= 2 && this.getNavigation().isDone() && sees) {
            if (++blockedTicks >= 20 && tpCooldown <= 0) { teleportRequest = true; blockedTicks = 0; tpCooldown = 60; }
        } else {
            blockedTicks = Math.max(0, blockedTicks - 2);
        }
        if (this.horizontalCollision) {
            if (wall == 1) this.getJumpControl().jump(); // one block: he hops onto it; 2+ blocks: he does not even try
            breakAhead(sl, target.position());
        }
    }

    /** Warden-like search: follow sounds, run at a repeated noise, otherwise roam around the player and listen. */
    private void searchAndListen(ServerLevel sl, LazurConfig cfg, ServerPlayer target) {
        if (noiseWindow > 0 && --noiseWindow == 0) noiseCount = 0;

        // 2+ noises: he runs at the place of the last one
        if (runTo != null) {
            if (--runTicks <= 0 || this.position().distanceToSqr(runTo) < 4.0) {
                runTo = null; noiseCount = 0; heard = null; wanderGoal = null;
                pauseTicks = 30;
            } else {
                moveToward(sl, cfg, runTo, true);
                return;
            }
        }
        if (pauseTicks > 0) { pauseTicks--; standAndListen(); return; }

        // 1 noise: he sneaks to where the last one was
        if (heard != null) {
            if (this.position().distanceToSqr(heard) > 2.25) {
                moveToward(sl, cfg, heard, false);
                return;
            }
            heard = null; wanderGoal = null;
            pauseTicks = 40 + this.random.nextInt(61);       // arrived at the sound: listens for 2-5 s
            standAndListen();
            return;
        }

        // nothing to follow: roams around the player, stopping now and then to listen
        if (wanderGoal != null) {
            wanderTicks--;
            if (wanderTicks <= 0 || this.position().distanceToSqr(wanderGoal) < 2.25
                    || (wanderTicks < 380 && this.getNavigation().isDone())) {
                wanderGoal = null;
                pauseTicks = 40 + this.random.nextInt(41);       // arrived at the point: listens for 2-4 s
                standAndListen();
                return;
            }
            moveToward(sl, cfg, wanderGoal, false);
            return;
        }
        wanderGoal = pickWanderGoal(sl, target);
        wanderTicks = 400;
        if (wanderGoal == null) { pauseTicks = 20; standAndListen(); }
    }

    private void standAndListen() {
        setSpeedMode(true);
        this.getNavigation().stop();
        setLazurState(S_LISTEN);
    }

    /** Sneaks (or runs) to a point; jumps and breaks leaves / glass when something is in the way. */
    private void moveToward(ServerLevel sl, LazurConfig cfg, Vec3 goal, boolean run) {
        setSpeedMode(!run);
        setLazurState(run ? S_RUN : S_CREEP);
        this.getLookControl().setLookAt(goal.x, goal.y + 1.0, goal.z);
        if (this.tickCount % 10 == 0 || this.getNavigation().isDone()) {
            this.getNavigation().moveTo(goal.x, goal.y, goal.z, 1.0);
        }
        int wall = wallHeight(sl, goal);
        if (this.getNavigation().isDone() && wall < 2) {
            this.getMoveControl().setWantedPosition(goal.x, goal.y, goal.z, 1.0);
        }
        if (this.horizontalCollision) {
            if (wall == 1) this.getJumpControl().jump();
            breakAhead(sl, goal);
        }
    }

    /** How many solid blocks high the obstacle right in front of him is, towards {@code goal}: 0 none, 1, 2 (= 2 or more). */
    private int wallHeight(ServerLevel sl, Vec3 goal) {
        Vec3 dir = new Vec3(goal.x - getX(), 0, goal.z - getZ());
        if (dir.lengthSqr() < 1.0E-4) return 0;
        dir = dir.normalize();
        int y0 = Mth.floor(getY() + 0.1);
        int best = 0;
        for (double d : new double[]{0.6, 1.0}) {
            int x = Mth.floor(getX() + dir.x * d), z = Mth.floor(getZ() + dir.z * d);
            int h = 0;
            while (h < 2) {
                BlockPos p = new BlockPos(x, y0 + h, z);
                if (sl.getBlockState(p).getCollisionShape(sl, p).isEmpty()) break;
                h++;
            }
            if (h == 1) { // a one-block step: he hops onto it only if the two blocks above it are free (no low ceiling)
                BlockPos a1 = new BlockPos(x, y0 + 1, z), a2 = new BlockPos(x, y0 + 2, z);
                if (!sl.getBlockState(a1).getCollisionShape(sl, a1).isEmpty()
                        || !sl.getBlockState(a2).getCollisionShape(sl, a2).isEmpty()) h = 2;
            }
            best = Math.max(best, h);
        }
        return best;
    }

    /** A random reachable standing place 6-20 blocks around the player (he does not know where exactly the player is). */
    private Vec3 pickWanderGoal(ServerLevel sl, ServerPlayer target) {
        for (int i = 0; i < 10; i++) {
            double ang = this.random.nextDouble() * Math.PI * 2, r = 6.0 + this.random.nextDouble() * 14.0;
            int x = Mth.floor(target.getX() + Math.cos(ang) * r), z = Mth.floor(target.getZ() + Math.sin(ang) * r);
            int y0 = target.getBlockY();
            BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
            for (int dy = 4; dy >= -6; dy--) {
                m.set(x, y0 + dy, z);
                if (!sl.hasChunkAt(m)) break;
                BlockPos feet = m.immutable();
                if (!sl.getBlockState(feet.below()).canOcclude()) continue;
                if (!sl.getBlockState(feet).getCollisionShape(sl, feet).isEmpty()) continue;
                if (!sl.getBlockState(feet.above()).getCollisionShape(sl, feet.above()).isEmpty()) continue;
                net.minecraft.world.level.pathfinder.Path path = this.getNavigation().createPath(feet, 0);
                if (path != null && path.canReach()) return Vec3.atBottomCenterOf(feet);
                break;
            }
        }
        return null;
    }

    // =====================================================================================
    // speed tuning
    // =====================================================================================
    private void setSpeedMode(boolean creep) {
        if (speedInit && creep == creepMode) return;
        speedInit = true;
        creepMode = creep;
        AttributeInstance attr = this.getAttribute(Attributes.MOVEMENT_SPEED);
        if (attr != null) attr.setBaseValue(creep ? CREEP_ATTR : RUN_ATTR);
    }

    /** Lazur breaks leaves, glass, panes, doors, gates, trapdoors. Earth, stone, wood stay solid. */
    private void breakAhead(ServerLevel sl, Vec3 goal) {
        Vec3 dir = new Vec3(goal.x - getX(), 0, goal.z - getZ());
        if (dir.lengthSqr() < 1.0E-4) return;
        dir = dir.normalize();
        for (int dy = 0; dy < 3; dy++) {
            BlockPos p = BlockPos.containing(getX() + dir.x * 0.9, getY() + dy, getZ() + dir.z * 0.9);
            BlockState bs = sl.getBlockState(p);
            if (Targets.lazurCanBreak(bs)) {
                sl.destroyBlock(p, false);
            }
        }
    }
}
