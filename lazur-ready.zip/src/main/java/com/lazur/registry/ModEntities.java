package com.lazur.registry;

import com.lazur.LazurMod;
import com.lazur.entity.LazurEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public final class ModEntities {
    public static final ResourceKey<EntityType<?>> LAZUR_KEY =
            ResourceKey.create(Registries.ENTITY_TYPE, LazurMod.id("lazur"));

    public static final EntityType<LazurEntity> LAZUR = Registry.register(
            BuiltInRegistries.ENTITY_TYPE,
            LAZUR_KEY,
            EntityType.Builder.<LazurEntity>of(LazurEntity::new, MobCategory.MISC)
                    .sized(0.6f, 2.9f)
                    .clientTrackingRange(10)
                    .updateInterval(2)
                    .fireImmune()
                    .build(LAZUR_KEY));

    /** The same Lazur, but with the hitbox of a player (0.6 x 1.8): the cave form that runs through tunnels. */
    public static final ResourceKey<EntityType<?>> LAZUR_PLAYER_KEY =
            ResourceKey.create(Registries.ENTITY_TYPE, LazurMod.id("lazur_player"));

    public static final EntityType<LazurEntity> LAZUR_PLAYER = Registry.register(
            BuiltInRegistries.ENTITY_TYPE,
            LAZUR_PLAYER_KEY,
            EntityType.Builder.<LazurEntity>of(LazurEntity::new, MobCategory.MISC)
                    .sized(0.6f, 1.8f)
                    .clientTrackingRange(10)
                    .updateInterval(2)
                    .fireImmune()
                    .build(LAZUR_PLAYER_KEY));

    public static void initialize() {
        FabricDefaultAttributeRegistry.register(LAZUR, LazurEntity.createLazurAttributes());
        FabricDefaultAttributeRegistry.register(LAZUR_PLAYER, LazurEntity.createLazurAttributes());
    }

    private ModEntities() {}
}
