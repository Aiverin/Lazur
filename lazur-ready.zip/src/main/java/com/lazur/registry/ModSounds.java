package com.lazur.registry;

import com.lazur.LazurMod;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.sounds.SoundEvent;

/** Sounds are defined in assets/lazur/sounds.json (7 footstep variants + one long ambient). */
public final class ModSounds {
    public static final SoundEvent LAZUR_STEP = register("entity.lazur.step");
    public static final SoundEvent LAZUR_MISS = register("entity.lazur.miss");       // a mistake in the grab mini-game
    public static final SoundEvent LAZUR_REVEAL = register("entity.lazur.reveal");   // Lazur shows himself
    public static final SoundEvent LAZUR_HEAD_SPIN = register("entity.lazur.head_spin"); // the cave form turns its head
    public static final SoundEvent LAZUR_AMBIENT = register("ambient.lazur.ambient");

    private static SoundEvent register(String path) {
        var id = LazurMod.id(path);
        return Registry.register(BuiltInRegistries.SOUND_EVENT, id, SoundEvent.createVariableRangeEvent(id));
    }

    public static void initialize() {
        // touching the class registers the fields above
    }

    private ModSounds() {}
}
