package com.lazur.net;

import com.lazur.LazurMod;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * Packets of the grab mini-game (start, state, end / key press) and the small effects (glitch, chase flag).
 * Pattern copied from the Fabric 26.2 networking docs (record + Type + StreamCodec).
 */
public final class LazurNet {
    private LazurNet() {}

    /** End modes (server -> client). */
    public static final int END_RELEASED = 0, END_ABORT = 1;

    // ---------------------------------------------------------------------------------------
    /**
     * Lazur grabbed the player. lazurId = entity id (not UUID), so the client can find it.
     * keys: the W/A/S/D sequence to press in order (0 forward(W) 1 left(A) 2 back(S) 3 right(D));
     * totalTicks: how long the "air" gauge lasts once the intro (the lift) is over.
     */
    public record GrabStart(int lazurId, int[] keys, int totalTicks) implements CustomPacketPayload {
        public static final Type<GrabStart> TYPE = new Type<>(LazurMod.id("grab_start"));
        public static final StreamCodec<RegistryFriendlyByteBuf, GrabStart> CODEC = new StreamCodec<>() {
            @Override
            public GrabStart decode(RegistryFriendlyByteBuf buf) {
                int id = buf.readVarInt(), total = buf.readVarInt(), n = buf.readVarInt();
                int[] keys = new int[n];
                for (int i = 0; i < n; i++) keys[i] = buf.readVarInt();
                return new GrabStart(id, keys, total);
            }

            @Override
            public void encode(RegistryFriendlyByteBuf buf, GrabStart p) {
                buf.writeVarInt(p.lazurId);
                buf.writeVarInt(p.totalTicks);
                buf.writeVarInt(p.keys.length);
                for (int k : p.keys) buf.writeVarInt(k);
            }
        };

        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    // ---------------------------------------------------------------------------------------
    /** Every tick while grabbed: the air left (0..1), how many keys are done, how many mistakes were made. */
    public record GrabState(float air, int done, int errors) implements CustomPacketPayload {
        public static final Type<GrabState> TYPE = new Type<>(LazurMod.id("grab_state"));
        public static final StreamCodec<RegistryFriendlyByteBuf, GrabState> CODEC = StreamCodec.composite(
                ByteBufCodecs.FLOAT, GrabState::air,
                ByteBufCodecs.VAR_INT, GrabState::done,
                ByteBufCodecs.VAR_INT, GrabState::errors,
                GrabState::new);

        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    // ---------------------------------------------------------------------------------------
    /** The grab is over (released / died / aborted): the client lets go of the camera and the position. */
    public record GrabEnd(int mode) implements CustomPacketPayload {
        public static final Type<GrabEnd> TYPE = new Type<>(LazurMod.id("grab_end"));
        public static final StreamCodec<RegistryFriendlyByteBuf, GrabEnd> CODEC = StreamCodec.composite(
                ByteBufCodecs.VAR_INT, GrabEnd::mode,
                GrabEnd::new);

        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    // ---------------------------------------------------------------------------------------
    /** Client -> server: one key press during the grab (0 W, 1 A, 2 S, 3 D). The server judges it. */
    public record GrabKey(int key) implements CustomPacketPayload {
        public static final Type<GrabKey> TYPE = new Type<>(LazurMod.id("grab_key"));
        public static final StreamCodec<RegistryFriendlyByteBuf, GrabKey> CODEC = StreamCodec.composite(
                ByteBufCodecs.VAR_INT, GrabKey::key,
                GrabKey::new);

        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    // ---------------------------------------------------------------------------------------
    /** The black player landed a hit: the screen glitch grows (it fades away by itself). */
    public record GlitchHit() implements CustomPacketPayload {
        public static final Type<GlitchHit> TYPE = new Type<>(LazurMod.id("glitch_hit"));
        public static final StreamCodec<RegistryFriendlyByteBuf, GlitchHit> CODEC = StreamCodec.unit(new GlitchHit());

        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    // ---------------------------------------------------------------------------------------
    /** A chase is on / over: during it the game cannot be paused and the "quit to menu" button is gone. */
    public record ChaseFlag(boolean on) implements CustomPacketPayload {
        public static final Type<ChaseFlag> TYPE = new Type<>(LazurMod.id("chase_flag"));
        public static final StreamCodec<RegistryFriendlyByteBuf, ChaseFlag> CODEC = StreamCodec.composite(
                ByteBufCodecs.BOOL, ChaseFlag::on,
                ChaseFlag::new);

        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    /** Cave form is being stared at: strength 0..1 drives camera shake and the pull towards Lazur (0 = stop). */
    public record CaveGaze(int lazurId, float strength) implements CustomPacketPayload {
        public static final Type<CaveGaze> TYPE = new Type<>(LazurMod.id("cave_gaze"));
        public static final StreamCodec<RegistryFriendlyByteBuf, CaveGaze> CODEC = StreamCodec.composite(
                ByteBufCodecs.VAR_INT, CaveGaze::lazurId,
                ByteBufCodecs.FLOAT, CaveGaze::strength,
                CaveGaze::new);

        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    /** The jumpscare in the bed: red edges on both sides of the screen for this many ticks. */
    public record Scream(int ticks) implements CustomPacketPayload {
        public static final Type<Scream> TYPE = new Type<>(LazurMod.id("scream"));
        public static final StreamCodec<RegistryFriendlyByteBuf, Scream> CODEC = StreamCodec.composite(
                ByteBufCodecs.VAR_INT, Scream::ticks,
                Scream::new);

        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    /** Common initializer: payload types must be registered on both sides. */
    public static void registerPayloads() {
        PayloadTypeRegistry.clientboundPlay().register(GrabStart.TYPE, GrabStart.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(GrabState.TYPE, GrabState.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(GrabEnd.TYPE, GrabEnd.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(GlitchHit.TYPE, GlitchHit.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(ChaseFlag.TYPE, ChaseFlag.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(CaveGaze.TYPE, CaveGaze.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(Scream.TYPE, Scream.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(GrabKey.TYPE, GrabKey.CODEC);
    }
}
