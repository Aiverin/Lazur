package com.lazur.net;

import com.lazur.LazurMod;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * Packets of the grab mini-game.
 * Server -> client: start, state (every tick), prompt, end. Client -> server: result of one prompt.
 * Pattern copied from the Fabric 26.2 networking docs (record + Type + StreamCodec).
 */
public final class LazurNet {
    private LazurNet() {}

    /** Result codes of one prompt (client -> server). */
    public static final int R_HIT = 0, R_WRONG_KEY = 1, R_EARLY = 2, R_MISS = 3;
    /** End modes (server -> client). */
    public static final int END_RELEASED = 0, END_ABORT = 1;

    // ---------------------------------------------------------------------------------------
    /** Lazur grabbed the player. lazurId = entity id (not UUID), so the client can find it. */
    public record GrabStart(int lazurId) implements CustomPacketPayload {
        public static final Type<GrabStart> TYPE = new Type<>(LazurMod.id("grab_start"));
        public static final StreamCodec<RegistryFriendlyByteBuf, GrabStart> CODEC = StreamCodec.composite(
                ByteBufCodecs.VAR_INT, GrabStart::lazurId,
                GrabStart::new);

        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    // ---------------------------------------------------------------------------------------
    /** Sent every tick while grabbed: the gauge at the bottom of the screen (0..1). */
    public record GrabState(float bar) implements CustomPacketPayload {
        public static final Type<GrabState> TYPE = new Type<>(LazurMod.id("grab_state"));
        public static final StreamCodec<RegistryFriendlyByteBuf, GrabState> CODEC = StreamCodec.composite(
                ByteBufCodecs.FLOAT, GrabState::bar,
                GrabState::new);

        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    // ---------------------------------------------------------------------------------------
    /**
     * One timing prompt.
     * key: 0 forward(W) 1 left(A) 2 back(S) 3 right(D); x, y: centre of the prompt, 0..1 of the screen;
     * duration: ticks the ring needs to shrink onto the circle; winStart: tick (since the prompt appeared)
     * when pressing starts to count; startRadius: pixels; curve: 0 = linear, 1 = accelerating, 2 = decelerating.
     */
    public record GrabPrompt(int id, int key, float x, float y, int duration, int winStart, int startRadius, int curve)
            implements CustomPacketPayload {
        public static final Type<GrabPrompt> TYPE = new Type<>(LazurMod.id("grab_prompt"));
        // written by hand: eight fields are more than StreamCodec.composite is guaranteed to take
        public static final StreamCodec<RegistryFriendlyByteBuf, GrabPrompt> CODEC = new StreamCodec<>() {
            @Override
            public GrabPrompt decode(RegistryFriendlyByteBuf buf) {
                return new GrabPrompt(buf.readVarInt(), buf.readVarInt(), buf.readFloat(), buf.readFloat(),
                        buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt());
            }

            @Override
            public void encode(RegistryFriendlyByteBuf buf, GrabPrompt p) {
                buf.writeVarInt(p.id);
                buf.writeVarInt(p.key);
                buf.writeFloat(p.x);
                buf.writeFloat(p.y);
                buf.writeVarInt(p.duration);
                buf.writeVarInt(p.winStart);
                buf.writeVarInt(p.startRadius);
                buf.writeVarInt(p.curve);
            }
        };

        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    // ---------------------------------------------------------------------------------------
    /** The grab is over (released / died / aborted): the client lets go of the camera and the position. */
    public record GrabEnd(int mode) implements CustomPacketPayload {
        public static final Type<GrabEnd> TYPE = new Type<>(LazurMod.id("grab_end"));
        public static final StreamCodec<RegistryFriendlyByteBuf, GrabEnd> CODEC = StreamCodec.composite(
                ByteBufCodecs.VAR_INT, GrabEnd::mode,
                GrabEnd::new);

        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    // ---------------------------------------------------------------------------------------
    /** Client -> server: how the prompt ended (see R_*). */
    public record GrabResult(int id, int code) implements CustomPacketPayload {
        public static final Type<GrabResult> TYPE = new Type<>(LazurMod.id("grab_result"));
        public static final StreamCodec<RegistryFriendlyByteBuf, GrabResult> CODEC = StreamCodec.composite(
                ByteBufCodecs.VAR_INT, GrabResult::id,
                ByteBufCodecs.VAR_INT, GrabResult::code,
                GrabResult::new);

        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    // ---------------------------------------------------------------------------------------
    /** Cave form is being stared at: strength 0..1 drives camera shake and the pull towards Lazur (0 = stop). */
    public record CaveGaze(int lazurId, float strength) implements CustomPacketPayload {
        public static final Type<CaveGaze> TYPE = new Type<>(LazurMod.id("cave_gaze"));
        public static final StreamCodec<RegistryFriendlyByteBuf, CaveGaze> CODEC = StreamCodec.composite(
                ByteBufCodecs.VAR_INT, CaveGaze::lazurId,
                ByteBufCodecs.FLOAT, CaveGaze::strength,
                CaveGaze::new);

        @Override
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    /** Common initializer: payload types must be registered on both sides. */
    public static void registerPayloads() {
        PayloadTypeRegistry.clientboundPlay().register(GrabStart.TYPE, GrabStart.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(GrabState.TYPE, GrabState.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(GrabPrompt.TYPE, GrabPrompt.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(GrabEnd.TYPE, GrabEnd.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(CaveGaze.TYPE, CaveGaze.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(GrabResult.TYPE, GrabResult.CODEC);
    }
}
