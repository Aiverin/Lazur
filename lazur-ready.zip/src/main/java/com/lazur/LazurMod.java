package com.lazur;

import com.lazur.logic.LazurCommands;
import com.lazur.logic.LazurEvents;
import com.lazur.registry.ModEntities;
import com.lazur.registry.ModSounds;
import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LazurMod implements ModInitializer {
    public static final String MOD_ID = "lazur";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        LazurConfig.load();      // must be before ModEntities (attributes read the config)
        ModSounds.initialize();
        ModEntities.initialize();
        LazurEvents.register();
        LazurCommands.register();
    }
}
