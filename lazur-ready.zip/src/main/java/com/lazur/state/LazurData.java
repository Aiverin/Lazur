package com.lazur.state;

import com.lazur.LazurMod;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Everything the mod remembers about the world. Stored as one CompoundTag inside the overworld data storage.
 * All timers are tick counters that are only decremented while the server (= the world) is running,
 * so they pause automatically when the player leaves the world.
 */
public class LazurData extends SavedData {

    public static final int HOLD = 0;   // original block waits for the chase to end
    public static final int READY = 1;  // waits for the next dawn
    public static final int DUE = 2;    // dawn passed, put back as soon as the chunk is loaded

    /** Current substitution (only one at a time). */
    public static class Sub {
        public int type;                 // LazurManager.SUB_*
        public int x, y, z;
        public String blockId = "";
        public int abandon = -1;         // ticks until Lazur leaves an untouched block (-1 = off)
        public int reveal = -1;          // ticks until reveal after the first click (-1 = not clicked)
        public boolean force;            // reveal now (debug / player tried to break it)
        public String mob = "";          // uuid of the substituted creature
        public int gaze;                 // ticks the player has been looking it in the eyes

        public BlockPos pos() { return new BlockPos(x, y, z); }

        CompoundTag save() {
            CompoundTag t = new CompoundTag();
            t.putInt("type", type); t.putInt("x", x); t.putInt("y", y); t.putInt("z", z);
            t.putString("block", blockId);
            t.putInt("abandon", abandon); t.putInt("reveal", reveal);
            t.putBoolean("force", force);
            t.putString("mob", mob); t.putInt("gaze", gaze);
            return t;
        }

        static Sub load(CompoundTag t) {
            Sub s = new Sub();
            s.type = t.getIntOr("type", 0);
            s.x = t.getIntOr("x", 0); s.y = t.getIntOr("y", 0); s.z = t.getIntOr("z", 0);
            s.blockId = t.getStringOr("block", "");
            s.abandon = t.getIntOr("abandon", -1); s.reveal = t.getIntOr("reveal", -1);
            s.force = t.getBooleanOr("force", false);
            s.mob = t.getStringOr("mob", ""); s.gaze = t.getIntOr("gaze", 0);
            return s;
        }
    }

    /** A block that was taken away and must come back at dawn. */
    public static class Ret {
        public int x, y, z;
        public CompoundTag state = new CompoundTag();
        public CompoundTag be;           // block entity data incl. chest contents (nullable)
        public int status = HOLD;
        public boolean particles;        // faint black particles at the empty spot (abandoned only)
        public int seen;                 // ticks the player has seen those particles

        public BlockPos pos() { return new BlockPos(x, y, z); }

        CompoundTag save() {
            CompoundTag t = new CompoundTag();
            t.putInt("x", x); t.putInt("y", y); t.putInt("z", z);
            t.put("state", state);
            if (be != null) t.put("be", be);
            t.putInt("status", status);
            t.putBoolean("particles", particles); t.putInt("seen", seen);
            return t;
        }

        static Ret load(CompoundTag t) {
            Ret r = new Ret();
            r.x = t.getIntOr("x", 0); r.y = t.getIntOr("y", 0); r.z = t.getIntOr("z", 0);
            r.state = t.getCompoundOrEmpty("state");
            r.be = t.getCompound("be").orElse(null);
            r.status = t.getIntOr("status", HOLD);
            r.particles = t.getBooleanOr("particles", false); r.seen = t.getIntOr("seen", 0);
            return r;
        }
    }

    // ---- fields ----
    public boolean initialized;
    public int silCd, subCd, farTicks;
    public long lastDay;
    public final List<int[]> homes = new ArrayList<>();      // {x, z}: first spawn + beds slept in

    public int role;                 // LazurManager.ROLE_*
    public UUID lazurId;
    public int phase, phaseTicks, glitchTotal, age;
    public int chaseTicks;
    public boolean fading;
    public int missing;              // not saved

    public Sub sub;
    public final List<Ret> returns = new ArrayList<>();
    public int bedAttack;
    public boolean cdOnRespawn;

    public static final Codec<LazurData> CODEC = CompoundTag.CODEC.xmap(LazurData::fromTag, LazurData::toTag);
    public static final SavedDataType<LazurData> TYPE =
            new SavedDataType<>(LazurMod.id("lazur"), LazurData::new, CODEC, null);

    public LazurData() {}

    public static LazurData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(TYPE);
    }

    public void resetAll() {
        initialized = false; silCd = subCd = farTicks = 0; lastDay = 0;
        homes.clear(); role = 0; lazurId = null; phase = phaseTicks = glitchTotal = age = 0;
        chaseTicks = 0; fading = false; missing = 0; sub = null; returns.clear(); bedAttack = 0; cdOnRespawn = false;
        setDirty();
    }

    private CompoundTag toTag() {
        CompoundTag t = new CompoundTag();
        t.putBoolean("init", initialized);
        t.putInt("silCd", silCd); t.putInt("subCd", subCd); t.putInt("farTicks", farTicks);
        t.putLong("lastDay", lastDay);
        ListTag hl = new ListTag();
        for (int[] h : homes) {
            CompoundTag c = new CompoundTag();
            c.putInt("x", h[0]); c.putInt("z", h[1]);
            hl.add(c);
        }
        t.put("homes", hl);
        t.putInt("role", role);
        if (lazurId != null) t.putString("lazur", lazurId.toString());
        t.putInt("phase", phase); t.putInt("phaseTicks", phaseTicks);
        t.putInt("glitchTotal", glitchTotal); t.putInt("age", age);
        t.putInt("chaseTicks", chaseTicks); t.putBoolean("fading", fading);
        if (sub != null) t.put("sub", sub.save());
        ListTag rl = new ListTag();
        for (Ret r : returns) rl.add(r.save());
        t.put("returns", rl);
        t.putInt("bedAttack", bedAttack); t.putBoolean("cdOnRespawn", cdOnRespawn);
        return t;
    }

    private static LazurData fromTag(CompoundTag t) {
        LazurData d = new LazurData();
        d.initialized = t.getBooleanOr("init", false);
        d.silCd = t.getIntOr("silCd", 0); d.subCd = t.getIntOr("subCd", 0); d.farTicks = t.getIntOr("farTicks", 0);
        d.lastDay = t.getLongOr("lastDay", 0L);
        ListTag hl = t.getListOrEmpty("homes");
        for (int i = 0; i < hl.size(); i++) {
            CompoundTag c = hl.getCompoundOrEmpty(i);
            d.homes.add(new int[]{c.getIntOr("x", 0), c.getIntOr("z", 0)});
        }
        d.role = t.getIntOr("role", 0);
        String id = t.getStringOr("lazur", "");
        if (!id.isEmpty()) {
            try { d.lazurId = UUID.fromString(id); } catch (IllegalArgumentException ignored) { }
        }
        d.phase = t.getIntOr("phase", 0); d.phaseTicks = t.getIntOr("phaseTicks", 0);
        d.glitchTotal = t.getIntOr("glitchTotal", 0); d.age = t.getIntOr("age", 0);
        d.chaseTicks = t.getIntOr("chaseTicks", 0); d.fading = t.getBooleanOr("fading", false);
        t.getCompound("sub").ifPresent(c -> d.sub = Sub.load(c));
        ListTag rl = t.getListOrEmpty("returns");
        for (int i = 0; i < rl.size(); i++) d.returns.add(Ret.load(rl.getCompoundOrEmpty(i)));
        d.bedAttack = t.getIntOr("bedAttack", 0); d.cdOnRespawn = t.getBooleanOr("cdOnRespawn", false);
        return d;
    }
}
