# Lazur

Horror mod for Minecraft **26.2** (Fabric): an AI mimic that hides among familiar things and hunts the player.

## Requirements

- Minecraft 26.2
- Fabric Loader 0.20.1+
- Fabric API
- Java 25
- Optional: [Simple Voice Chat](https://modrinth.com/plugin/simple-voice-chat) — Lazur can hear the microphone

## Build

```
./gradlew build
```

The jar appears in `build/libs/`.

## Grab mini-game

Lazur's strike no longer stops him: he keeps running while the arm swings. If the strike lands he lifts the player in one
hand, face to face, the camera shakes and a gauge appears at the bottom of the screen.

- Prompts (W / A / S / D, random spot of the screen, random ring animation) must be hit in timing.
- 7 hits break free the first time, then 10, 13, ... (`grabBaseHits`, `grabHitsStep`) until Lazur finally kills the player.
- The 2nd mistake (wrong key, too early, or a missed prompt) or a full gauge kills at once; the player respawns at the world spawn.
- After a release Lazur stands still for 1.5 s (`grabReleaseHeadStartTicks`).
- `/lazur cave` places the cave form 5-10 blocks away; on the timer he appears within 10 blocks in free room.
- `/lazur grab` starts it for testing. All numbers are in `config/lazur.json`.

## Look and sound

- Glitch effects are few, flat (zero-depth patches, like a picture) and black-and-white only.
- The vanilla Ravager roar is removed; Lazur's own clips live in `assets/lazur/sounds/`.

## License

CC0-1.0, see [LICENSE](LICENSE).
