# Lazur

## Setup

For setup instructions, please see the [Fabric Documentation page](https://docs.fabricmc.net/develop/getting-started/creating-a-project#setting-up) related to the IDE that you are using.

## License

This template is available under the CC0 license. Feel free to learn from it and incorporate it in your own projects.

## Grab mini-game

Lazur's strike no longer stops him: he keeps running while the arm swings. If the strike lands he lifts the player in one
hand, face to face, the camera shakes and a gauge appears at the bottom of the screen.

- Prompts (W / A / S / D, random spot of the screen, random ring animation) must be hit in timing.
- 7 hits break free the first time, then 10, 13, ... (`grabBaseHits`, `grabHitsStep`) until Lazur finally kills the player.
- The 2nd mistake (wrong key, too early, or a missed prompt) or a full gauge kills at once; the player respawns at the world spawn.
- After a release Lazur stands still for 1.5 s (`grabReleaseHeadStartTicks`).
- `/lazur grab` starts it for testing. All numbers are in `config/lazur.json`.
