# Lazur

Horror mod for Minecraft **26.2** (Fabric): an AI mimic that hides among familiar things and hunts the player.

## Requirements

- Minecraft 26.2
- Fabric Loader 0.20.1+
- Fabric API
- Java 25
- Optional: [Simple Voice Chat](https://modrinth.com/plugin/simple-voice-chat) — Lazur can hear the microphone

## Build

```
./gradlew build
```

The jar appears in `build/libs/`.

## Grab mini-game

Lazur's strike no longer stops him: he keeps running while the arm swings. If the strike lands he lifts the player in one
hand, face to face, the camera shakes and a gauge appears at the bottom of the screen.

- Prompts (W / A / S / D, random spot of the screen, random ring animation) must be hit in timing.
- 7 hits break free the first time, then 10, 13, ... (`grabBaseHits`, `grabHitsStep`) until Lazur finally kills the player.
- The 2nd mistake (wrong key, too early, or a missed prompt) or a full gauge kills at once; the player respawns at the world spawn.
- After a release Lazur stands still for 1.5 s (`grabReleaseHeadStartTicks`).
- The cave form appears 7-10 blocks from the player (in the space around him: x, z and height, floor within 5-8 blocks of his level), both on the timer and with `/lazur cave`. Looking at his head for 3 s starts the head turn; standing 1 block from him turns him black at once.
- `/lazur grab` starts it for testing. All numbers are in `config/lazur.json`.

- The silhouette appears 2-4 chunks (32-64 blocks) from the player, anywhere in the world: only its cooldown (1-9 days) matters, not the distance from spawn or bed.

- While chasing, the tall Lazur jumps straight to a player who cannot be reached: 5+ blocks above him with no 3x3 platform
  with dense walls under the player, or after the player has built 3 blocks up. It happens 1 s after the condition starts
  (sound `assets/lazur/sounds/teleport.ogg`) and he strikes the player away and down at once; otherwise he just keeps running after the player.

- Animal imitation: any animal (not tamed or named) within 12 blocks of the player; if nothing happens for 10 minutes he drops it and picks the nearest one again.

- The silhouette can also stand on top of a tree canopy (leaves), not only on the ground.

## Death message

When Lazur kills, the message names him with a scrambled text (`<player> was slain by §kLazur`, in the player's own language).
The glitchy name changes its length (3-6 characters) every 0.2-1.5 s in the chat line (client side, through reflection; if
that does not work in your version it just stays a normal obfuscated name).

## Quiet start

A new world is quiet for 20-40 minutes (24000-48000 ticks, random). Then the player is thrown out with a fake network error
(`Internal Exception: java.io.IOException: An existing connection was forcibly closed by the remote host`). After that the FIRST
silhouette comes in 1-4 days; only after it does everything else (cave form, imitations, ambient sound) start working as usual,
with the silhouette cooldown becoming 1-9 days. Worlds saved by an older version skip this and run as usual.
`/lazur kick` does the error right now (for testing); `/lazur status` shows the stage.

## Look and sound

- Glitch effects are few, flat (zero-depth patches, like a picture) and black-and-white only.
- The vanilla Ravager roar is removed; Lazur's own clips live in `assets/lazur/sounds/`.

## License

CC0-1.0, see [LICENSE](LICENSE).
